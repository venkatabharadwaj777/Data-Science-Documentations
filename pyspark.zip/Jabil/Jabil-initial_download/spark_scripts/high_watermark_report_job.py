from pyspark.sql.functions import col, concat_ws, date_add, udf, split, array, coalesce, lit, size
from pyspark.sql.functions import sum as spark_sum
from pyspark.sql.types import DateType, DoubleType, ArrayType
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_date
from importlib import import_module
from datetime import datetime, timedelta
import argparse


MONDAY = 0
SUNDAY = 6

def get_parameters():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--snapshotdate", dest="snapshotdate", metavar="9999-01-01",
                        help="Date in Y-MM-DD format for which query needs to run. If no Date is provided it will "
                             "run for today", required=False)
    parser.add_argument("--s3_root_path", dest="s3_root_path", metavar="s3a://bucket_name/object_path",
                        help="Bucket and object path for writing waterfall component result data", required=False)
    parser.add_argument("--secrets_arn", dest="secrets_arn",
                        help="Secrets name to retrieve Aurora Credentials", required=False)
    parser.add_argument("--region_name", dest="region_name",
                        help="AWS Region")
    parser.add_argument("--aurora_table_name", dest="aurora_table_name",
                        help="Database Header Table Name on the target DB")
    parser.add_argument("--component_header_aurora_table_name", dest="component_header_aurora_table_name",
                        help="Component Header Table Name on the target DB")
    parser.add_argument("--aurora_database_name", dest="aurora_database_name", metavar="Y or N",
                        help="If Y, then we write to aurora, if N - to s3")
    parser.add_argument("--util_script_path", dest="util_script_path",
                        help="Local path to util script")
    parser.add_argument("--enable_logging", dest="enable_logging", required=True,
                        help="Enable or disable logging into logfile")
    args = parser.parse_args()
    return args.util_script_path, args.snapshotdate, args.s3_root_path, args.secrets_arn, args.region_name, \
           args.aurora_table_name, args.aurora_database_name, args.component_header_aurora_table_name, \
           args.enable_logging


class HighWatermarkDataProvider:
    ROLLING_AVG_CONSUMPTION_WEEKS = [13, 26, 39, 52]

    def __init__(self, spark, spark_utils):
        self.spark = spark
        self.spark_utils = spark_utils

    def read_sql_data(self, sql, aurora_params):
        url = "jdbc:mysql://%s/%s?useServerPrepStmts=false&rewriteBatchedStatements=true&" \
              "useUnicode=yes&characterEncoding=UTF-8" % (aurora_params['aurora_host'],
                                                          aurora_params['aurora_database_name'])

        db_properties = {"user": aurora_params['aurora_user'],
                         "password": aurora_params['aurora_pwd'],
                         "driver": "com.mysql.jdbc.Driver"}
        data_df = self.spark.read.jdbc(
            url=url,
            table="("+sql+") as my_table ",
            properties=db_properties
        )
        return data_df

    def get_base_component_waterfall_data(self, s3_root_path, snapshot_date):
        columns = ['PlantCode', 'MaterialCode', 'DataSourceId', 'SnapshotDt', 'MinimumOrderQty',
                   'OrderIncrement', 'TotalDemand', 'TotalLtDemand', 'ReorderPointQty', 'SafetyStockQty', 'LeadTime',
                   'NonConsignedNettableOnHand', 'ConsignedNettableOnHand']
        domain_path = "incontrol/waterfall_component"
        snapshot_date_str = snapshot_date.strftime("%Y-%m-%d")
        s3path = s3_root_path + domain_path\
                 + "/YYYY=" + snapshot_date_str[:4] + "/MM=" + snapshot_date_str[5:7] + "/DD=" + snapshot_date_str[8:]
        base_cw_data = self.spark.read.format("parquet").load(s3path).select(columns)
        column_names_mapping = {"NonConsignedNettableOnHand": "JabilNettableOnHand", "TotalDemand": "TotalGrossDemand",
                                "TotalLtDemand": "TotalLtGrossDemand"}
        base_cw_data = self.spark_utils.rename_columns(base_cw_data, column_names_mapping)\
            .withColumnRenamed("SnapshotDt", "SnapshotDate") \
            .withColumn("SnapshotDate", col("SnapshotDate").cast(DateType())) \
            .withColumn("MaterialKey", concat_ws("_", col("DataSourceId"),
                                                        col("PlantCode"), col("MaterialCode")))
        return base_cw_data.repartition(500)

    def get_on_order_data(self, snapshot_date):
        mondays_data = self.spark.sql("SELECT ccedate AS SnapshotDate, con_ind, plants AS PlantCode, "
                                      "materials AS MaterialCode, lpmd_qty AS OnOrder "
                                      "from domains.vw_lpmd_oo_53mondays WHERE ccedate = '%s'"
                                      % snapshot_date.strftime("%Y-%m-%d"))
        consigned_on_order = mondays_data.filter(col("con_ind") == 2)\
            .withColumnRenamed("OnOrder", "ConsignedOnOrder")\
            .drop("con_ind")
        jabil_owned_on_order = mondays_data.filter(col("con_ind") != 2)\
            .withColumnRenamed("OnOrder", "JabilOwnedOnOrder")\
            .drop("con_ind")\
            .groupby("PlantCode", "MaterialCode", "SnapshotDate")\
            .agg(spark_sum(col("JabilOwnedOnOrder")).alias("JabilOwnedOnOrder"))

        return consigned_on_order.repartition(500), jabil_owned_on_order.repartition(500)

    def get_prior_wkly_receipts_data(self, snapshot_date):
        snapshot_year = snapshot_date.year
        snapshot_week = snapshot_date.isocalendar()[1]
        prior_weekly_receipt_data = self.spark.sql("select wfplant as PlantCode, wfmaterial as MaterialCode, "
                                                   "wfyear as Year, wfweek as Week, "
                                                   "wf_pwk_receipts_qty as PriorWeekReceipts "
                                                   "from domains.vw_inv_prior_wkly_receipts "
                                                   "WHERE wfyear = %d and wfweek = %d " % (snapshot_year,  snapshot_week))
        # taking date from year and week values (add 1 day, as to_date return Sunday)
        prior_weekly_receipt_data = prior_weekly_receipt_data.withColumn("SnapshotDate",
                                                                         concat_ws(" ", col('Year'), col("Week")))\
            .withColumn("SnapshotDate", date_add(to_date(col("SnapshotDate"), "yyyy w"), 1)) \
            .withColumn("SnapshotDate", col("SnapshotDate").cast(DateType())) \
            .drop("Year", "Week")
        return prior_weekly_receipt_data.repartition(500)

    def get_prev_12_weeks_avg_data(self, aurora_params, component_header_aurora_table_name, snapshot_date):
        end_date = snapshot_date - timedelta(weeks=12)
        sql = "Select concat_ws('_', DataSourceId, PlantCode, MaterialCode) as MaterialKey, " \
              "GROUP_CONCAT(TotalDemand) as Rolling13wkAvgGrossDemandList, " \
              "GROUP_CONCAT(TotalLtDemand) as Rolling13wkAvgLtGrossDemandList from %s " \
              "where SnapshotDt >= '%s' and SnapshotDt < '%s' group by MaterialKey" % \
              (component_header_aurora_table_name, end_date.strftime("%Y-%m-%d"), snapshot_date.strftime("%Y-%m-%d"))
        return self.read_sql_data(sql, aurora_params).repartition(500)

    def get_consumption_data(self):
        rolling_avg_list_columns = ', '.join(self.get_rolling_avg_consumption_list_columns())
        mondays_data = self.spark.sql('select PlantCode, MaterialCode, '
                                      'CurrentWeekConsumption, ' + rolling_avg_list_columns +
                                      ' from incontrol.vw_conship_79mondays_tmp')
        return mondays_data.repartition(500)

    def get_rolling_avg_consumption_list_columns(self):
        return [
            'Rolling{}wkAvgConsumptionList'.format(weeks_cnt)
            for weeks_cnt in self.ROLLING_AVG_CONSUMPTION_WEEKS
        ]

class HighWatermarkPipeline:

    def __init__(self, spark, data_provider, spark_utils, pipeline_configs):
        self.spark = spark
        self.data_provider = data_provider
        self.spark_utils = spark_utils
        self.snapshot_date, self.s3_root_path, self.secrets_arn, self.region_name, \
            self.aurora_table_name, self.aurora_database_name, self.component_header_aurora_table_name, \
            self.enable_logging = pipeline_configs
        self.snapshot_date = datetime.strptime(self.snapshot_date, '%Y-%m-%d') if self.snapshot_date \
            else datetime.today().strftime("%Y-%m-%d")
        self.week_day = self.snapshot_date.weekday()
        self.snapshot_date = self.snapshot_date - timedelta(self.week_day) if self.week_day != 0 else self.snapshot_date
        self.rolling_average_udf = udf(self.rolling_average, returnType=DoubleType())

    @staticmethod
    def rolling_average(previous_values, curr_value, skip_last):
        values_arr = list(filter(lambda rec: float(rec) is not None, previous_values))
        curr_value = float(curr_value) if curr_value is not None else 0
        if not skip_last:
            values_arr = [] if values_arr is None else values_arr
            values_arr.append(curr_value)
        return 0.0 if values_arr is None or len(values_arr) == 0 else sum(values_arr) / len(values_arr)

    def update_main_table(self, aurora_params):
        rolling_update_part = '\n'.join(
            (', {{table_name}}.Rolling{weeks_cnt}wkAvgConsumption={{table_name}}_stg.Rolling{weeks_cnt}wkAvgConsumption'
                .format(weeks_cnt=weeks_cnt))
            for weeks_cnt in self.data_provider.ROLLING_AVG_CONSUMPTION_WEEKS
        )

        query = ("UPDATE {table_name},{table_name}_stg  "
                 "SET {table_name}.CurrentWeekConsumption={table_name}_stg.CurrentWeekConsumption " +
                 (rolling_update_part if self.week_day == SUNDAY else "") +
                 " WHERE {table_name}.MaterialKey = {table_name}_stg.MaterialKey "
                 "and {table_name}.SnapshotDate = {table_name}_stg.SnapshotDate") \
            .format(table_name=aurora_params['aurora_table_name'])
        self.spark_utils.run_sql_query(query, self.aurora_database_name, aurora_params['aurora_host'],
                                       aurora_params['aurora_user'], aurora_params['aurora_pwd'])

    @staticmethod
    def split_concat_array_col(data, cols):
        for arr_col in cols:
            data = data.withColumn(arr_col,
                                   coalesce(split(col(arr_col), ','), array()).cast(ArrayType(DoubleType())))
        return data

    def build_weekday_snapshot_data(self, base_high_watermark_data):
        high_watermark_data = base_high_watermark_data.select("MaterialKey", "SnapshotDate", "CurrentWeekConsumption",
                                                              *self.data_provider.get_rolling_avg_consumption_list_columns())
        return self.add_rolling_avg_consumption(high_watermark_data)

    def add_rolling_avg_consumption(self, high_watermark_data, skip_last=False):
        for weeks_cnt in self.data_provider.ROLLING_AVG_CONSUMPTION_WEEKS:
            list_column_name = "Rolling{}wkAvgConsumptionList".format(weeks_cnt)
            value_column_name = "Rolling{}wkAvgConsumption".format(weeks_cnt)

            high_watermark_data = self.split_concat_array_col(high_watermark_data, [list_column_name]) \
                .withColumn(value_column_name,
                            self.rolling_average_udf(col(list_column_name), col("CurrentWeekConsumption"),
                                                     lit(skip_last))) \
                .drop(list_column_name)

        return high_watermark_data.fillna(0.0)

    def build_monday_snapshot_data(self, base_high_watermark_data, aurora_params):
        consigned_on_order, jabil_owned_on_order = self.data_provider.get_on_order_data(self.snapshot_date)
        prior_weekly_receipt_data = self.data_provider.get_prior_wkly_receipts_data(self.snapshot_date)
        prev_12_weeks_avg_data = self.data_provider.get_prev_12_weeks_avg_data(aurora_params,
                                                                               self.component_header_aurora_table_name,
                                                                               self.snapshot_date)

        high_watermark_data = base_high_watermark_data.join(
            consigned_on_order,
            (base_high_watermark_data['SnapshotDate'] == consigned_on_order['SnapshotDate']) &
            (base_high_watermark_data['PlantCode'] == consigned_on_order['PlantCode']) &
            (base_high_watermark_data['MaterialCode'] == consigned_on_order['MaterialCode']) &
            (base_high_watermark_data['DataSourceId'] == 6),
            how='left_outer').select(base_high_watermark_data['*'], consigned_on_order.ConsignedOnOrder)

        high_watermark_data = high_watermark_data.join(
            jabil_owned_on_order,
            (high_watermark_data['SnapshotDate'] == jabil_owned_on_order['SnapshotDate']) &
            (high_watermark_data['PlantCode'] == jabil_owned_on_order['PlantCode']) &
            (high_watermark_data['MaterialCode'] == jabil_owned_on_order['MaterialCode']) &
            (high_watermark_data['DataSourceId'] == 6),
            how='left_outer').select(high_watermark_data['*'], jabil_owned_on_order.JabilOwnedOnOrder)

        high_watermark_data = high_watermark_data.join(
            prior_weekly_receipt_data,
            (high_watermark_data['SnapshotDate'] == prior_weekly_receipt_data['SnapshotDate']) &
            (high_watermark_data['PlantCode'] == prior_weekly_receipt_data['PlantCode']) &
            (high_watermark_data['MaterialCode'] == prior_weekly_receipt_data['MaterialCode']) &
            (high_watermark_data['DataSourceId'] == 6),
            how='left_outer').select(high_watermark_data['*'], prior_weekly_receipt_data.PriorWeekReceipts)

        high_watermark_data = high_watermark_data.join(prev_12_weeks_avg_data, ['MaterialKey'], how='left_outer')

        high_watermark_data = self.split_concat_array_col(high_watermark_data,
                                                          ["Rolling13wkAvgGrossDemandList",
                                                           "Rolling13wkAvgLtGrossDemandList"])

        # skip today's CurrentWeekConsumption in avg calculations if snapshot is today
        is_сurrent_date = self.snapshot_date.date() == datetime.now().date()
        high_watermark_data = high_watermark_data \
            .withColumn("Rolling13wkAvgGrossDemand",
                        self.rolling_average_udf(col("Rolling13wkAvgGrossDemandList"), col("TotalGrossDemand"),
                                                 lit(False)))\
            .withColumn("Rolling13wkAvgLtGrossDemand",
                        self.rolling_average_udf(col("Rolling13wkAvgLtGrossDemandList"), col("TotalLtGrossDemand"),
                                                 lit(False))) \
            .drop("Rolling13wkAvgGrossDemandList", "Rolling13wkAvgLtGrossDemandList") \
            .fillna(0.0)

        high_watermark_data = self.add_rolling_avg_consumption(high_watermark_data, is_сurrent_date)

        return high_watermark_data

    def run_pipeline(self):
        if self.enable_logging:
            self.spark_utils.configure_logging(file_name="high_watermark")
        aurora_host, aurora_user, aurora_pwd = self.spark_utils.get_secrets(self.secrets_arn, self.region_name)

        base_high_watermark_data = self.data_provider.get_base_component_waterfall_data(self.s3_root_path,
                                                                                        self.snapshot_date)
        consumption_data = self.data_provider.get_consumption_data()

        base_high_watermark_data = base_high_watermark_data.join(
            consumption_data,
            (base_high_watermark_data['PlantCode'] == consumption_data['PlantCode']) &
            (base_high_watermark_data['MaterialCode'] == consumption_data['MaterialCode']) &
            (base_high_watermark_data['DataSourceId'] == 6),
            how="left_outer").select(base_high_watermark_data['*'], 'CurrentWeekConsumption',
                                     *self.data_provider.get_rolling_avg_consumption_list_columns())

        aurora_params = {"aurora_database_name": self.aurora_database_name, "aurora_pwd": aurora_pwd,
                         "aurora_table_name": self.aurora_table_name, "aurora_host": aurora_host,
                         "aurora_user": aurora_user, "snapshot_date": self.snapshot_date.strftime("%Y-%m-%d"),
                         "drop_snapshot_date": True, "snapshot_date_column": "SnapshotDate"}

        if self.week_day != MONDAY:
            # just update CurrentWeekConsumption and calculate RollingAvgConsumption
            high_watermark_data = self.build_weekday_snapshot_data(base_high_watermark_data)
            self.spark_utils.write_to_aurora(high_watermark_data,
                                             dict(aurora_params.items(),
                                                  **{'aurora_table_name': aurora_params['aurora_table_name']+'_stg'}))
            self.update_main_table(aurora_params)
        else:
            high_watermark_data = self.build_monday_snapshot_data(base_high_watermark_data, aurora_params)
            self.spark_utils.write_to_aurora(high_watermark_data, aurora_params)


if __name__ == "__main__":
    util_script_path, *configs = get_parameters()
    spark_session = SparkSession.builder.getOrCreate()
    spark_session.sparkContext.addPyFile(util_script_path)
    spark_util = import_module('spark_utils')

    high_watermark_data_provider = HighWatermarkDataProvider(spark_session, spark_util)
    high_watermark_pipeline = HighWatermarkPipeline(spark_session, high_watermark_data_provider, spark_util, configs)
    high_watermark_pipeline.run_pipeline()
