from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import StringType, DateType
from datetime import datetime
from importlib import import_module
import argparse


def get_parameters():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--snapshotdate", dest="snapshot_date", metavar="9999-01-01",
                        help="Date in Y-MM-DD format for which query needs to run. If no Date is provided it will "
                             "run for today", required=False)
    parser.add_argument("--target_s3_path", dest="target_s3_path", metavar="s3a://bucket_name/object_path",
                        help="Bucket and object path for writing result data", required=False)
    parser.add_argument("--s3_root_path", dest="s3_root_path", metavar="s3a://bucket_name/object_path",
                        help="Format of result data written in s3", required=False)
    parser.add_argument("--s3_output_format", dest="s3_output_format", metavar="s3a://bucket_name/object_path",
                        help="Format of result data written in s3", required=True)
    parser.add_argument("--loadtodb", dest="load_to_db", metavar="Y or N",
                        help="If Y, then we write to aurora, if N - to s3")
    parser.add_argument("--region_name", dest="region_name",
                        help="AWS Region")
    parser.add_argument("--secrets_arn", dest="secrets_arn",
                        help="Secrets name to retrieve Aurora Credentials", required=False)
    parser.add_argument("--aurora_database_name", dest="aurora_database_name",
                        help="Database name for material snapshot data")
    parser.add_argument("--aurora_table_name", dest="aurora_table_name",
                        help="Table name for material snapshot data")
    parser.add_argument("--util_script_path", dest="util_script_path",
                        help="Local path to util script")
    parser.add_argument("--data_source", dest="data_source", required=True,
                        help="Source of raw data: S3 or EIP")
    parser.add_argument("--enable_logging", dest="enable_logging", required=True,
                        help="Enable or disable logging into logfile")

    args = parser.parse_args()
    return args.snapshot_date, args.target_s3_path, args.s3_output_format, args.load_to_db, \
           args.aurora_database_name, args.aurora_table_name, args.secrets_arn, args.region_name, args.s3_root_path, \
           args.util_script_path, args.data_source, args.enable_logging


class DataReader:
    """ reading data from different sources """

    def __init__(self, spark, spark_util):
        self.spark = spark
        self.spark_utils = spark_util

    def read_s3_data(self, s3_root_path, snapshot_date, domain_path, columns, drop_material_code=True,
                     is_col_upper=False):
        s3path = s3_root_path + domain_path + \
                 "/YYYY=" + snapshot_date[:4] + "/MM=" + snapshot_date[5:7] + "/DD=" + snapshot_date[8:]
        data_df = self.spark.read.format("parquet").load(s3path).select(columns)

        if is_col_upper:
            data_df = self.spark_utils.columns_to_camel_case(data_df, columns)
            data_df = data_df.withColumnRenamed("dataSourceId", "datasourceid") \
                .withColumnRenamed("plantCode", "plantcode") \
                .withColumnRenamed("materialCode", "materialcode")

        data_df = data_df.withColumn("materialKey", concat(col("datasourceid"), lit("_"),
                                                           col("plantcode"), lit("_"),
                                                           col("materialcode")))
        if drop_material_code:
            data_df = data_df.drop('datasourceid', 'materialcode', 'plantcode')
        else:
            data_df = data_df.withColumnRenamed("datasourceid", "dataSourceId") \
                .withColumnRenamed("materialcode", "materialCode") \
                .withColumnRenamed("plantcode", "plantCode")
        return data_df.repartition("materialKey").repartition(200)

    def read_eip_data(self, query, drop_material_code=True):
        data = self.spark.sql(query)
        data = data.withColumn("materialKey", concat(col("dataSourceId"), lit("_"),
                                                     col("plantCode"), lit("_"),
                                                     col("materialCode")))
        if drop_material_code:
            data = data.drop('dataSourceId', 'materialCode', 'plantCode')
        return data.repartition("materialKey").repartition(200)


class DataProvider:

    def __init__(self, spark, spark_util, s3_root_path, data_source, snapshot_date):
        self.spark = spark
        self.s3_root_path = s3_root_path
        self.spark_utils = spark_util
        self.snapshot_date = snapshot_date
        self.data_source = data_source
        self.data_reader = DataReader(self.spark, spark_util)

    @staticmethod
    def aggregate_by_material_key(data, agg_columns, result_column_name):
        return data \
            .select("materialKey", struct(sorted(agg_columns)).alias(result_column_name)) \
            .groupBy("materialKey").agg(collect_list(result_column_name).alias(result_column_name))

    @staticmethod
    def not_material_key_columns(columns):
        return list(filter(lambda column_name: column_name.lower() not in ['datasourceid', 'plantcode',
                                                                           'materialcode', 'materialKey'], columns))

    def get_materials_data(self):
        if self.data_source == 'S3':
            materials_columns = ['DataSourceId', 'PlantCode', 'MaterialCode', 'CustomerGroupCode',
                                 'CustomerMaterialCode',
                                 'ProductGroupCode', 'MaterialDescription', 'MaterialTypeStdCode', 'AbcCode',
                                 'MaterialTypeCode', 'BuyerCode', 'UnitOfMeasureCode', 'DiscontinuationIndicator',
                                 'FollowUpMaterial', 'MakeBuy', 'ProfitCenter', 'DivisionName', 'SectorName',
                                 'CustomerName',
                                 'DeleteFlag', 'MinimumLotSize', 'MaximumLotSize', 'MultipleQuantity',
                                 'SafetyStockQuantity',
                                 'ReorderPointQuantity', 'MaximumStockQuantity', 'DockToStockLeadTime',
                                 'SafetyLeadTime',
                                 'SafetyTimeIndicator', 'FixedLeadTime', 'StandardUnitCostUSD', 'SellUnitPriceUSD',
                                 'LocalCurrencyToUsdExchangeRate',
                                 'PlanningTimeFence', 'StandardUnitCostP0', 'StandardUnitCostP1', 'SellUnitPriceP0',
                                 'SellUnitPriceP1',
                                 'AssemblyScrapCount', 'ComponentScrapCount', 'SafetyInStock', 'FixedLotSize',
                                 'StdUnitCostPlannedCurrent', 'MovingAverageUnitCost', 'StkValueQuantity',
                                 'StkValueCurrent',
                                 'StkValueMovingAverageWhenStandardPriceControl', 'StdUnitCostPlannedNext',
                                 'MlMovingAvgUnitCostUsd', 'snapshotdate',
                                 'MlCurrencyCode', 'LocalCurrencyCode', 'MlStkValueCurrentUsd',
                                 'MlStkValueMovingAvgWhenStdPriceControlUsd', 'MlStdUnitCostUsd', 'MlPriceUnit',
                                 'StkValueAtStdUnitCost', 'StkValueAtMovingAvgCost', 'MlStkValueAtStdUnitCostUsd',
                                 'MlStkValueAtMovingAvgCostUsd', 'QuotaArrangementUsage',
                                 'DiscontinuationEffectiveOutDate']
            materials_data = self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date,
                                                           "dimensions/materials", materials_columns,
                                                           drop_material_code=False, is_col_upper=True) \
                .withColumnRenamed("snapshotdate", "snapshotDate")
        else:
            sql = "select datasourceid as dataSourceId, plantcode as plantCode, materialcode as materialCode," \
                  "customergroupcode as customerGroupCode, customermaterialcode as customerMaterialCode," \
                  "productgroupcode as productGroupCode, materialdescription as materialDescription," \
                  "materialtypestdcode as materialTypeStdCode, abccode as abcCode, materialtypecode as materialTypeCode, " \
                  "buyercode as buyerCode, unitofmeasuredscode as unitOfMeasureCode, " \
                  "discontinuationindicator as discontinuationIndicator, followupmaterial as followUpMaterial," \
                  "makebuy as makeBuy, profitcenter as profitCenter, divisionname as divisionName, sectorname as sectorName," \
                  "customername as customerName, case when deleteflag = 'X' then 1 else 0 end as deleteFlag," \
                  "minimumlotsize as minimumLotSize, maximumlotsize as maximumLotSize, multipleqty as multipleQuantity," \
                  "safetystockqty as safetyStockQuantity, reorderpointqty as reorderPointQuantity," \
                  "maximumstockqty as maximumStockQuantity, docktostockleadtime as dockToStockLeadTime," \
                  "safetyleadtime as safetyLeadTime, cast(safetytimeindicator as int) as safetyTimeIndicator," \
                  "fixedleadtime as fixedLeadTime, standardunitcostusd as standardUnitCostUSD, " \
                  "sellunitpriceusd as sellUnitPriceUSD, localcurrencytousdexchangerate as localCurrencyToUsdExchangeRate," \
                  "planningtimefence as planningTimeFence, stdunitcostp0 as standardUnitCostP0, " \
                  "stdunitcostp1 as standardUnitCostP1, sellunitpricep0 as sellUnitPriceP0, " \
                  "sellunitpricep1 as sellUnitPriceP1, assemblyscrappct as assemblyScrapCount, " \
                  "componentscrappct as componentScrapCount, cast(safetyinstock as int) as safetyInStock, " \
                  "cast(fixedlotsize as int) as fixedLotSize, stdunitcostplannedcurrent as stdUnitCostPlannedCurrent," \
                  "movingavgunitcost as movingAverageUnitCost, stkvaluedqty as stkValueQuantity, " \
                  "stkvaluecurrent as stkValueCurrent, mlstkvaluecurrentusd as mlStkValueCurrentUsd, " \
                  "stkvaluemovingavgwhenstdpricecontrol as stkValueMovingAverageWhenStandardPriceControl," \
                  "stdunitcostplannednext as stdUnitCostPlannedNext,mlmovingavgunitcostusd as mlMovingAvgUnitCostUsd, " \
                  "'%s' as snapshotDate, mlcurrencycode as mlCurrencyCode, localcurrencycode as localCurrencyCode," \
                  "mlstkvaluemovingavgwhenstdpricecontrolusd as mlStkValueMovingAvgWhenStdPriceControlUsd," \
                  "mlstdunitcostusd as mlStdUnitCostUsd, mlpriceunit as mlPriceUnit," \
                  "stkvalueatstdunitcost as stkValueAtStdUnitCost, stkvalueatmovingavgcost as stkValueAtMovingAvgCost," \
                  "mlstkvalueatstdunitcostusd as mlStkValueAtStdUnitCostUsd, " \
                  "mlstkvalueatmovingavgcostusd as mlStkValueAtMovingAvgCostUsd, " \
                  "quotaarrangementusage as quotaArrangementUsage," \
                  "case when discontinuationeffectiveoutdate = '00000000' then NULL " \
                  "else concat_ws('-', substr(discontinuationeffectiveoutdate,1,4), " \
                  "substr(discontinuationeffectiveoutdate,5,2), substr(discontinuationeffectiveoutdate,7) ) " \
                  "end as discontinuationEffectiveOutDate " \
                  " from dimensions.vw_sl_materials" % self.snapshot_date
            materials_data = self.data_reader.read_eip_data(sql, drop_material_code=False)

        return materials_data

    def get_inactive_bom_data(self):
        if self.data_source == 'S3':
            inactive_bom_columns = ['DataSourceID', 'PlantCode', 'MaterialCode']
            inactive_bom_data = self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date,
                                                              "incontrol/inactivebom", inactive_bom_columns)
        else:
            sql = "select datasourceid as dataSourceId, plantcode as plantCode, materialcode as materialCode " \
                  "from incontrol.vw_sl_inactive_bom_materials"
            inactive_bom_data = self.data_reader.read_eip_data(sql)

        inactive_bom_data = inactive_bom_data.withColumn("inactiveBom", lit(True))
        return inactive_bom_data

    def get_agedinventory_data(self):
        if self.data_source == "S3":
            agedinventory_columns = ['datasourceid', 'plantcode', 'materialcode', 'onhandquantitynonconsigned',
                                     'onhandquantityconsigned', 'totalonhandquantity', 'inventorytypestdcode',
                                     'netmvmtquantitynonconsigned', 'totalmvmtquantity', 'agenonconsigned', 'totalage',
                                     'standardunitcost', 'posteddts']
            agedinventory_data = self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date,
                                                               "scm/agedinventory",
                                                               agedinventory_columns) \
                .withColumnRenamed("onhandquantitynonconsigned", "onHandQuantityNonConsigned") \
                .withColumnRenamed("onhandquantityconsigned", "onHandQuantityConsigned") \
                .withColumnRenamed("totalonhandquantity", "totalOnHandQuantity") \
                .withColumnRenamed("inventorytypestdcode", "inventoryTypeStdCode") \
                .withColumnRenamed("netmvmtquantitynonconsigned", "netMvmtQuantityNonConsigned") \
                .withColumnRenamed("totalmvmtquantity", "totalMvmtQuantity") \
                .withColumnRenamed("agenonconsigned", "ageNonConsigned") \
                .withColumnRenamed("totalage", "totalAge") \
                .withColumnRenamed("standardunitcost", "standardUnitCost") \
                .withColumnRenamed("posteddts", "postingDate")
        else:
            sql = "select datasourceid as dataSourceId, " \
                  " plantcode as plantCode, " \
                  " materialcode as materialCode, " \
                  " onhandquantitynonconsigned as onHandQuantityNonConsigned," \
                  " onhandquantityconsigned as onHandQuantityConsigned," \
                  " totalonhandquantity as totalOnHandQuantity," \
                  " 'NULL' as inventoryTypeStdCode," \
                  " netmvmtquantitynonconsigned as netMvmtQuantityNonConsigned," \
                  " totalmvmtquantity as totalMvmtQuantity," \
                  " agenonconsigned as ageNonConsigned," \
                  " totalage as totalAge," \
                  " standardunitcost as standardUnitCost," \
                  " posteddts as postingDate from incontrol.vw_sl_agedinventory_tmp"
            agedinventory_data = self.data_reader.read_eip_data(sql)

        return agedinventory_data.cache()

    def get_shipment_data(self):
        if self.data_source == 'S3':
            shipment_columns = ['DataSourceID', 'MaterialCode', 'PlantCode', 'MaxPostedDts', 'SnapshotDate']
            shipment_data = self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date, "incontrol/shipment",
                                                          shipment_columns,
                                                          is_col_upper=True)
        else:
            sql = "select datasourceid as dataSourceId, " \
                  "materialcode as materialCode, " \
                  "plantcode as plantCode, " \
                  "'%(snapshot_date)s' as snapshotDate," \
                  "coalesce(cast(max(posteddts) as string),'') as maxPostedDts " \
                  " from incontrol.vw_sl_shipmentdate  " \
                  "group by datasourceid, materialcode, plantcode , " \
                  "profitcenter, concat_ws('-', profitcenter, plantcode), '$(snapshot_date)s'" \
                  % {'snapshot_date': self.snapshot_date}
            shipment_data = self.data_reader.read_eip_data(sql)
        shipment_data = self.aggregate_by_material_key(shipment_data, ['maxPostedDts', 'snapshotDate'], "shipment")
        return shipment_data

    def get_demand_data(self):
        if self.data_source == 'S3':
            on_order_columns = ['datasourceid', 'materialcode', 'plantcode', 'mrptypestdcode', 'deliveryfinishdts',
                                'receiptrequirementdts', 'quantity', 'cancellationleadtime', 'ncnrflag',
                                'processingrule']
            mrp_data = self.data_reader\
                .read_s3_data(self.s3_root_path, self.snapshot_date, "scm/mrp", on_order_columns) \
                .withColumnRenamed("mrptypestdcode", "mrpTypeStdCode") \
                .withColumnRenamed("deliveryfinishdts", "deliveryFinishDts") \
                .withColumnRenamed("receiptrequirementdts", "receiptRequirementDts") \
                .withColumnRenamed("cancellationleadtime", "cancellationLeadTime") \
                .withColumnRenamed("ncnrflag", "ncnrFlag") \
                .withColumnRenamed("processingrule", "processingRule")
        else:
            sql = "select datasourceid as dataSourceId, " \
                  "materialcode as materialCode, " \
                  "plantcode as plantCode, " \
                  "mrptypestdcode as mrpTypeStdCode, " \
                  "deliveryfinishdts as deliveryFinishDts, " \
                  "receiptrequirementdts as receiptRequirementDts, " \
                  "quantity, " \
                  "cancellationleadtime as cancellationLeadTime, " \
                  "ncnrflag as ncnrFlag, " \
                  "processingrule as processingRule " \
                  "from incontrol.vw_sl_mrp_tmp " \
                  "where mrptypestdcode != 'SubContractor Requirement' OR ( mrpplanningsegment != '' " \
                  "AND mrpplanningsegment IS NOT NULL)"
            mrp_data = self.data_reader.read_eip_data(sql)
        return mrp_data.cache()


class MaterialSnapshotPipeline:

    def __init__(self, spark, spark_util, data_provider, *args):
        self.spark = spark
        self.snapshot_date, self.target_s3_path, self.s3_output_format, self.load_to_db, self.aurora_database_name, \
            self.aurora_table_name, self.secrets_arn, self.region_name, self.s3_root_path, \
            self.util_script_path, self.data_source, self.enable_logging = args
        self.spark_utils = spark_util
        self.data_reader = DataReader(spark, spark_util)
        self.snapshot_date = self.snapshot_date if self.snapshot_date else datetime.today().strftime("%Y-%m-%d")
        self.data_provider = data_provider
        if self.enable_logging == 'True':
            self.spark_utils.configure_logging(file_name="material_snapshot")

    def get_on_order_data(self, mrp_data, materials_lead_time):
        on_order_data = mrp_data \
            .join(materials_lead_time, ["materialKey"]) \
            .withColumn("deliveryFinishDts", col("deliveryFinishDts").cast(DateType())) \
            .withColumn("leadTimeLimit", expr('date_add(snapshotDate, leadTimeTotal)')) \
            .filter((col("quantity") > 0) & ((col("mrpTypeStdCode") == 'Purchase Order') |
                                             ((col(
                                                 "mrpTypeStdCode") == 'Purchase Agreement') & (
                                                      col("deliveryFinishDts") < col("leadTimeLimit"))))
                    ) \
            .drop("leadTimeLimit", "leadTimeTotal", "snapshotDate") \
            .cache()

        on_order_total = on_order_data.select('materialKey', 'quantity').groupby("materialKey") \
            .agg(sum("quantity").alias("onOrderTotal"))

        on_order_struct_columns = self.data_provider.not_material_key_columns(on_order_data.columns)
        on_order_data = self.data_provider.aggregate_by_material_key(on_order_data, on_order_struct_columns, "onOrder")
        on_order_data.unpersist()
        return {"total": on_order_total, "summary_data": on_order_data}

    def get_on_hand_data(self, aged_inventory_data):
        agedinventory_material_data = aged_inventory_data.select("materialKey", "onHandQuantityNonConsigned",
                                                                 "onHandQuantityConsigned", "totalOnHandQuantity") \
            .groupby("materialKey") \
            .agg(first("onHandQuantityNonConsigned").alias("onHandQuantityNonConsigned"),
                 first("onHandQuantityConsigned").alias("onHandQuantityConsigned"),
                 first("totalOnHandQuantity").alias("totalOnHandQuantity")) \
            .withColumn("onHandTotal", col("onHandQuantityNonConsigned"))

        agedinventory_data = aged_inventory_data.drop("onHandQuantityNonConsigned",
                                                      "onHandQuantityConsigned",
                                                      "totalOnHandQuantity")
        agedinventory_columns = self.data_provider.not_material_key_columns(agedinventory_data.columns)
        on_hand_data = self.data_provider.aggregate_by_material_key(agedinventory_data, agedinventory_columns, "onHand")
        agedinventory_data.unpersist()
        return {"total": agedinventory_material_data, "summary_data": on_hand_data}

    def get_demand_summary_data(self, mrp_data):
        regular_mrp_data = mrp_data.filter(upper(mrp_data.processingRule) == 'REGULAR')

        demand_sales_order_quantity = regular_mrp_data \
            .filter(col("mrpTypeStdCode") == 'Sales Order') \
            .groupBy("materialKey").agg(sum("quantity").alias("demandSalesOrderQuantity"))

        demand_summary_data = regular_mrp_data \
            .groupby('materialKey', 'deliveryFinishDts') \
            .agg(sum(when(col("mrpTypeStdCode").isin(['Delivery', 'Independent Requirement',
                                                      'Sales Agreement', 'Sales Order']),
                          col("quantity")).otherwise(lit(0)))
                 .alias("inDepQuantity"),
                 sum(when(col("mrpTypeStdCode").isin(['Allocation', 'Backflush Dependent Requirement',
                                                      'Dependent Requirement', 'Dependent Reservation',
                                                      'Interplant Transfer Order', 'SubContractor Requirement']),
                          col("quantity")).otherwise(lit(0)))
                 .alias("depQuantity")).cache()

        demand_total = demand_summary_data.groupby("materialKey"). \
            agg(sum(col("depQuantity") + col("inDepQuantity")).alias("demandTotal"))

        demand_summary = self.data_provider.aggregate_by_material_key(demand_summary_data,
                                                                      ['deliveryFinishDts', 'inDepQuantity',
                                                                       'depQuantity'],
                                                                      "demand")
        demand_summary_data.unpersist()
        return {"total": demand_total, "summary_data": demand_summary,
                "sales_order_quantity": demand_sales_order_quantity}

    @staticmethod
    def get_demand_in_lead_time(materials_with_demand):
        return materials_with_demand \
            .select("materialKey", "snapshotDate", "leadTimeTotal", explode("demand").alias("demandColumn")) \
            .filter(datediff(to_date(col("demandColumn.deliveryFinishDts"), "yyyy-MM-dd HH:mm:ss"),
                             to_date(col("snapshotDate"), "yyyy-MM-dd")) - 1 <= col("leadTimeTotal")) \
            .withColumn("demandSum", col("demandColumn.inDepQuantity") + col("demandColumn.depQuantity")) \
            .groupby("materialKey") \
            .agg(sum(col("demandSum")).alias("demandInLeadTime")) \
            .select("materialKey", "demandInLeadTime")

    def get_base_material_object(self, materials_data, mrp_data, on_hand_data, on_order_data):
        inactive_bom_data = self.data_provider.get_inactive_bom_data()
        demand_summary_data = self.get_demand_summary_data(mrp_data)

        materials_object_data = materials_data \
            .join(inactive_bom_data, ['materialKey'], how='left_outer') \
            .join(on_hand_data['total'], ['materialKey'], how='left_outer') \
            .join(on_order_data['total'], ['materialKey'], how='left_outer') \
            .join(demand_summary_data['total'], ['materialKey'], how='left_outer') \
            .join(demand_summary_data['sales_order_quantity'], ['materialKey'], how='left_outer') \
            .withColumn("inactiveBom", when(col("inactiveBom").isNotNull(), col("inactiveBom")).otherwise(lit(False))) \
            .join(demand_summary_data['summary_data'], ['materialKey'], how="left_outer") \
            .cache()

        demand_in_lead_time = self.get_demand_in_lead_time(materials_object_data)
        materials_object_data = materials_object_data \
            .join(demand_in_lead_time, ['materialKey'], "left_outer") \
            .fillna(0, subset=["demandSalesOrderQuantity", "onHandQuantityNonConsigned", "onHandQuantityConsigned",
                               "totalOnHandQuantity", "demandTotal",
                               "onOrderTotal", "onHandTotal", "demandInLeadTime"]) \
            .withColumn("inventoryTotal", col("onHandTotal") + col("onOrderTotal")) \
            .cache()
        return materials_object_data

    def write_material_snapshot_data(self, materials_object_data, s3_params, aurora_params):
        snapshot_json_cols = ['shipment', 'onOrder', 'onHand', 'demand']
        for snapshot_col in snapshot_json_cols:
            materials_object_data = materials_object_data.withColumn(snapshot_col, to_json(snapshot_col))
        aurora_params['aurora_table_name'] = self.aurora_table_name
        if self.load_to_db == "Y":
            self.spark_utils.write_to_aurora(materials_object_data, aurora_params)
        else:
            data = materials_object_data.withColumn("profitplant",
                                                    concat(col("profitCenter"), lit("-"), col("plantCode")))
            if s3_params['s3_output_format'] == 'json':
                data = data.select("materialKey", "profitplant", struct(data.columns).alias("material"))
            self.spark_utils.write_to_s3(data, s3_params)

    def run_pipeline(self):
        self.spark_utils.logging.info("Snapshot date:   %s" % self.snapshot_date)
        self.spark_utils.logging.info("S3 target path:   %s" % self.target_s3_path)
        self.spark_utils.logging.info("S3 output format:   %s" % self.s3_output_format)

        materials_data = self.data_provider.get_materials_data() \
            .withColumn("snapshotDate", col('snapshotDate').cast(StringType()).substr(1, 10)) \
            .withColumn("snapshotDate", col("snapshotDate").cast(DateType())) \
            .withColumn("leadTimeTotal",
                        coalesce(col("fixedLeadTime"), lit(0)) + coalesce(col("dockToStockLeadTime"), lit(0)) +
                        when(col("safetyTimeIndicator").isin([1, 2]), col("safetyLeadTime")).otherwise(lit(0)))
        mrp_data = self.data_provider.get_demand_data()
        shipment_data = self.data_provider.get_shipment_data()
        agedinventory_data = self.data_provider.get_agedinventory_data()
        on_hand_data = self.get_on_hand_data(agedinventory_data)
        on_order_data = self.get_on_order_data(mrp_data,
                                               materials_data.select("materialKey", "leadTimeTotal", "snapshotDate"))

        materials_object_data = self.get_base_material_object(materials_data, mrp_data,
                                                              on_hand_data, on_order_data)

        aurora_host, aurora_user, aurora_pwd = self.spark_utils.get_secrets(self.secrets_arn, self.region_name)
        aurora_params = {"aurora_database_name": self.aurora_database_name, "aurora_host": aurora_host,
                         "aurora_user": aurora_user, "aurora_pwd": aurora_pwd, "snapshot_date": self.snapshot_date,
                         "snapshot_date_column": "snapshotDate"}

        materials_object_data = materials_object_data \
            .join(shipment_data, ['materialKey'], "left_outer") \
            .join(on_order_data['summary_data'], ['materialKey'], "left_outer") \
            .join(on_hand_data['summary_data'], ['materialKey'], "left_outer")

        s3path = self.target_s3_path + "/YYYY=" + self.snapshot_date[:4] + \
                 "/MM=" + self.snapshot_date[5:7] + "/DD=" + self.snapshot_date[8:]
        s3_params = {"s3_output_format": self.s3_output_format, "s3path": s3path, "s3_folder_name": None,
                     "is_partitioned": True, "partition_column": "profitplant"}
        self.write_material_snapshot_data(materials_object_data, s3_params, aurora_params)
        self.spark_utils.logging.info("Process Completed")


if __name__ == "__main__":
    snapshotdate, target_s3_path, s3_output_format, load_to_db, \
        aurora_database_name, aurora_table_name, secrets_arn, region_name, s3_root_folder, \
        util_script_path, raw_data_source, enable_logging = get_parameters()
    
    spark_session = SparkSession.builder.getOrCreate()
    spark_session.sparkContext.addPyFile(util_script_path)
    spark_utils = import_module('spark_utils')
    grid_data_provider = DataProvider(spark_session, spark_utils, s3_root_folder, raw_data_source, snapshotdate)
    pipeline_configs = (snapshotdate, target_s3_path, s3_output_format, load_to_db,
                        aurora_database_name, aurora_table_name, secrets_arn, region_name, s3_root_folder,
                        util_script_path, raw_data_source, enable_logging)
    data_grid_pipeline = MaterialSnapshotPipeline(spark_session, spark_utils, grid_data_provider, *pipeline_configs)
    data_grid_pipeline.run_pipeline()
