from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder.enableHiveSupport().getOrCreate()
spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation", "true")

ihs_pricing_landing = spark.sql("SELECT part_objectid,manufacturer_objectid,manufacturer_part_number, \
    manufacturer_full_name,average_price,lytica_price,updated_on from incontrol.vw_ihs_pricing  ")

ihs_pricing_landing.write.format("parquet").mode("overwrite").saveAsTable("incontrol.ihs_pricing_landing")

ihs_basic_landing = spark.sql("SELECT objectid,manufacturer_part_number,manufacturer_name,part_description, \
    mfr_package_description,reach_compliant,eu_rohs_compliant,china_rohs_compliant,manufacturer_url,status,category,datasheet_url,updated_on from incontrol.vw_ihs_basic ")

ihs_basic_landing.write.format("parquet").mode("overwrite").saveAsTable("incontrol.ihs_basic_landing")

ihs_lifecycle_landing = spark.sql("SELECT part_objectid,manufacturer_objectid,upper(trim(manufacturer_part_number)) as manufacturer_part_number, \
    upper(trim(manufacturer_full_name)) as manufacturer_full_name,part_status,life_cycle_stage, life_cycle_code,date_of_intro,availabilityyteol, \
    estimated_yteol,alert_prediction_date,life_cycle_comments, life_cycle_information_source, updated_on FROM incontrol.vw_ihs_lifecycle")

ihs_lifecycle_landing.write.format("parquet").mode("overwrite").saveAsTable("incontrol.ihs_lifecycle_landing")

cds_df = spark.sql("select distinct upper(trim(cds.corporationdsname)) as corporationdsname, upper(trim(c.corporationname)) AS manufacturer_name \
    from persistent.jabildb_corporationds   cds \
    INNER JOIN persistent.jabildb_corporation c ON cds.corporationid = c.corporationid  \
    WHERE cds.datasourceid = 21 AND cds.deleteflag = 'false'").createOrReplaceTempView('cds')

query = """SELECT lc.part_objectid AS part_objectid, 
        lc.manufacturer_part_number, 
       cds.manufacturer_name,  
       b.part_description,  
       b.mfr_package_description,  
       b.reach_compliant,  
       b.eu_rohs_compliant,  
       b.china_rohs_compliant, 
       b.manufacturer_url,  
       b.status AS status,  
       b.category,  
       b.datasheet_url, 
       lc.life_cycle_stage, 
       CASE 
           WHEN b.status IN ('Discontinued',
                             'Discontinued-Unconfirmed',
                             'Transferred') 
                THEN '5' 
           ELSE 
                lc.life_cycle_code 
       END AS life_cycle_code,
       case when lc.date_of_intro='' then NULL else lc.date_of_intro end as date_of_intro,
        CASE 
           WHEN b.status IN ('Discontinued',
                             'Discontinued-Unconfirmed',
                             'Transferred') 
                THEN '0' 
           ELSE 
                 lc.availabilityyteol
       END AS availabilityyteol,
       
        CASE 
           WHEN b.status IN ('Discontinued',
                             'Discontinued-Unconfirmed',
                             'Transferred') 
                THEN '0' 
           ELSE 
                 lc.estimated_yteol
       END AS estimated_yteol,
       lc.alert_prediction_date, 
       lc.life_cycle_comments, 
       lc.life_cycle_information_source, 
       p.average_price, 
       p.lytica_price,
       b.updated_on,
       row_number() over (partition by lc.manufacturer_part_number, cds.manufacturer_name order by b.status asc,  b.updated_on desc, lc.estimated_yteol desc, lc.part_objectid desc ) rownum
FROM incontrol.ihs_lifecycle_landing lc
LEFT OUTER JOIN cds ON lc.manufacturer_full_name = cds.corporationdsname
LEFT OUTER JOIN incontrol.ihs_basic_landing b ON lc.part_objectid = b.objectid 
LEFT OUTER JOIN incontrol.ihs_pricing_landing p ON p.part_objectid = lc.part_objectid
AND p.manufacturer_objectid = lc.manufacturer_objectid """
ihs_lifecycle = spark.sql(query)

ihs_lifecycle_final = ihs_lifecycle.filter(col("rownum") == 1).drop("rownum").withColumn("status", when((col("estimated_yteol") == 0) ,"Discontinued").otherwise(col("status")))

ihs_lifecycle_final.write.format("parquet").mode("overwrite").saveAsTable("incontrol.ihs_lifecycle")
