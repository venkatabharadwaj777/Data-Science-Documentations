from mysql.connector import MySQLConnection, Error
from datetime import datetime
from pyspark.sql.functions import col
import logging
import boto3
import json


def configure_logging(file_name):
    logfile = "/eip_interfaces/logs/inControl/incontrol_dataingest_" + file_name + "_logfile_" \
              + datetime.now().strftime('%Y-%m-%d_%H-%M.log')
    fmt = '%(asctime)s %(message)s'
    logging.basicConfig(filename=logfile, level=logging.INFO, format=fmt)


def get_secrets(secretsarn, region_name):
    logging.info("Retrieve Aurora Credentials")
    secret_name = secretsarn
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name)
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    secret = get_secret_value_response['SecretString']
    parsed_secret = json.loads(secret)
    host = parsed_secret['host']
    user = parsed_secret['username']
    pwd = parsed_secret['password']
    return host, user, pwd


def read_s3_data(spark, s3_root_path, domain_path, columns, is_partitioned=True, snapshot_date=None):
    s3path = s3_root_path + domain_path
    if is_partitioned:
        s3path = s3path + "/YYYY=" + snapshot_date[:4] + "/MM=" + snapshot_date[5:7] + "/DD=" + snapshot_date[8:]
    data_df = spark.read.format("parquet").load(s3path).select(columns)
    return data_df


def drop_table_snapshot_records(snapshot_date, snapshot_date_column, database, table, host, user, password):
    sql_query = "DELETE FROM %s WHERE %s = '%s'" % (table, snapshot_date_column, snapshot_date)
    run_sql_query(sql_query, database, host, user, password)


def run_sql_query(query, database, host, user, password):
    try:
        conn = MySQLConnection(host=host, database=database, user=user, password=password)
        cursor = conn.cursor()
        cursor.execute(query)
        conn.commit()
    except Error as error:
        logging.error("Failed on executing the query: %s" % query)
        raise Exception(error)
    finally:
        cursor.close()
        conn.close()


def rename_columns(data, columns_mapping):
    for old_name, new_name in columns_mapping.items():
        data = data.withColumnRenamed(old_name, new_name)
    return data


def cast_cols_to_type(data, columns, data_type):
    for col_name in columns:
        data = data.withColumn(col_name, col(col_name).cast(data_type))
    return data


def write_to_aurora(df, aurora_params):
    host = aurora_params['aurora_host']
    database_name = aurora_params['aurora_database_name']
    table_name = aurora_params['aurora_table_name']
    user = aurora_params['aurora_user']
    password = aurora_params['aurora_pwd']
    logging.info("Writing data to Aurora")
    logging.info(host)
    url = "jdbc:mysql://%s/%s?useServerPrepStmts=false&rewriteBatchedStatements=true&" \
          "useUnicode=yes&characterEncoding=UTF-8" % (host, database_name)
    logging.info(url)
    if aurora_params.get("drop_snapshot_date", True):
        drop_table_snapshot_records(aurora_params['snapshot_date'], aurora_params['snapshot_date_column'],
                                    database_name, table_name, host, user, password)
    df.write.format('jdbc').options(url=url, driver="com.mysql.jdbc.Driver", dbtable=table_name,
                                                        user=user, password=password).mode('append').save()


def write_to_s3(df, s3_params):
    if s3_params['is_partitioned']:
        df.repartition(s3_params['partition_column']).write.partitionBy(s3_params['partition_column']) \
            .mode('overwrite') \
            .format(s3_params['s3_output_format']) \
            .save(s3_params['s3path'], header='true')
    else:
        df.coalesce(1).write.mode("overwrite").format(s3_params['s3_output_format'])\
            .save(s3_params['s3path'])


def publish_sns_message(topic_name, region_name, subject, message_text):
    client = boto3.client('sns', region_name=region_name)
    return client.publish(TopicArn=topic_name, Message=message_text,
                          Subject=subject)


def columns_to_camel_case(data, columns):
    for data_col in columns:
        data = data.withColumnRenamed(data_col, data_col[0].lower() + data_col[1:])
    return data


def columns_to_pascal_case(data, columns):
    for data_col in columns:
        data = data.withColumnRenamed(data_col, data_col[0].upper() + data_col[1:])
    return data


def column_names_drop_whitespaces(data):
    for data_col in data.columns:
        data = data.withColumnRenamed(data_col, data_col.replace(" ", ""))
    return data


def update_snapshot_table(snapshot_date, aurora_params):
    table_name = aurora_params['aurora_table_name'].replace("_stg", "")
    sql = "INSERT INTO LatestSnapshot (TableName, LatestSnapshotDate) VALUES ('{table_name}', '{snapshot_date}') " \
          "ON DUPLICATE KEY UPDATE LatestSnapshotDate=IF(LatestSnapshotDate < VALUES(LatestSnapshotDate), " \
          "VALUES(LatestSnapshotDate), LatestSnapshotDate)"\
        .format(table_name=table_name, snapshot_date=snapshot_date)
    run_sql_query(sql, aurora_params['aurora_database_name'], aurora_params['aurora_host'],
                  aurora_params['aurora_user'], aurora_params['aurora_pwd'])

