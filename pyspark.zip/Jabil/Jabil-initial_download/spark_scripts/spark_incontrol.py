# This will be called from the bash wrapper script
from pyspark.sql import SQLContext
from pyspark import SparkContext
from datetime import datetime
import argparse


def get_parameters():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--sqlfile", dest="sqlfilename",
                        help="Name of the SQL File that has the Query for extraction. "
                             "File needs to be passed in the spark submit --files", metavar="FILE", required=True)
    parser.add_argument("--partition", dest="partition",
                        help="Y or N. If Y , --snapshotdt has to be provided. if N , full table is extracted",
                        metavar="N Y", required=True)
    parser.add_argument("--snapshotdt", dest="snapshotdt", metavar="9999-01-01",
                        help="Date in Y-MM-DD format for which query needs to run."
                             "If no Date is provided it will run for Yesterday", default=get_currentdate(),
                        required=False)
    parser.add_argument("--outputformat", dest="outputformat", metavar="CSV",
                        help="CSV or PARQUET", default='parquet')
    parser.add_argument("--S3Path", dest="S3Path",
                        help="S3 Bucket Name default  is jbl-lab-incontrol-use1-data-001/data",
                        default='jbl-lab-incontrol-use1-data-001/data')
    parser.add_argument("--dbtable", dest="dbtable",
                        help="Database Table Name on the target DB. If blank do not load into DB")
    parser.add_argument("--aurora_database_name", dest="aurora_database_name",
                        help="Database Table Name on the target DB. If blank do not load into DB")
    parser.add_argument("--secretsarn", dest="secretsarn",
                        help="Secrets name to retrieve Aurora Credentials")
    parser.add_argument("--region_name", dest="region_name",
                        help="AWS Region")
    parser.add_argument("--s3export_error_topic", dest="s3export_error_topic",
                        help="SNS Error Topic EIP ETL")
    parser.add_argument("--cluster_env", dest="cluster_env",
                        help="Environment name")
    parser.add_argument("--enable_error_notifications", dest="enable_error_notifications", default='false',
                        help="Enable or disable sns notifications on error")
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS,
                        help='This code accepts following paramsShow this help message and exit.')
    parser.add_argument("--util_script_path", dest="util_script_path",
                        help="Local path to util script")
    parser.add_argument("--update_latest_snapshot", dest="update_latest_snapshot",
                        help="Enable or disable updating LatestSnapshot table record")
    args = parser.parse_args()
    return (args.sqlfilename, args.partition, args.snapshotdt, args.outputformat, args.S3Path, args.dbtable,
            args.secretsarn, args.region_name, args.s3export_error_topic, args.cluster_env,
            args.enable_error_notifications, args.aurora_database_name, args.util_script_path,
            args.update_latest_snapshot)


def get_currentdate():
    currdate = (datetime.now()).strftime('%Y-%m-%d')
    return currdate


def format_sql(sqlfilename, snapshotdt, partition):
    with open(sqlfilename, 'r') as myfile:
        sqlstmt = myfile.read().replace('\n', '')
    if partition == 'Y' and snapshotdt != 'N':
        whereclause = ' where snapshotdate=\'' + snapshotdt + '\''
        sqlstmt = sqlstmt + whereclause
        sqlstmt = sqlstmt.replace("current_date", "'" + snapshotdt + "'")
    elif partition == 'Y' and snapshotdt == 'N':
        sqlstmt = sqlstmt
    else:
        sqlstmt = sqlstmt
    return sqlstmt


def write_to_s3_parition(partition, s3path, snapshotdt, outputformat, df, spark_utils):
    s3path = s3path if snapshotdt == 'N' else \
        s3path + "/YYYY=" + snapshotdt[:4] + "/MM=" + snapshotdt[5:7] + "/DD=" + snapshotdt[8:]
    s3_params = {"s3_output_format": outputformat, "s3path": s3path,
                 "is_partitioned": (partition == 'Y'), "partition_column": "profitplant"}
    spark_utils.write_to_s3(df, s3_params)


def main():
    sqlfilename, partition, snapshotdt, outputformat, s3path, dbtable, secretsarn, \
        region_name, s3export_error_topic, cluster_env, \
        enable_error_notifications, aurora_database_name, util_script_path, update_latest_snapshot = get_parameters()
    extraction_proc_name = sqlfilename.split('.')[0]
    sc = SparkContext()
    sc.addPyFile(util_script_path)
    import spark_utils
    spark_utils.configure_logging(extraction_proc_name)
    sc.setLocalProperty("callSite.short", "Incontrol Data to S3")
    sql_context = SQLContext(sc)
    finalquery = format_sql(sqlfilename, snapshotdt, partition)
    spark_utils.logging.info(finalquery)
    data = sql_context.sql(finalquery).cache()
    records_count = data.count()
    spark_utils.logging.info("Records count :    " + str(records_count))
    host, user, pwd = spark_utils.get_secrets(secretsarn, region_name)
    aurora_params = {"aurora_database_name": aurora_database_name,
                     "aurora_table_name": dbtable,
                     "aurora_host": host, "aurora_user": user, "aurora_pwd": pwd,
                     "snapshot_date": snapshotdt, "drop_snapshot_date": False}
    if records_count != 0:
        write_to_s3_parition(partition, s3path, snapshotdt, outputformat, data, spark_utils=spark_utils)
        if dbtable:
            spark_utils.write_to_aurora(data, aurora_params)
    else:
        enable_error_notifications = enable_error_notifications.lower() == 'true'
        if enable_error_notifications:
            spark_utils.logging.error("Zero records fetched")
            message_text = "Zero records fetched during extraction of " + extraction_proc_name
            subject = cluster_env.upper() + ' : Error during s3export'
            spark_utils.publish_sns_message(s3export_error_topic, region_name, subject, message_text)
    spark_utils.logging.info("Process Completed")
    if update_latest_snapshot == "True":
        spark_utils.logging.info("Updating LatestSnapshot table")
        spark_utils.update_snapshot_table(get_currentdate() if
                                          (snapshotdt == 'N' or (snapshotdt is None)) else snapshotdt,
                                          aurora_params)


if __name__ == "__main__":
    main()
