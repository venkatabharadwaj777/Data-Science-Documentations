from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import FloatType
from datetime import datetime, timedelta
from importlib import import_module
import argparse


def get_parameters():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--snapshotdate", dest="snapshot_date", metavar="9999-01-01",
                        help="Date in Y-MM-DD format for which query needs to run. If no Date is provided it will "
                             "run for today", required=False)
    parser.add_argument("--s3_root_path", dest="s3_root_path", metavar="s3a://bucket_name/object_path",
                        help="Format of result data written in s3", required=False)
    parser.add_argument("--s3_target_path", dest="s3_target_path", metavar="s3a://bucket_name/object_path",
                        help="Bucket and object path for writing result data", required=False)
    parser.add_argument("--region_name", dest="region_name",
                        help="AWS Region")
    parser.add_argument("--secrets_arn", dest="secrets_arn",
                        help="Secrets name to retrieve Aurora Credentials", required=False)
    parser.add_argument("--aurora_database_name", dest="aurora_database_name",
                        help="Database name for material snapshot data")
    parser.add_argument("--util_script_path", dest="util_script_path",
                        help="Local path to util script")

    args = parser.parse_args()
    return args.snapshot_date, args.aurora_database_name, args.secrets_arn, args.region_name, \
           args.s3_root_path, args.util_script_path, args.s3_target_path


class DataReader:
    """ reading data from different sources """

    def __init__(self, spark, spark_util):
        self.spark = spark
        self.spark_utils = spark_util

    def read_s3_data(self, s3_root_path, snapshot_date, domain_path, columns):
        s3path = s3_root_path + domain_path + \
                 "/YYYY=" + snapshot_date[:4] + "/MM=" + snapshot_date[5:7] + "/DD=" + snapshot_date[8:]
        data_df = self.spark.read.format("parquet").load(s3path).select(columns)
        return data_df.repartition(200)

    def read_sql_data(self, sql, aurora_params):
        url = "jdbc:mysql://%s/%s?useServerPrepStmts=false&rewriteBatchedStatements=true&" \
              "useUnicode=yes&characterEncoding=UTF-8" % (aurora_params['aurora_host'],
                                                          aurora_params['aurora_database_name'])

        db_properties = {"user": aurora_params['aurora_user'],
                         "password": aurora_params['aurora_pwd'],
                         "driver": "com.mysql.jdbc.Driver"}
        data_df = self.spark.read.jdbc(
            url=url,
            table="("+sql+") as my_table ",
            properties=db_properties
        )
        return data_df


class InventoryPerformanceDataProvider:

    def __init__(self, spark, spark_util, s3_root_path, snapshot_date):
        self.spark = spark
        self.spark_utils = spark_util
        self.data_reader = DataReader(spark, spark_util)
        self.s3_root_path = s3_root_path
        self.snapshot_date = snapshot_date

    def get_agedinventory_data(self):
        agedinventory_columns = ['datasourceid', 'plantcode', 'materialcode', 'totalonhandquantity']
        agedinventory_data = self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date,
                                                           "scm/agedinventory",
                                                           agedinventory_columns) \
            .withColumn("MaterialKey", concat(col("datasourceid"), lit("_"),
                                              col("plantcode"), lit("_"),
                                              col("materialcode")))\
            .drop('datasourceid', 'plantcode', 'materialcode')\
            .distinct()
        return agedinventory_data

    def get_mrp_data(self):
        demand_columns = ['datasourceid', 'materialcode', 'plantcode', 'mrptypestdcode', 'deliveryfinishdts',
                          'quantity', 'processingrule', 'profitcenter']
        demand_end_date = (datetime.strptime(self.snapshot_date, '%Y-%m-%d') + timedelta(days=91)).strftime('%Y-%m-%d')
        mrp_data = self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date,
                                                       "scm/mrp", demand_columns) \
            .withColumn("MaterialKey", concat(col("datasourceid"), lit("_"),
                                              col("plantcode"), lit("_"),
                                              col("materialcode"))) \
            .drop('datasourceid', 'plantcode', 'materialcode') \
            .filter((col("processingrule") == 'Regular') &
                    (col("deliveryfinishdts").isNotNull()) &
                    (col("profitcenter").isNotNull()) &
                    (col("mrptypestdcode").isin(['Delivery', 'Independent Requirement', 'Sales Agreement', 'Sales Order',
                                                 'Allocation', 'Backflush Dependent Requirement', 'Dependent Requirement',
                                                 'Dependent Reservation', 'Interplant Transfer Order',
                                                 'SubContractor Requirement'])))\
            .filter(col("deliveryfinishdts") <= demand_end_date)\
            .groupby("MaterialKey")\
            .agg((sum(col("quantity")) / 91).alias("AverageDemand"))
        return mrp_data

    def get_materials_data(self):
        materials_columns = ['DataSourceId', 'PlantCode', 'MaterialCode', 'SafetyLeadTime',
                             'DockToStockLeadTime', 'LotSizeCode', 'SafetyStockQuantity']
        materials_data = self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date,
                                                       "dimensions/materials", materials_columns) \
            .withColumn("MaterialKey", concat(col("DataSourceId"), lit("_"),
                                              col("PlantCode"), lit("_"),
                                              col("MaterialCode"))) \
            .withColumnRenamed("snapshotdate", "SnapshotDate")\
            .filter(col("DataSourceId") == 6)
        return materials_data

    def get_lot_size_data(self, aurora_params):
        query = "Select DataSourceID, LotSizeCode, ForceNumberOfDaysSupply from lotsize"
        lot_size_data = self.data_reader.read_sql_data(query, aurora_params=aurora_params)\
            .withColumnRenamed("DataSourceID", "DataSourceId")
        return lot_size_data


class InventoryPerformancePipeline:
    def __init__(self, ip_data_provider, aurora_params, s3_root_path, snapshot_date, s3_target_path):
        self.data_provider = ip_data_provider
        self.aurora_params = aurora_params
        self.s3_root_path = s3_root_path
        self.snapshot_date = snapshot_date
        self.s3_target_path = s3_target_path
        self.spark_utils = spark_utils

    def run_pipeline(self):
        inventory_data = self.data_provider.get_agedinventory_data()
        materials_data = self.data_provider.get_materials_data()
        lot_size_data = self.data_provider.get_lot_size_data(self.aurora_params)
        demand_data = self.data_provider.get_mrp_data()

        inventory_perf_data = materials_data\
            .join(lot_size_data, ['DataSourceId', 'LotSizeCode'], how='left_outer') \
            .withColumnRenamed("DockToStockLeadTime", "TargetRangeLow")\
            .withColumn("TargetRangeLow", col("TargetRangeLow").cast(FloatType()))\
            .withColumn("TargetRangeHigh", coalesce(col("TargetRangeLow"), lit(0)) +
                        coalesce(col("SafetyLeadTime"), lit(0)) +
                        coalesce(col("ForceNumberOfDaysSupply"), lit(0)))\
            .withColumn("TargetRangeHigh", col("TargetRangeHigh").cast(FloatType()))\
            .join(inventory_data, ['MaterialKey'], how='left_outer')\
            .join(demand_data, ['MaterialKey'], how='left_outer')\
            .withColumn("ActualDOS", (coalesce(col("totalonhandquantity"), lit(0)) -
                                      coalesce(col("SafetyStockQuantity"), lit(0))) /
                        coalesce(col("AverageDemand"), lit(0))) \
            .withColumn("ActualDOS", round(col("ActualDOS"), scale=2))\
            .fillna(-1, ["ActualDOS"]) \
            .drop("LotSizeCode", "SafetyLeadTime", "SafetyStockQuantity", "totalonhandquantity",
                  "AverageDemand", "ForceNumberOfDaysSupply")
        s3path = self.s3_root_path + self.s3_target_path + \
                 "/YYYY=" + self.snapshot_date[:4] + "/MM=" + self.snapshot_date[5:7] + "/DD=" + self.snapshot_date[8:]
        inventory_perf_data.repartition(10).write.mode("overwrite").format("parquet").save(s3path)


if __name__ == "__main__":
    snapshot_date, aurora_database_name, secrets_arn, region_name, \
        s3_root_path, util_script_path, s3_target_path = get_parameters()

    spark_session = SparkSession.builder.getOrCreate()
    spark_session.sparkContext.addPyFile(util_script_path)
    spark_utils = import_module('spark_utils')
    aurora_host, aurora_user, aurora_pwd = spark_utils.get_secrets(secrets_arn, region_name)
    data_provider = InventoryPerformanceDataProvider(spark_session, spark_utils, s3_root_path, snapshot_date)
    base_aurora_params = {"aurora_database_name": aurora_database_name,
                          "aurora_host": aurora_host, "aurora_user": aurora_user, "aurora_pwd": aurora_pwd,
                          "snapshot_date": snapshot_date, "drop_snapshot_date": True}
    data_grid_pipeline = InventoryPerformancePipeline(data_provider, base_aurora_params, s3_root_path,
                                                      snapshot_date, s3_target_path)
    data_grid_pipeline.run_pipeline()

