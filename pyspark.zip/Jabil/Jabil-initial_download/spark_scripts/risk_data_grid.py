from pyspark.sql.types import DateType, DoubleType
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql import Window
from importlib import import_module
from datetime import datetime
import argparse


def get_parameters():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--snapshotdate", dest="snapshot_date", metavar="9999-01-01",
                        help="Date in Y-MM-DD format for which query needs to run. If no Date is provided it will "
                             "run for today", required=False)
    parser.add_argument("--s3_root_path", dest="s3_root_path", metavar="s3a://bucket_name/object_path",
                        help="Format of result data written in s3", required=False)
    parser.add_argument("--region_name", dest="region_name",
                        help="AWS Region")
    parser.add_argument("--util_script_path", dest="util_script_path",
                        help="Local path to util script")
    parser.add_argument("--aurora_database_name", dest="aurora_database_name",
                        help="Target database name in aurora")
    parser.add_argument("--aurora_table_name", dest="aurora_table_name",
                        help="Target table name in aurora")
    parser.add_argument("--secrets_arn", dest="secrets_arn",
                        help="Secrets name to retrieve Aurora Credentials", required=False)
    parser.add_argument("--enable_logging", dest="enable_logging",
                        help="Enable or disable logging into file", required=False)
    args = parser.parse_args()
    return args.snapshot_date, args.s3_root_path, args.secrets_arn, args.region_name, \
           args.util_script_path, args.enable_logging, args.aurora_table_name, args.aurora_database_name


class DataReader:
    """ reading data from different sources """

    def __init__(self, spark):
        self.spark = spark

    def read_s3_data(self, s3_root_path, snapshot_date, domain_path, columns, drop_material_code=True,
                     is_partitioned=True):
        s3path = s3_root_path + domain_path
        if is_partitioned:
            s3path = s3path +\
                     "/YYYY=" + snapshot_date[:4] + \
                     "/MM=" + snapshot_date[5:7] + \
                     "/DD=" + snapshot_date[8:]

        data_df = self.spark.read.format("parquet").load(s3path) \
            .select(columns) \
            .withColumn("MaterialKey", concat(col("DataSourceId"), lit("_"),
                                              col("PlantCode"), lit("_"),
                                              col("MaterialCode")))
        if drop_material_code:
            data_df = data_df.drop('DataSourceId', 'MaterialCode', 'PlantCode')

        return data_df.repartition("MaterialKey").repartition(200)

    def read_sql_data(self, aurora_params, columns):
        host = aurora_params['aurora_host']
        database_name = aurora_params['aurora_database_name']
        table_name = aurora_params['aurora_table_name']
        user = aurora_params['aurora_user']
        password = aurora_params['aurora_pwd']
        url = "jdbc:mysql://%s/%s?useServerPrepStmts=false&rewriteBatchedStatements=true&" \
              "useUnicode=yes&characterEncoding=UTF-8" % (host, database_name)
        data_df = self.spark.read.format("jdbc") \
            .option("driver", "com.mysql.jdbc.Driver") \
            .option("url", url) \
            .option("dbtable", table_name) \
            .option("user", user) \
            .option("password", password) \
            .load().select(*columns)
        return data_df.repartition(200)

    def read_eip_data(self, query, drop_material_code=True, material_key_exists=False):
        data = self.spark.sql(query)
        if not material_key_exists:
            data = data.withColumn("MaterialKey", concat(col("DataSourceId"), lit("_"),
                                                         col("PlantCode"), lit("_"),
                                                         col("MaterialCode")))
            if drop_material_code:
                data = data.drop('DataSourceId', 'MaterialCode', 'PlantCode')
        return data.repartition("MaterialKey").repartition(200)


class DataProvider:

    def __init__(self, spark, spark_util, s3_root_path, snapshot_date):
        self.spark = spark
        self.s3_root_path = s3_root_path
        self.spark_utils = spark_util
        self.snapshot_date = snapshot_date
        self.data_reader = DataReader(self.spark)

    def get_corporation_data(self):
        ihs_unique_window = Window.partitionBy("MaterialKey", "ManufacturerPartNumber", "Manufacturer", "AmlReference")\
            .orderBy(asc_nulls_last("Yteol"), desc_nulls_last("AlertPredictionDate"))
        corp_data_query = "select distinct aml.materialkey as MaterialKey, ihs.life_cycle_stage as LifeCycle, " \
            "ihs.estimated_yteol as Yteol, trim(aml.amlreference) as AmlReference, " \
            "trim(corp.corporationname) as Manufacturer, trim(aml.manufacturerpartnumber) as ManufacturerPartNumber, " \
            "ihs.alert_prediction_date as AlertPredictionDate "\
            "from incontrol.vw_sl_jabildb_aml aml " \
            "inner join incontrol.vw_sl_mfrpart mfr on aml.mfrpartid = mfr.mfrpartid " \
            "and to_date(now())  < aml.effectivetodts " \
            "inner  join incontrol.vw_sl_jabildb_corporationds corpds " \
            "on aml.mfrcorporationdsid = corpds.corporationdsid " \
            "and aml.datasourceid  = corpds.datasourceid " \
            "inner  join incontrol.vw_sl_jabildb_corporation corp " \
            "on mfr.corporationid = corp.corporationid " \
            "left outer join " \
            "(select ihs_inner.life_cycle_stage, ihs_inner.estimated_yteol, ihs_inner.manufacturer_part_number, " \
                          "c.corporationid, ihs_inner.alert_prediction_date " \
            "from incontrol.ihs_lifecycle ihs_inner " \
            " inner join incontrol.vw_sl_jabildb_corporation c on c.corporationname = ihs_inner.manufacturer_name " \
            ") ihs on trim(ihs.manufacturer_part_number) = trim(mfr.mfrpartcode) " \
            "and ihs.corporationid =  corp.corporationid"
        corp_data = self.data_reader.read_eip_data(corp_data_query, material_key_exists=True)\
            .withColumn("AlertPredictionDate",
                        from_unixtime(unix_timestamp('AlertPredictionDate', 'dd-MMM-yyyy')).cast(DateType()))\
            .withColumn("MinYteolRank", row_number().over(ihs_unique_window)) \
            .filter(col("MinYteolRank") == 1)\
            .drop("AlertPredictionDate", "MinYteolRank")
        return corp_data

    def get_materials_data(self):
        materials_data = self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date, "dimensions/materials",
                                                       columns=['DataSourceId', 'PlantCode', 'MaterialCode',
                                                                'FixedLeadTime',
                                                                'MaterialDescription', 'StandardUnitCostUsd',
                                                                'MinimumLotSize', 'ProfitCenter',
                                                                'MultipleQuantity', 'SafetyStockQuantity',
                                                                'SellUnitPriceUSD', 'CustomerGroupCode',
                                                                'ProductGroupCode',
                                                                'PlantName', 'QuotaArrangementUsage', 'MakeBuy'],
                                                       drop_material_code=False)
        materials_rename_columns = {"FixedLeadTime": "LeadTime", "SellUnitPriceUSD": "SellPriceUSD",
                                    "StandardUnitCostUsd": "StandardCostUSD", "MinimumLotSize": "MinimumOrderQuantity",
                                    "MultipleQuantity": "OrderIncrement"}
        materials_data = self.spark_utils.rename_columns(materials_data, materials_rename_columns)

        materials_data = self.spark_utils.cast_cols_to_type(materials_data,
                                                            ['SellPriceUSD', 'StandardCostUSD', 'SafetyStockQuantity'],
                                                            DoubleType())
        return materials_data.filter(col('MakeBuy') == 'Buy').drop('MakeBuy')

    def get_inventory_data(self):
        return self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date, "scm/inventory",
                                             ['DataSourceId', 'PlantCode', 'MaterialCode', 'Quantity'])\
            .filter(col("Quantity") > 0).drop("Quantity")

    def get_mrp_data(self):
        return self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date, "scm/mrp",
                                             ['DataSourceId', 'PlantCode', 'MaterialCode', 'Quantity'])\
            .filter(col("Quantity") > 0).drop("Quantity").distinct()

    def get_quota_arrangement_data(self):
        quota_arrangement_data = self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date,
                                                               "dimensions/quota_arrangement",
                                                               ['DataSourceId', 'PlantCode', 'MaterialCode',
                                                                'TargetRatio', 'EffectiveFromDate',
                                                                'EffectiveToDate', 'CorporationName', 'AmlReference',
                                                                'SupplierCorporationDSCode', 'MaterialSourceTypeCode',
                                                                'PurchasingOrganizationCode']) \
            .withColumn('AmlReference', trim(col('AmlReference')))
        return quota_arrangement_data

    def get_purchasing_source_list_data(self):
        source_list_data = self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date,
                                                         "dimensions/purchasing_source_list",
                                                         ['DataSourceId', 'PlantCode', 'MaterialCode', 'StatusCode',
                                                          'FixedSource', 'MrpIndicator', 'CorporationName',
                                                          'AmlReference', 'EffectiveFromDate', 'EffectiveToDate',
                                                          'SupplierCorporationDSCode', 'PurchasingOrganizationCode']) \
            .withColumn("EffectiveFromDate",
                        from_unixtime(unix_timestamp('EffectiveFromDate', 'yyyy-MM-dd HH:mm:ss')).cast(DateType())) \
            .withColumn("EffectiveToDate",
                        from_unixtime(unix_timestamp('EffectiveToDate', 'yyyy-MM-dd HH:mm:ss')).cast(DateType())) \
            .withColumn('AmlReference', trim(col('AmlReference')))\
            .filter((upper(col("StatusCode")) == 'RELEASED') &
                    (col("EffectiveFromDate") <= current_date()) &
                    (col("EffectiveToDate") >= current_date()))\
            .drop("EffectiveFromDate", "EffectiveToDate")
        return source_list_data

    def get_source_type_data(self):
        source_type_sql = "select * from (select concat_ws('_', '6', werks, matnr) as MaterialKey, " \
                          "CASE WHEN sobsl = '10' THEN '2' WHEN sobsl = '30' THEN '3' ELSE '0' END " \
                          "as MaterialSourceTypeCode " \
                          "from persistent.sap_hana_ecc_ha_marc " \
                          "union  all " \
                          "select concat_ws('_', '22', werks, matnr) as MaterialKey, CASE WHEN " \
                          "sobsl = '10' THEN '2' WHEN sobsl = '30' THEN '3' ELSE '0' END as MaterialSourceTypeCode " \
                          "from persistent.sap_hana_ecc_hcc_marc) s"
        source_type_data = self.data_reader.read_eip_data(source_type_sql, material_key_exists=True)
        return source_type_data

    def get_purchasing_info_record_data(self):
        s3_path = self.s3_root_path + "dimensions/purchasing_info_record"
        pi_columns_mapping = {'suppliercorporationdscode': 'SupplierCorporationDSCode',
                              'materialsourcetypecode': 'MaterialSourceTypeCode',
                              'purchasingorganizationcode': 'PurchasingOrganizationCode',
                              'fixedleadtime': 'LeadTime', 'minimumlotsize': 'MinimumOrderQuantity',
                              'multipleqty': 'OrderIncrement', 'materialkey': 'MaterialKey'}

        purchasing_info_data = self.spark.read.format("parquet").load(s3_path) \
            .withColumn("materialkey", concat(col("datasourceid"), lit("_"),
                                              col("plantcode"), lit("_"),
                                              col("materialcode"))) \
            .select([*pi_columns_mapping])
        purchasing_info_data = self.spark_utils.rename_columns(purchasing_info_data, pi_columns_mapping) \
            .repartition("MaterialKey").repartition(200)
        return purchasing_info_data

    def get_aml_count_data(self):
        alm_count = self.data_reader.read_eip_data(
                                  "select aml.materialkey as MaterialKey, count(distinct aml.amlid) as AmlCount "
                                  "from incontrol.vw_sl_jabildb_aml aml where to_date(now()) < aml.effectivetodts "
                                  "group by aml.materialkey",
                                  material_key_exists=True)
        return alm_count

    def get_material_comm_data(self):
        material_comm_data = self.data_reader.read_s3_data(self.s3_root_path, self.snapshot_date, "dimensions/commodity",
                                                           columns=['DataSourceId', 'PlantCode', 'MaterialCode',
                                                                    'CommodityMaterialGroup', 'Commodity'],
                                                           is_partitioned=False) \
            .withColumnRenamed("CommodityMaterialGroup", "CommodityGrouping")
        return material_comm_data

    def get_preferred_supplier_data(self, base_aurora_params):
        aurora_params = dict(base_aurora_params, **{'aurora_table_name': "PreferredSupplierList"})
        columns = ['SupplierName', 'RecordClean',  "Commodity",
                   'SupplierType', 'SupplierClassification']
        preferred_supplier_data = self.data_reader.read_sql_data(aurora_params, columns)
        preferred_supplier_data = preferred_supplier_data \
            .filter(trim(col("RecordClean")) == 'Yes') \
            .withColumn("PreferredManufacturer", lit(True)) \
            .withColumn("SupplierType", trim(upper(col("SupplierType")))) \
            .withColumn("SupplierClassification", trim(upper(col("SupplierClassification")))) \
            .withColumn("SupplierName", upper(trim(col("SupplierName")))) \
            .withColumnRenamed("Commodity", "PreferredCommodity")\
            .withColumnRenamed("SupplierType", "ManufacturerType") \
            .withColumnRenamed("SupplierClassification", "ManufacturerClassification") \
            .drop("RecordClean") \
            .distinct()
        return preferred_supplier_data

    def get_technology_data(self, base_aurora_params):
        aurora_params = dict(base_aurora_params, **{'aurora_table_name': "TechnologyFunction"})
        columns = ['ManufacturerPartNumber', 'Technology', 'Yteoc', "Manufacturer"]
        technology_data = self.data_reader.read_sql_data(aurora_params, columns)\
            .withColumn("ManufacturerPartNumber", trim(col("ManufacturerPartNumber"))) \
            .withColumn("Manufacturer", trim(col("Manufacturer"))) \
            .distinct()
        return technology_data


class RiskDataGridPipeline:

    def __init__(self, spark, spark_util, data_provider, *args):
        self.spark = spark
        self.snapshot_date, self.s3_root_path, self.secrets_arn, self.region_name, \
            self.util_script_path, self.enable_logging, self.aurora_table_name, self.aurora_database_name = args
        host, user, pwd = spark_util.get_secrets(self.secrets_arn, self.region_name)
        self.base_aurora_params = {"aurora_host": host, "aurora_user": user, "aurora_pwd": pwd,
                                   "aurora_database_name": self.aurora_database_name}
        self.data_reader = DataReader(self.spark)
        self.snapshot_date = self.snapshot_date if self.snapshot_date else datetime.today().strftime("%Y-%m-%d")
        self.data_provider = data_provider
        self.spark_utils = spark_util
        if self.enable_logging == 'True':
            self.spark_utils.configure_logging(file_name="risk_data_grid")

    def add_purchasing_info_data(self, materials_data):
        """ replacing "LeadTime", "MinimumOrderQuantity", "OrderIncrement" columns in materials by data from
         purchasinginforecord view if material has qoutaarrangement or source list records """

        info_record_unique_window = Window.partitionBy('MaterialKey', 'PurchasingOrganizationCode',
                                                       'MaterialSourceTypeCode', 'SupplierCorporationDSCode')\
            .orderBy(desc_nulls_last("LeadTime"))

        purchasing_info_data = self.data_provider.get_purchasing_info_record_data() \
            .withColumn("OrderIncrement", first(col("OrderIncrement")).over(info_record_unique_window)) \
            .withColumn("LeadTime", first(col("LeadTime")).over(info_record_unique_window)) \
            .withColumn("MinimumOrderQuantity", first(col("MinimumOrderQuantity")).over(info_record_unique_window)) \
            .distinct()

        source_type_data = self.data_provider.get_source_type_data()

        result_unique_key_window = Window\
            .partitionBy('MaterialKey', 'Supplier', 'SupplierSplit').orderBy(desc_nulls_last("LeadTime"))

        materials_purchasing_info_data = materials_data \
            .filter(col("SupplierSplit").isNotNull()) \
            .join(source_type_data, ['MaterialKey'], how="left_outer") \
            .drop("LeadTime", "MinimumOrderQuantity", "OrderIncrement") \
            .join(purchasing_info_data, ['MaterialKey', 'PurchasingOrganizationCode', "MaterialSourceTypeCode",
                                         'SupplierCorporationDSCode'], how='left_outer')\
            .drop("MaterialSourceTypeCode") \
            .withColumn("OrderIncrement", first(col("OrderIncrement")).over(result_unique_key_window)) \
            .withColumn("LeadTime", first(col("LeadTime")).over(result_unique_key_window)) \
            .withColumn("MinimumOrderQuantity", first(col("MinimumOrderQuantity")).over(result_unique_key_window)) \
            .distinct()

        union_columns = materials_data.columns
        return materials_data.filter(col("SupplierSplit").isNull())\
            .select(*union_columns)\
            .union(materials_purchasing_info_data.select(*union_columns))

    def get_full_materials_data(self):
        """ add aml count, material commodity details and IHS data to materials """

        materials_data = self.data_provider.get_materials_data()
        alm_count = self.data_provider.get_aml_count_data()
        material_comm_data = self.data_provider.get_material_comm_data()

        inventory_data = self.data_provider.get_inventory_data()
        mrp_data = self.data_provider.get_mrp_data()

        full_materials_data = materials_data.join(mrp_data.union(inventory_data).distinct(), ['MaterialKey']) \
            .join(material_comm_data, ['MaterialKey'], how='left_outer') \
            .join(alm_count, ['MaterialKey'], how='left_outer')
        return full_materials_data

    @staticmethod
    def aggregate_source_list_data(source_list_data, group_cols):
        """ get prioritized list of source list records and group them by specified columns """

        source_list_agg_data = source_list_data \
            .groupBy(group_cols).agg(
                collect_list(when(upper(col('FixedSource')) == 'FIXED',
                                  struct("AmlReference", "CorporationName",
                                         "PurchasingOrganizationCode", "SupplierCorporationDSCode")))
                    .alias("FirstRowSourceList"),

                collect_set(when(((col('FixedSource') == '') & (col('MrpIndicator').isin([1, 2]))),
                                 col("SupplierCorporationDSCode")))
                    .alias("DistinctCorporationDSCodes"),

                collect_list(when((col('FixedSource') == '') & (col('MrpIndicator').isin([1, 2])),
                                  struct(["AmlReference", "CorporationName",
                                          "PurchasingOrganizationCode", "SupplierCorporationDSCode"]))
                             ).alias("SecondRowSourceList")) \
            .filter((size(col("FirstRowSourceList")) > 0) | (size(col("SecondRowSourceList")) > 0))\
            .withColumn("SourceListSourcingCount", when(size(col("FirstRowSourceList")) > 0, lit(1))
                        .otherwise(size(col("DistinctCorporationDSCodes")))) \
            .withColumn("SourceListRecord",
                            when(size(col("FirstRowSourceList")) > 0, col("FirstRowSourceList").getItem(0))
                            .when(size(col("SecondRowSourceList")) > 0, col("SecondRowSourceList").getItem(0)))\
            .drop("FirstRowSourceList", "SecondRowSourceList", "DistinctCorporationDSCodes")
        return source_list_agg_data

    @staticmethod
    def aggregate_quota_arrangement_data(quota_arrangement_data):
        count_window = Window.partitionBy("MaterialKey", "CorporationName", "SupplierCorporationDSCode")
        rank_window = count_window.orderBy(["IsNullAmlReference", "MaterialSourceTypeCode"])
        quota_arrangement_data = quota_arrangement_data \
            .withColumn("EffectiveToDate",
                        from_unixtime(unix_timestamp('EffectiveToDate', 'yyyyMMdd')).cast(DateType())) \
            .withColumn("EffectiveFromDate",
                        from_unixtime(unix_timestamp('EffectiveFromDate', 'yyyyMMdd')).cast(DateType())) \
            .filter((col('EffectiveFromDate') <= current_date()) &
                    (col('EffectiveToDate') >= current_date()) &
                    (col('TargetRatio') > 0))\
            .withColumn("IsDuplicated", count(col("CorporationName")).over(count_window) > 1)\
            .withColumn("IsNullAmlReference", when((col("AmlReference") == "") | (col("AmlReference").isNull()), 1)
                        .otherwise(0))\
            .withColumn("DuplicatedQARank",  when((col("IsDuplicated") == True) & (col("IsNullAmlReference") == 1),
                                                            row_number().over(rank_window)).otherwise(lit(1)))\
            .filter((col("IsDuplicated") == False) |
                    ((col("IsDuplicated")) & (col("DuplicatedQARank") == 1))) \
            .select("MaterialKey",
                    struct(["AmlReference", "CorporationName", "PurchasingOrganizationCode",
                            "SupplierCorporationDSCode", "TargetRatio"]).alias("qa")) \
            .groupBy("MaterialKey").agg(collect_list("qa").alias("QuotaArrangement")) \
            .withColumn("SourcingCount", size(col("QuotaArrangement")))
        return quota_arrangement_data

    @staticmethod
    def get_source_list_materials(materials_data, source_list_data, join_cols, aml_only=False):
        """ add specified source list columns into materials data """

        source_list_agg_data = RiskDataGridPipeline.aggregate_source_list_data(source_list_data, join_cols)

        materials_source_list = materials_data \
            .join(source_list_agg_data, join_cols, how='left_outer')\
            .withColumn("AmlReference", when(col("SourceListRecord").isNotNull(), col("SourceListRecord.AmlReference")))

        if not aml_only:
            materials_source_list = materials_source_list\
                .withColumnRenamed("SourceListSourcingCount", "SourcingCount") \
                .withColumn("SupplierSplit", when(col("SourceListRecord").isNotNull(), lit(100))) \
                .withColumn("Supplier",
                            when(col("SourceListRecord").isNotNull(), col("SourceListRecord.CorporationName")))\
                .withColumn("SupplierCorporationDSCode",
                            when(col("SourceListRecord").isNotNull(), col("SourceListRecord.SupplierCorporationDSCode")))\
                .withColumn("PurchasingOrganizationCode",
                            when(col("SourceListRecord").isNotNull(), col("SourceListRecord.PurchasingOrganizationCode")))
        else:
            materials_source_list = materials_source_list.drop("SourceListSourcingCount")

        materials_source_list = materials_source_list.drop("SourceListRecord", "QuotaArrangementUsage")
        return materials_source_list

    @staticmethod
    def get_quota_arr_materials(materials_data, quota_arrangement_data, source_list_data):
        """ filter, aggregate and join quota arrangement data with materials """

        quota_arrangement_data = RiskDataGridPipeline.aggregate_quota_arrangement_data(quota_arrangement_data)

        qouta_materials_data = materials_data.filter(col("QuotaArrangementUsage") != '') \
            .join(quota_arrangement_data, ['MaterialKey'], how="left_outer") \
            .withColumn("Set100Percents",
                        when((col("QuotaArrangement").isNotNull()) & (size(col("QuotaArrangement")) == 1) &
                             (col("QuotaArrangement").getItem(0).TargetRatio != 100), True).otherwise(False))\
            .cache()

        not_null_quota = qouta_materials_data.filter((col("QuotaArrangement").isNotNull()) &
                                                     (size(col("QuotaArrangement")) > 0))\
            .withColumn("QuotaArrangement", explode("QuotaArrangement")) \
            .withColumn("SupplierSplit", when(col("Set100Percents"), 100)
                        .otherwise(col("QuotaArrangement.TargetRatio"))) \
            .withColumn('Supplier', col("QuotaArrangement.CorporationName")) \
            .withColumn('AmlReference', col("QuotaArrangement.AmlReference")) \
            .withColumn("SupplierCorporationDSCode", col("QuotaArrangement.SupplierCorporationDSCode")) \
            .withColumn("PurchasingOrganizationCode", col("QuotaArrangement.PurchasingOrganizationCode")) \
            .drop("QuotaArrangement", "Set100Percents", "QuotaArrangementUsage")\
            .cache()

        # take amlreference from sourcelist data if there is no amlreference in quotaarrangement data
        qouta_null_aml_from_sourcelist = RiskDataGridPipeline.get_source_list_materials(
            not_null_quota.filter((col("AmlReference").isNull()) | (col("AmlReference") == '')),
            source_list_data,
            join_cols=['MaterialKey', 'SupplierCorporationDSCode'],
            aml_only=True)\
            .cache()

        not_null_quota = not_null_quota\
            .join(qouta_null_aml_from_sourcelist, ['MaterialKey', 'SupplierCorporationDSCode'], 'left_anti')\
            .select(*not_null_quota.columns) \
            .union(qouta_null_aml_from_sourcelist.select(*not_null_quota.columns))

        # taking records without QuotaArrangement and joining them with SourceList
        null_qouta_materials_data = qouta_materials_data\
            .filter((col("QuotaArrangement").isNull()) | (size(col("QuotaArrangement")) == 0)) \
            .drop("QuotaArrangement", "Set100Percents", "QuotaArrangementUsage", "SourcingCount") \

        source_list_materials_data = RiskDataGridPipeline.\
            get_source_list_materials(null_qouta_materials_data, source_list_data, join_cols=['MaterialKey'])

        qouta_materials_data = not_null_quota\
            .select(*not_null_quota.columns)\
            .union(source_list_materials_data.select(*not_null_quota.columns))
        return qouta_materials_data

    def add_preferred_supplier_data(self, data):
        preferred_supplier_data = self.data_provider.get_preferred_supplier_data(self.base_aurora_params)
        preferred_supplier_result = data\
            .join(preferred_supplier_data,
                  (upper(data.Manufacturer) == upper(preferred_supplier_data.SupplierName)) &
                  (upper(data.Commodity) == upper(preferred_supplier_data.PreferredCommodity)),
                  how="left_outer")\
            .drop("PreferredCommodity", "SupplierName")
        return preferred_supplier_result

    def write_to_s3(self, result_data):
        s3path = self.s3_root_path + "incontrol/risk_data" + \
                 "/YYYY=" + self.snapshot_date[:4] + "/MM=" + self.snapshot_date[5:7] + "/DD=" + self.snapshot_date[8:]
        result_data = result_data.withColumn("ProfitPlant", concat_ws("-", col("ProfitCenter"), col("PlantCode")))
        s3_params = {"s3_output_format": "parquet", "s3path": s3path, "s3_folder_name": None,
                     "is_partitioned": False}
        self.spark_utils.write_to_s3(result_data, s3_params)

    def write_risk_grid_data(self, result_data):
        aurora_params = dict(self.base_aurora_params,
                             **{"aurora_table_name": self.aurora_table_name,
                                "snapshot_date_column": "SnapshotDate",
                                "snapshot_date": self.snapshot_date.replace("-", ""),
                                "drop_snapshot_date": True})
        self.spark_utils.write_to_aurora(result_data, aurora_params)
        self.write_to_s3(result_data)

    def run_pipeline(self):
        materials_data = self.get_full_materials_data()
        quota_arrangement_data = self.data_provider.get_quota_arrangement_data()
        source_list_data = self.data_provider.get_purchasing_source_list_data().cache()
        qouta_materials_data = self.get_quota_arr_materials(materials_data,
                                                            quota_arrangement_data, source_list_data)

        materials_source_list = self.get_source_list_materials(
            materials_data.filter(col("QuotaArrangementUsage") == ''),
            source_list_data,
            join_cols=['MaterialKey'])

        union_columns = qouta_materials_data.columns
        result_data = qouta_materials_data \
            .select(*union_columns) \
            .union(materials_source_list.select(*union_columns))

        unique_key_window = Window.partitionBy("MaterialKey", "ManufacturerPartNumber",
                                               "Manufacturer", "Supplier")

        manufacturer_data = self.data_provider.get_corporation_data()
        technology_data = self.data_provider.get_technology_data(self.base_aurora_params)
        result_data = self.add_purchasing_info_data(result_data) \
            .join(manufacturer_data, ["MaterialKey", "AmlReference"], how="left_outer") \
            .withColumn("SupplierSplitSum", sum("SupplierSplit").over(Window.partitionBy("MaterialKey"))) \
            .withColumn("SupplierSplit", sum("SupplierSplit").over(unique_key_window))\
            .withColumn("PurchasingInfoRecordRowNumber",
                        row_number()
                        .over(unique_key_window.orderBy(desc_nulls_last("LeadTime"), monotonically_increasing_id()))) \
            .filter(col("PurchasingInfoRecordRowNumber") == 1) \
            .drop("PurchasingInfoRecordRowNumber") \
            .distinct()\
            .withColumn("RecordsCount", count("SupplierSplit").over(Window.partitionBy("MaterialKey"))) \
            .withColumn("SupplierSplit",
                        when((col("SupplierSplitSum") > 100) | (col("SupplierSplitSum") < 100),
                             round(col("SupplierSplit") / col("SupplierSplitSum") * 100))
                        .when((col("SupplierSplitSum") < 100) & (col("RecordsCount") == 1), lit(100))
                        .otherwise(col("SupplierSplit"))) \
            .drop("RecordsCount", "SupplierSplitSum")

        result_data = self.add_preferred_supplier_data(result_data) \
            .join(technology_data, ['ManufacturerPartNumber', 'Manufacturer'], how='left_outer') \
            .withColumn("CreatedDate", current_timestamp()) \
            .withColumn("SnapshotDate", lit(self.snapshot_date.replace("-", ""))) \
            .fillna({"SourcingCount": 0, "PreferredManufacturer": False, "AmlCount": 0}) \
            .withColumn("Sourcing",
                        when(col("SourcingCount") > 1, "Split Source").
                        when(col("AmlCount") > 1, "Multi Source").
                        when((col("AmlCount") == 0) & (col("SourcingCount") == 0), "Unknown").
                        otherwise("Single Source")) \
            .drop("SourcingCount", "AmlReference", "SupplierCorporationDSCode",
                  'PurchasingOrganizationCode', 'MaterialSourceTypeCode')\
            .distinct()\
            .cache()

        self.write_risk_grid_data(result_data)
        self.spark_utils.update_snapshot_table(self.snapshot_date, dict(self.base_aurora_params,
                                                                        **{"aurora_table_name": self.aurora_table_name}))


if __name__ == "__main__":
    snapshotdate, s3_root_folder, secrets_arn, region_name, \
        util_script_path, enable_logging, aurora_table_name, aurora_database_name = get_parameters()

    spark_session = SparkSession.builder.getOrCreate()
    spark_session.sparkContext.addPyFile(util_script_path)
    spark_utils = import_module('spark_utils')
    grid_data_provider = DataProvider(spark_session, spark_utils, s3_root_folder, snapshotdate)
    pipeline_configs = (snapshotdate, s3_root_folder, secrets_arn, region_name,
                        util_script_path, enable_logging, aurora_table_name, aurora_database_name)
    data_grid_pipeline = RiskDataGridPipeline(spark_session, spark_utils, grid_data_provider, *pipeline_configs)
    data_grid_pipeline.run_pipeline()
