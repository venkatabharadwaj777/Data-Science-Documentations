from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, timedelta
from importlib import import_module
import argparse
from pyspark.sql.types import DateType, StringType, ArrayType
from math import ceil


def get_parameters():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--snapshotdate", dest="snapshot_date", metavar="9999-01-01",
                        help="Date in Y-MM-DD format for which query needs to run. If no Date is provided it will "
                             "run for today", required=False)
    parser.add_argument("--s3_root_path", dest="s3_root_path", metavar="s3a://bucket_name/object_path",
                        help="Format of result data written in s3", required=False)
    parser.add_argument("--region_name", dest="region_name",
                        help="AWS Region")
    parser.add_argument("--secrets_arn", dest="secrets_arn",
                        help="Secrets name to retrieve Aurora Credentials", required=False)
    parser.add_argument("--aurora_database_name", dest="aurora_database_name",
                        help="Database name for material snapshot data")
    parser.add_argument("--util_script_path", dest="util_script_path",
                        help="Local path to util script")

    args = parser.parse_args()
    return args.snapshot_date, args.aurora_database_name, args.secrets_arn, args.region_name, \
           args.s3_root_path, args.util_script_path


class DataReader:
    """ reading data from different sources """

    def __init__(self, spark, spark_util):
        self.spark = spark
        self.spark_utils = spark_util

    def read_s3_data(self, s3_root_path, domain_path, columns, snapshot_date=None):

        if snapshot_date is not None:
            s3path = s3_root_path + domain_path + \
                     "/YYYY=" + snapshot_date[:4] + "/MM=" + snapshot_date[5:7] + "/DD=" + snapshot_date[8:]
        else:
            s3path = s3_root_path + domain_path
        self.spark_utils.logging.info(f"Read data from {s3path}")
        data_df = self.spark.read.format('parquet').load(s3path).select(columns)

        return data_df.repartition(200)

    def read_sql_data(self, sql, aurora_params):
        url = "jdbc:mysql://%s/%s?useServerPrepStmts=false&rewriteBatchedStatements=true&" \
              "useUnicode=yes&characterEncoding=UTF-8" % (aurora_params['aurora_host'],
                                                          aurora_params['aurora_database_name'])

        db_properties = {"user": aurora_params['aurora_user'],
                         "password": aurora_params['aurora_pwd'],
                         "driver": "com.mysql.jdbc.Driver"}
        data_df = self.spark.read.jdbc(
            url=url,
            table="(" + sql + ") as my_table ",
            properties=db_properties
        )
        return data_df


class IndependentDemandDataProvider:

    def __init__(self, spark, spark_util, s3_root_path, snapshot_date):
        self.spark = spark
        self.spark_utils = spark_util
        self.data_reader = DataReader(spark, spark_util)
        self.s3_root_path = s3_root_path
        self.snapshot_date = snapshot_date

    def get_demand_data(self):
        demand_columns = ['datasourceid', 'plantcode', 'materialcode', 'profitcenter', 'quantity', 'processingrule',
                          'mrptypestdcode', 'deliveryfinishdts']

        mrp_data = self.data_reader.read_s3_data(self.s3_root_path,
                                                 "scm/mrp", demand_columns, self.snapshot_date) \
            .withColumn("MaterialKey", concat(col("datasourceid"), lit("_"),
                                              col("plantcode"), lit("_"),
                                              col("materialcode"))).filter((col("processingrule") == 'Regular') &
                                                                           (col("quantity") > 0) &
                                                                           (col("deliveryfinishdts").isNotNull()) &
                                                                           (col("profitcenter").isNotNull()) &
                                                                           (col("mrptypestdcode").isin(
                                                                               ['Allocation',
                                                                                'Backflush Dependent Requirement',
                                                                                'Delivery',
                                                                                'Independent Requirement',
                                                                                'Dependent Requirement',
                                                                                'Dependent Reservation',
                                                                                'Sales agreement',
                                                                                'Sales order',
                                                                                'Interplant Transfer Order',
                                                                                'SubContractor Requirement']))) \
            .withColumn('finish_dts', when(col("deliveryfinishdts") < self.snapshot_date, lit(self.snapshot_date))
                        .otherwise(col("deliveryfinishdts"))) \
            .withColumn('snapshotdate', lit(self.snapshot_date))

        return mrp_data

    def get_materials_data(self):
        materials_columns = ['DataSourceId', 'PlantCode', 'MaterialCode', 'SellUnitPriceUSD']
        materials_data = self.data_reader.read_s3_data(self.s3_root_path,
                                                       "dimensions/materials", materials_columns, self.snapshot_date) \
            .withColumn("MaterialKey", concat(col("DataSourceId"), lit("_"),
                                              col("PlantCode"), lit("_"),
                                              col("MaterialCode"))).drop('PlantCode', 'MaterialCode',
                                                                         'DataSourceId').distinct()
        return materials_data

    def get_demand_type_data(self, aurora_params):
        query = "Select DemandTypeID, DemandType, MRPTypeSTDCodes from DemandType"
        demand_type_data = self.data_reader.read_sql_data(query, aurora_params=aurora_params)
        return demand_type_data

    def get_billofmaterialflat(self):
        bill_of_material_flat_columns = ['AssemblyMaterialKey']
        bill_of_material_flat_data = self.data_reader.read_s3_data(self.s3_root_path,
                                                                   'incontrol/flatbom',
                                                                   bill_of_material_flat_columns).distinct()

        return bill_of_material_flat_data


class IndependentDemandPipeline:
    def __init__(self, ip_data_provider, aurora_params, s3_root_path, snapshot_date):
        self.data_provider = ip_data_provider
        self.aurora_params = aurora_params
        self.s3_root_path = s3_root_path
        self.snapshot_date = snapshot_date
        self.spark_utils = spark_utils

    @staticmethod
    def get_bucket_monday_date(date_col):
        return when(date_format(date_col, 'E') != 'Mon', date_sub(next_day(date_col, 'monday'), 7)) \
            .otherwise(date_col)

    @staticmethod
    def get_bucket_dates(start_date, end_date):
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
        end_date = datetime.strptime(end_date, '%Y-%m-%d')
        num_of_weeks = ceil(((end_date - start_date).days + 1) / 7)

        bucket_dates = [(start_date + timedelta(weeks=n)).strftime('%Y-%m-%d') for n in range(num_of_weeks)]
        return bucket_dates

    @staticmethod
    def get_month_bucket_dates(start_date, max_future_date):
        start_date = datetime.strptime(start_date, '%Y-%m-%d') if type(start_date) == str else start_date
        max_future_date = datetime.strptime(max_future_date, '%Y-%m-%d') if type(
            max_future_date) == str else max_future_date
        bucket_dates = []
        while max_future_date > start_date:
            bucket_dates.append(datetime.strftime(start_date, '%Y-%m-%d'))
            start_date = datetime(start_date.year + int(start_date.month / 12), ((start_date.month % 12) + 1), 1)

        return bucket_dates

    @staticmethod
    def get_quarter_dates(snapshot_date, date, max_date):
        max_date = datetime.strptime(max_date.split(" ")[0], '%Y-%m-%d')
        start_quarter_date = datetime.strptime(snapshot_date.split(" ")[0], '%Y-%m-%d')
        date = datetime.strptime(date, '%Y-%m-%d')
        while start_quarter_date < max_date:
            quarter_end_date = start_quarter_date + timedelta(days=91)
            if start_quarter_date <= date < quarter_end_date:
                return start_quarter_date
            start_quarter_date = quarter_end_date
        return max_date

    def run_pipeline(self):
        self.spark_utils.configure_logging(file_name="demand_type")
        demand_data = self.data_provider.get_demand_data()
        materials_data = self.data_provider.get_materials_data()
        demand_type_data = self.data_provider.get_demand_type_data(self.aurora_params)
        bill_of_material_flat_data = self.data_provider.get_billofmaterialflat()

        enriched_demand_data = demand_data.join(demand_type_data,
                                                demand_data.mrptypestdcode == demand_type_data.MRPTypeSTDCodes).join(
            materials_data, ['MaterialKey']).cache()

        get_bucket_dates_udf = udf(f=self.get_bucket_dates, returnType=ArrayType(elementType=StringType()))
        get_month_bucket_dates_udf = udf(f=self.get_month_bucket_dates, returnType=ArrayType(elementType=StringType()))
        get_quarter_dates_udf = udf(f=self.get_quarter_dates, returnType=DateType())

        max_date_buckets = enriched_demand_data.withColumn("deliveryfinishdts_timestamp",
                                                           col('deliveryfinishdts').cast("timestamp")) \
            .groupBy('MaterialKey', 'datasourceid', 'plantcode', 'materialcode', 'profitcenter', 'snapshotdate',
                     'DemandType', 'DemandTypeID') \
            .agg(max('deliveryfinishdts_timestamp').alias("final_demand_date")) \
            .withColumn("final_demand_d", from_unixtime(unix_timestamp(col("final_demand_date")), "yyyy-MM-dd")) \
            .withColumn("Quantity", lit(0.0))

        all_date_buckets = max_date_buckets.withColumn("bucket_dates",
                                                       get_bucket_dates_udf(col('snapshotdate'),
                                                                            col('final_demand_d'))) \
            .withColumn("bucket_date", explode(col('bucket_dates'))) \
            .drop("bucket_dates", "final_demand_date")

        independent_demand = enriched_demand_data.withColumn('bucket_date',
                                                             self.get_bucket_monday_date(col('finish_dts')).cast(
                                                                 DateType())) \
            .groupBy(['MaterialKey', 'bucket_date', 'SellUnitPriceUSD']) \
            .agg(sum(enriched_demand_data.quantity).alias('Quantity')).withColumn("value",
                                                                                  col("SellUnitPriceUSD") * col(
                                                                                      'Quantity'))
        independent_demand_full = all_date_buckets \
            .join(independent_demand, ['MaterialKey', 'bucket_date'], how='left_outer') \
            .join(bill_of_material_flat_data,
                  all_date_buckets.MaterialKey == bill_of_material_flat_data.AssemblyMaterialKey,
                  how='left_outer').withColumn("Value",
                                               when(independent_demand.value.isNotNull(),
                                                    independent_demand.value).otherwise(0)) \
            .withColumn('IsAssembly',
                        when(bill_of_material_flat_data.AssemblyMaterialKey.isNotNull(), 1).otherwise(0)).withColumn(
            'quan', when(
                independent_demand.Quantity.isNotNull(), independent_demand.Quantity).otherwise(
                all_date_buckets.Quantity)).select(
            col('datasourceid').alias("DataSourceId"),
            col('plantcode').alias("PlantCode"),
            col('materialcode').alias("MaterialCode"),
            col('MaterialKey'),
            col('profitcenter').alias("ProfitCenter"),
            col('snapshotdate').alias("SnapshotDate"),
            col('bucket_date').alias("BucketDate"),
            col('DemandType'),
            col('DemandTypeID'),
            col('quan').alias("Quantity"),
            col('Value'),
            col('IsAssembly'),
            col('final_demand_d')
        )

        s3_params = {"s3path": self.s3_root_path + f'incontrol/demandtype/{self.snapshot_date}',
                     "s3_output_format": "parquet",
                     "is_partitioned": False}

        demand_df = independent_demand_full.drop('final_demand_d')
        self.aurora_params.update({"aurora_table_name": 'DemandWeekly'})
        self.spark_utils.logging.info(
            f"Writing result into Aurora {self.aurora_params['aurora_table_name']} table and S3 path: {s3_params}")
        self.spark_utils.write_to_aurora(demand_df, self.aurora_params)
        demand_df.write.mode("overwrite").format(s3_params['s3_output_format']).save(s3_params['s3path'])


        demand_monthly_df = max_date_buckets.withColumn("bucket_dates", get_month_bucket_dates_udf(col('snapshotdate'),
                                                                                                   col(
                                                                                                       'final_demand_d'))) \
            .withColumn("bucket_date", explode(col('bucket_dates'))).withColumn(
            "bucket_date_1", date_format(col('bucket_date'), 'yyyy-MM')).drop('bucket_date', 'bucket_dates').withColumn(
            'val', lit(0.0)) \
            .select(
            col('datasourceid').alias("DataSourceId"),
            col('plantcode').alias("PlantCode"),
            col('materialcode').alias("MaterialCode"),
            col('MaterialKey'),
            col('profitcenter').alias("ProfitCenter"),
            col('snapshotdate').alias("SnapshotDate"),
            col('bucket_date_1'),
            col('DemandType'),
            col('DemandTypeID'),
            col("Quantity"),
            col('val'),
            col('final_demand_d')
        )

        monthly_independent_demand = enriched_demand_data.withColumn("bucket_date_1",
                                                                     date_format(col('finish_dts'), 'yyyy-MM')) \
            .groupBy(['MaterialKey', 'bucket_date_1', 'SellUnitPriceUSD']) \
            .agg(sum(enriched_demand_data.quantity).alias('Quantity')).withColumn("val",
                                                                                  col("SellUnitPriceUSD") * col(
                                                                                      'Quantity'))
        full_demand_monthly = demand_monthly_df.join(monthly_independent_demand, ['MaterialKey', 'bucket_date_1'],
                                                     how='left_outer') \
            .join(bill_of_material_flat_data,
                  demand_monthly_df.MaterialKey == bill_of_material_flat_data.AssemblyMaterialKey,
                  how='left_outer').withColumn("Value",
                                               when(monthly_independent_demand.val.isNotNull(),
                                                    monthly_independent_demand.val).otherwise(demand_monthly_df.val)) \
            .withColumn('IsAssembly',
                        when(bill_of_material_flat_data.AssemblyMaterialKey.isNotNull(), 1).otherwise(0)).withColumn(
            'quant', when(
                monthly_independent_demand.Quantity.isNotNull(), monthly_independent_demand.Quantity).otherwise(
                demand_monthly_df.Quantity)).select("DataSourceId",
                                                    "PlantCode",
                                                    "MaterialCode",
                                                    'MaterialKey',
                                                    "ProfitCenter",
                                                    "SnapshotDate",
                                                    col('bucket_date_1').alias('bucket_date'),
                                                    'DemandType',
                                                    'DemandTypeID',
                                                    col("quant").alias("Quantity"),
                                                    'Value',
                                                    'IsAssembly',
                                                    'final_demand_d')


        extended_monthly_demand_df = full_demand_monthly.filter(
            col("bucket_date") == date_format(col('final_demand_d'), 'yyyy-MM')) \
            .filter((col("DemandTypeID") == 1) | (col("DemandTypeID") == 3)).drop('bucket_date').withColumn(
            "bucket_dates", get_month_bucket_dates_udf(
                from_unixtime(unix_timestamp(add_months(col('final_demand_d'), 1)), "yyyy-MM-dd"), lit('2030-01-01'))) \
            .withColumn("extended_bucket_date", explode(col('bucket_dates'))).withColumn(
            "BucketDate", date_format(col('extended_bucket_date'), 'yyyy-MM-dd')).drop('extended_bucket_date').drop(
            'bucket_dates')

        union = full_demand_monthly.withColumn('BucketDate', date_format(col('bucket_date'), 'yyyy-MM-dd')).drop(
            'bucket_date').union(extended_monthly_demand_df).drop('final_demand_d').distinct()

        self.aurora_params.update({"aurora_table_name": 'DemandMonthly'})
        self.spark_utils.logging.info(f"Writing results into Aurora {self.aurora_params['aurora_table_name']}")
        self.spark_utils.write_to_aurora(union, self.aurora_params)
        s3_params['s3path'] = self.s3_root_path + f'incontrol/demandtypemonthly/{self.snapshot_date}'
        self.spark_utils.write_to_s3(demand_df, s3_params)

        demand_quarterly_df = independent_demand_full.withColumn("bucket_date",
                                                                 get_quarter_dates_udf(lit(self.snapshot_date),
                                                                                       col('BucketDate'),
                                                                                       col('final_demand_d'))) \
            .drop(col('BucketDate')) \
            .groupBy(col("DataSourceId"),
                     col("PlantCode"),
                     col("MaterialCode"),
                     col("MaterialKey"),
                     col("ProfitCenter"),
                     col("SnapshotDate"),
                     col("DemandType"),
                     col("DemandTypeID"),
                     col("IsAssembly"),
                     col("bucket_date")).agg(sum("Quantity").alias("Quantity"), sum("Value").alias("Value")).withColumn(
            "BucketDate",
            date_format(col('bucket_date'), 'yyyy-MM-dd')).drop(
            'bucket_date')

        self.aurora_params.update({"aurora_table_name": 'DemandQuarterly'})
        self.spark_utils.logging.info(f"Writing results into Aurora {self.aurora_params['aurora_table_name']}")
        self.spark_utils.write_to_aurora(demand_quarterly_df, self.aurora_params)
        s3_params['s3path'] = self.s3_root_path + f'incontrol/demandtypequarterly/{self.snapshot_date}'
        self.spark_utils.write_to_s3(demand_df, s3_params)

        self.spark_utils.logging.info("Process Completed")
        self.spark_utils.logging.info("Updating LatestSnapshot table")
        self.spark_utils.update_snapshot_table(self.snapshot_date,
                                               dict(self.aurora_params, **{"aurora_table_name": "DemandWeekly"}))
        self.spark_utils.update_snapshot_table(self.snapshot_date,
                                               dict(self.aurora_params, **{"aurora_table_name": "DemandMonthly"}))
        self.spark_utils.update_snapshot_table(self.snapshot_date,
                                               dict(self.aurora_params, **{"aurora_table_name": "DemandQuarterly"}))


if __name__ == "__main__":
    snapshot_date, aurora_database_name, secrets_arn, region_name, \
    s3_root_path, util_script_path = get_parameters()

    spark_session = SparkSession.builder.getOrCreate()
    spark_session.sparkContext.addPyFile(util_script_path)
    spark_utils = import_module('spark_utils')
    aurora_host, aurora_user, aurora_pwd = spark_utils.get_secrets(secrets_arn, region_name)
    data_provider = IndependentDemandDataProvider(spark_session, spark_utils, s3_root_path, snapshot_date)
    base_aurora_params = {"aurora_database_name": aurora_database_name, "aurora_table_name": 'DemandWeekly',
                          "aurora_host": aurora_host, "aurora_user": aurora_user, "aurora_pwd": aurora_pwd,
                          "snapshot_date": snapshot_date, "drop_snapshot_date": False}
    data_grid_pipeline = IndependentDemandPipeline(data_provider, base_aurora_params, s3_root_path,
                                                   snapshot_date)
    data_grid_pipeline.run_pipeline()
