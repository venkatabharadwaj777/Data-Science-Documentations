from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import FloatType, DateType, ArrayType, StringType
from importlib import import_module
from pyspark import StorageLevel
from datetime import timedelta
from math import ceil
from datetime import datetime
import argparse


def get_parameters():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--snapshotdt", dest="snapshotdt", metavar="9999-01-01",
                        help="Date in Y-MM-DD format for which query needs to run. If no Date is provided it will "
                             "run for today", required=False)
    parser.add_argument("--s3root_path", dest="s3root_path", metavar="s3a://bucket_name/object_path",
                        help="Bucket and object path for writing waterfall component result data", required=False)
    parser.add_argument("--secrets_arn", dest="secrets_arn",
                        help="Secrets name to retrieve Aurora Credentials", required=False)
    parser.add_argument("--region_name", dest="region_name",
                        help="AWS Region")
    parser.add_argument("--s3_output_format", dest="s3_output_format", metavar="csv",
                        help="CSV or PARQUET", default='csv')
    parser.add_argument("--header_aurora_table_name", dest="header_aurora_table_name",
                        help="Database Header Table Name on the target DB")
    parser.add_argument("--bucket_aurora_table_name", dest="bucket_aurora_table_name",
                        help="Database Bucket Table Name on the target DB")
    parser.add_argument("--aurora_database_name", dest="aurora_database_name", metavar="Y or N",
                        help="If Y, then we write to aurora, if N - to s3")
    parser.add_argument("--util_script_path", dest="util_script_path",
                        help="Local path to util script")
    args = parser.parse_args()
    return args.util_script_path, args.snapshotdt, args.s3root_path, args.secrets_arn, args.region_name, \
           args.s3_output_format, args.header_aurora_table_name, args.bucket_aurora_table_name, \
           args.aurora_database_name


class ComponentWaterfallDataProvider:

    def __init__(self, spark):
        self.spark = spark

    @staticmethod
    def add_material_key(data, drop_material_columns=True):
        data = data.withColumn("MaterialKey", concat_ws("_", col("datasourceid"),
                                                        col("plantcode"), col("materialcode")))
        if drop_material_columns:
            data = data.drop("materialcode", "plantcode", "datasourceid")
        return data

    def get_mrp_data(self):
        mrp_data = self.spark.sql("select datasourceid, plantcode, materialcode, quantity, deliveryfinishdts"
                                  " from incontrol.vw_sl_mrp_tmp "
                                  "where processingrule='Regular' and deliveryfinishdts is not null and mrptypestdcode "
                                  "in ('Delivery', 'Independent Requirement', 'Sales Agreement','Sales Order',"
                                  "'Allocation','Backflush Dependent Requirement', 'Dependent Requirement',"
                                  "'Dependent Reservation','Interplant Transfer Order','SubContractor Requirement')"
                                  " and profitcenter is not null")
        mrp_data = self.add_material_key(mrp_data)
        return mrp_data

    def get_materials_lead_time_and_quantities(self):
        materials_data = self.spark.sql(
            'select datasourceid, plantcode, materialcode, safetytimeindicator, safetyleadtime, reorderpointqty '
            'from dimensions.vw_sl_materials')
        materials_data = self.add_material_key(materials_data)
        return materials_data

    def get_ha_mondays_details(self):
        ha_mondays_data = self.spark.sql(
            'select marc_matnr as component, marc_werks as plant, marc_eisbe as safetystockqty, '
            'marc_bstmi as minimumorderqty, marc_bstrf as orderincrement, marc_plifz as fixedleadtime '
            'from incontrol.ha_parts_mondays_tmp')
        return ha_mondays_data

    def get_all_materials(self):
        all_materials = self.spark.sql(
            'select distinct datasourceid, plantcode, materialcode, profitcenter from incontrol.vw_sl_inventory_tmp '
            'where quantity > 0 and profitcenter is not null '
            'union '
            'select distinct datasourceid, plantcode, materialcode, profitcenter from incontrol.vw_sl_mrp_tmp '
            'where quantity > 0  and profitcenter is not null'
        )
        all_materials = self.add_material_key(all_materials, drop_material_columns=False)
        return all_materials

    def get_agedinventory_data(self):
        agedinv_data = self.spark.sql(
            'select distinct datasourceid, plantcode, materialcode, onhandquantitynonconsigned '
            'as current_total, onhandquantityconsigned from incontrol.vw_sl_agedinventory_tmp')
        agedinv_data = self.add_material_key(agedinv_data)
        return agedinv_data

    def get_79mondays_data(self):
        mondays_data = self.spark.sql('select wfplant, wfmaterial, wfshipment_qty, wfconsump_qty '
                                      'from incontrol.vw_conship_79mondays_tmp')
        return mondays_data


class ComponentWaterfallPipeline:

    def __init__(self, data_provider, spark_utils, pipeline_configs):
        self.data_provider = data_provider
        self.snapshot_date, self.s3root_path, self.secrets_arn, self.region_name, \
            self.s3_output_format, self.header_aurora_table_name,  self.bucket_aurora_table_name, \
            self.aurora_database_name = pipeline_configs
        self.spark_utils = spark_utils

    # return bucket date based on deliveryfinishdts
    @staticmethod
    def get_bucket_monday_date(date_col):
        return when(date_format(date_col, 'E') != 'Mon', date_sub(next_day(date_col, 'monday'), 7)) \
            .otherwise(date_col)

    # return all bucket dates between snapshot date and max deliveryfinishdts within material
    @staticmethod
    def get_bucket_dates(start_date, end_date):
        zero_demand_default_weeks = 52
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
        if end_date:
            end_date = datetime.strptime(end_date, '%Y-%m-%d')
            num_of_weeks = ceil(((end_date - start_date).days + 1) / 7)
        else:
            num_of_weeks = zero_demand_default_weeks

        bucket_dates = [(start_date + timedelta(weeks=n)).strftime('%Y-%m-%d') for n in range(num_of_weeks)]
        return bucket_dates

    def get_mrp_with_lead_time(self):
        all_materials = self.data_provider.get_all_materials()
        mrp_components = self.data_provider.get_mrp_data()

        demand_info = all_materials.join(mrp_components, ['MaterialKey'], how='left_outer') \
            .withColumn("profitplant", concat(coalesce(col("profitcenter"), lit("")), lit("-"), col('plantcode'))) \
            .withColumn("deliveryfinishdts",
                        when(col("deliveryfinishdts") < self.snapshot_date, lit(self.snapshot_date))
                        .otherwise(col("deliveryfinishdts"))
                        )
        materials_lead_time = self.data_provider.get_materials_lead_time_and_quantities()
        ha_mondays_data = self.data_provider.get_ha_mondays_details()

        demand_info = demand_info.join(materials_lead_time, ['MaterialKey'], how='left_outer') \
            .join(ha_mondays_data, (demand_info.plantcode == ha_mondays_data.plant) &
                  (demand_info.materialcode == ha_mondays_data.component) &
                  (demand_info.datasourceid == 6), how='left_outer')\
            .withColumn("leadtime",
                        when(col("safetytimeindicator") != " ",
                             coalesce(col("safetyleadtime"), lit(0)) + coalesce(col("fixedleadtime"), lit(0)))
                        .otherwise(col("fixedleadtime"))) \
            .withColumn('snapshotdt', lit(self.snapshot_date))\
            .drop("safetytimeindicator", "safetyleadtime", "fixedleadtime", "plant",  "component") \
            .persist(StorageLevel.MEMORY_AND_DISK)
        return demand_info

    def get_bucket_cw_data(self, demand_info):
        get_bucket_dates_udf = udf(f=self.get_bucket_dates, returnType=ArrayType(elementType=StringType()))

        # get all buckets dates
        all_date_buckets = demand_info \
            .withColumn("deliveryfinishdts_timestamp", col('deliveryfinishdts').cast("timestamp")) \
            .groupBy('MaterialKey', 'datasourceid', 'plantcode', 'materialcode', 'profitplant', 'profitcenter', 'snapshotdt') \
            .agg(max('deliveryfinishdts_timestamp').alias("final_demand_date")) \
            .withColumn("final_demand_date", from_unixtime(unix_timestamp(col("final_demand_date")), "yyyy-MM-dd")) \
            .withColumn("bucket_dates",
                        get_bucket_dates_udf(col('snapshotdt'),
                                             from_unixtime(unix_timestamp(col("final_demand_date")), "yyyy-MM-dd"))) \
            .withColumn("bucket_date", explode(col('bucket_dates'))) \
            .withColumn("demand", lit(0.0)) \
            .drop("bucket_dates", 'final_demand_date')

        # get buckets for existing demand
        bucket_demand = demand_info \
            .withColumn('bucket_date', self.get_bucket_monday_date(col('deliveryfinishdts')).cast(DateType())) \
            .groupBy('MaterialKey', 'datasourceid', 'plantcode', 'materialcode', 'bucket_date', 'profitplant',
                     'profitcenter', 'snapshotdt') \
            .agg(sum('quantity').alias('demand')) \
            .withColumn("demand", col("demand").cast(FloatType()))

        bucket_demand_result = all_date_buckets \
            .join(bucket_demand, ['MaterialKey', 'bucket_date'], how='left_outer') \
            .select(all_date_buckets.datasourceid.alias("DataSourceId"),
                    all_date_buckets.plantcode.alias("PlantCode"),
                    all_date_buckets.materialcode.alias("MaterialCode"),
                    all_date_buckets.profitplant.alias("ProfitPlant"),
                    all_date_buckets.profitcenter.alias("ProfitCenter"),
                    all_date_buckets.snapshotdt.alias("SnapshotDt"),
                    all_date_buckets.bucket_date.alias("BucketDate"),
                    when(bucket_demand.demand.isNotNull(), bucket_demand.demand)
                    .otherwise(all_date_buckets.demand).alias("Demand")
                    )
        return bucket_demand_result

    def get_header_cw_data(self, demand_info):
        # calculating lead time demand, including last date
        total_lt_demand = demand_info \
            .withColumn('final_deliverydt', expr('date_add(snapshotdt, leadtime + 1)')) \
            .filter('deliveryfinishdts < final_deliverydt') \
            .groupby('MaterialKey').agg(sum('quantity').alias('total_lt_demand'))

        header_demand = demand_info \
            .groupby('MaterialKey', 'datasourceid', 'plantcode', 'materialcode', 'profitplant', 'profitcenter',
                     'snapshotdt', 'leadtime', 'minimumorderqty', 'orderincrement', 'reorderpointqty', 'safetystockqty') \
            .agg(sum('quantity').alias('total_demand'))

        header_demand = header_demand.join(total_lt_demand, ['MaterialKey'], how='left_outer')\
            .withColumn("total_demand", coalesce("total_demand", lit(0.0)))

        aged_inventory_data = self.data_provider.get_agedinventory_data()
        mondays79data = self.data_provider.get_79mondays_data()

        header_demand = header_demand \
            .join(aged_inventory_data, ['MaterialKey'], how='left_outer')

        header_demand = header_demand \
            .join(mondays79data, (header_demand.plantcode == mondays79data.wfplant) &
                  (header_demand.materialcode == mondays79data.wfmaterial) &
                  (header_demand.datasourceid == 6), how='left_outer') \
            .select(header_demand.datasourceid.alias("DataSourceId"),
                    header_demand.plantcode.alias("PlantCode"),
                    header_demand.materialcode.alias("MaterialCode"),
                    header_demand.profitcenter.alias("ProfitCenter"),
                    header_demand.leadtime.alias("LeadTime"),
                    coalesce(header_demand.current_total.cast(FloatType()), lit(0.0))\
                        .alias("NonConsignedNettableOnHand"),
                    coalesce(header_demand.onhandquantityconsigned.cast(FloatType()), lit(0.0))
                        .alias("ConsignedNettableOnHand"),
                    coalesce(header_demand.minimumorderqty.cast(FloatType()), lit(0.0)).alias("MinimumOrderQty"),
                    coalesce(header_demand.orderincrement.cast(FloatType()), lit(0.0)).alias("OrderIncrement"),
                    coalesce(header_demand.reorderpointqty.cast(FloatType()), lit(0.0)).alias("ReorderPointQty"),
                    coalesce(header_demand.safetystockqty.cast(FloatType()), lit(0.0)).alias("SafetyStockQty"),
                    header_demand.snapshotdt.cast(DateType()).alias("SnapshotDt"),
                    coalesce(header_demand.total_lt_demand.cast(FloatType()),  lit(0.0)).alias("TotalLtDemand"),
                    header_demand.total_demand.cast(FloatType()).alias("TotalDemand"),
                    header_demand.profitplant.alias("ProfitPlant"),
                    coalesce(mondays79data.wfshipment_qty.cast(FloatType()), lit(0.0)).alias("PriorWeekShipment"),
                    coalesce(mondays79data.wfconsump_qty.cast(FloatType()), lit(0.0)).alias("PriorWeekConsumption")
                    )
        return header_demand.cache()

    def write_cw_data(self, cw_data, s3_params, aurora_params, write_to_s3):
        if write_to_s3:
            s3_params['s3path'] = s3_params['s3_root_path']
            self.spark_utils.write_to_s3(cw_data, s3_params)
        cw_data = cw_data.drop("ProfitPlant")
        self.spark_utils.write_to_aurora(cw_data, aurora_params)

    def run_pipeline(self):
        self.spark_utils.configure_logging(file_name="component_waterfall")
        aurora_host, aurora_user, aurora_pwd = self.spark_utils.get_secrets(self.secrets_arn, self.region_name)

        snapshot_date = self.snapshot_date if self.snapshot_date else datetime.today().strftime("%Y-%m-%d")
        s3path = self.s3root_path + "/YYYY=" + snapshot_date[:4] + "/MM=" + \
                 snapshot_date[5:7] + "/DD=" + snapshot_date[8:]

        s3_params = {"s3_output_format": self.s3_output_format, "s3_root_path": s3path,
                     "is_partitioned": False}

        aurora_params = {"aurora_database_name": self.aurora_database_name, "aurora_pwd": aurora_pwd,
                         "aurora_table_name": self.bucket_aurora_table_name, "aurora_host": aurora_host,
                         "aurora_user": aurora_user, "snapshot_date": snapshot_date, "snapshot_date_column": "SnapshotDt"}

        self.spark_utils.logging.info("Snapshot date:   %s" % snapshot_date)
        self.spark_utils.logging.info("S3 root path:   %s" % s3path)

        # retrieve base demand data with lead time
        demand_info = self.get_mrp_with_lead_time()

        # demand data for monday buckets
        bucket_demand_result = self.get_bucket_cw_data(demand_info)
        self.write_cw_data(bucket_demand_result, s3_params, aurora_params, write_to_s3=False)

        # demand header data
        header_demand = self.get_header_cw_data(demand_info)
        aurora_params['aurora_table_name'] = self.header_aurora_table_name
        self.write_cw_data(header_demand, s3_params, aurora_params, write_to_s3=True)
        self.spark_utils.logging.info("Process Completed")
        self.spark_utils.logging.info("Updating LatestSnapshot table")
        self.spark_utils.update_snapshot_table(self.snapshot_date,
                                               dict(aurora_params, **{"aurora_table_name": "ComponentWaterfall"}))


if __name__ == "__main__":
    util_script_path, *configs = get_parameters()
    spark_session = SparkSession.builder.getOrCreate()
    spark_session.sparkContext.addPyFile(util_script_path)
    spark_util = import_module('spark_utils')

    cw_data_provider = ComponentWaterfallDataProvider(spark_session)
    component_waterfall_pipeline = ComponentWaterfallPipeline(cw_data_provider, spark_util, configs)
    component_waterfall_pipeline.run_pipeline()
