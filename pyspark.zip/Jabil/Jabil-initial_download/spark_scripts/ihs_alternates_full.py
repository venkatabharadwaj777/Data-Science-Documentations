

from pyspark.sql.types import DateType, DoubleType
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql import HiveContext
#only for writing to HFDS
spark = SparkSession.builder.getOrCreate()

sqlContext = HiveContext(spark)


query = """     SELECT part_obj_id,part,regexp_replace(part,'[^a-zA-Z0-9]','') as formatted_ihsmpn,fff_code,updated_on, rownum
        FROM
  (SELECT a.part_obj_id,a.part,a.fff_code,a.updated_on,
  row_number() OVER (PARTITION BY a.part_obj_id ORDER BY updated_on DESC) rownum
   FROM persistent.ihs_region_alternates_code a
   WHERE a.fff_code != '') b
   WHERE b.rownum = 1
"""

ihs_alternate_current = spark.sql(query)

ihs_alternate_current.write.format("parquet").mode("overwrite").saveAsTable("incontrol.ihs_alternate_current")

alternate = spark.sql("select part_obj_id, part ,formatted_ihsmpn, fff_code from incontrol.ihs_alternate_current")
alternate2 = alternate
basic = spark.sql("select manufacturer_name, objectid from incontrol.ihs_basic_landing where status in ('Active', 'Active-Unconfirmed')")
basic2 = spark.sql("select manufacturer_name, objectid from incontrol.ihs_basic_landing")
basic = basic.withColumnRenamed("manufacturer_name", "ihsalternatemanufacturername")
basic2 = basic2.withColumnRenamed("manufacturer_name", "ihsmpnmanufacturername")
df1 = alternate.join(basic2, (basic2.objectid == alternate.part_obj_id))
df2 = alternate2.join(basic, (basic.objectid == alternate2.part_obj_id))

df1 = df1.withColumnRenamed("part", "ihsmpn")
df2 = df2.withColumnRenamed("part", "ihsalternatepart")

ihs_alternate_full = df1.join(df2, ((df1.fff_code == df2.fff_code) & (df1.ihsmpn != df2.ihsalternatepart)))\
        .select(df1.part_obj_id, trim(df1.ihsmpn).alias("ihsmpn"), trim(df1.formatted_ihsmpn).alias("formatted_ihsmpn"), df1.ihsmpnmanufacturername, df1.fff_code, df2.ihsalternatepart, df2.ihsalternatemanufacturername)

# only for writing to HDFSC -- Do not over write the alternate_full table as PIP team is using this
ihs_alternate_full.write.format("parquet").mode("overwrite").saveAsTable("incontrol.ihs_alternate_full")

cds = spark.sql("SELECT DISTINCT trim(cds.corporationdsname) as corporationdsname, c.corporationid, \
 trim(c.corporationname) as JabilCorporationName,  \
 trim(mp.mfrpartcode) as JabilManufacturerPartCode \
 , mp.mfrpartid FROM incontrol.vw_sl_jabildb_corporationds cds \
 INNER JOIN  incontrol.vw_sl_jabildb_corporation c ON cds.corporationid = c.corporationid  \
 AND cds.datasourceid = 21 AND cds.deleteflag = 'false' \
 INNER JOIN incontrol.vw_sl_mfrpart mp ON mp.corporationid = c.corporationid AND mp.deleteflag = 'false' ")


Ihs = spark.sql("select trim(manufacturer_part_number) as manufacturer_part_number, \
        trim(manufacturer_name) as manufacturer_name, estimated_yteol, date_of_intro, life_cycle_stage from incontrol.ihs_lifecycle ihs ")

# Incomplete
alt_df = ihs_alternate_full.join(cds, ((cds.JabilManufacturerPartCode == ihs_alternate_full.ihsmpn) \
        & (ihs_alternate_full.ihsmpnmanufacturername == cds.corporationdsname)), how='inner')

ihs_alternate_priority1_2 = alt_df.join(Ihs, ((alt_df.ihsalternatepart == Ihs.manufacturer_part_number) \
        & (alt_df.JabilCorporationName == Ihs.manufacturer_name)), how = 'left_outer')\
        .select(col("mfrpartid"), col("JabilManufacturerPartCode"), col("JabilCorporationName"), col("part_obj_id"), \
        col("ihsmpn").alias("IhsManufacturerPartcode"), col("JabilCorporationName").alias("IhsMpnManufacturerName"), \
        col("fff_code"), col("ihsalternatepart").alias("IhsAlternatePart"), \
        col("JabilCorporationName").alias("IhsAlternateManufacturerName"),col("estimated_yteol"),
                col("date_of_intro"),col("life_cycle_stage"))



# only for writing to HDFSC
ihs_alternate_priority1_2.write.format("parquet").mode("overwrite").saveAsTable("incontrol.ihs_alternate_priority1_2")

