from pyspark.sql.functions import col, upper, concat_ws, lit
from importlib import import_module
from datetime import datetime
import argparse
import boto3
import math


def get_parameters():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--snapshotdate", dest="snapshot_date", metavar="9999-01-01",
                        help="Date in Y-MM-DD format for which query needs to run. If no Date is provided it will "
                             "run for today", required=False)
    parser.add_argument("--target_s3_path", dest="target_s3_path", metavar="s3a://bucket_name/object_path",
                        help="Bucket and object path for writing result data", required=False)
    parser.add_argument("--read_s3_root_path", dest="read_s3_root_path", metavar="s3a://bucket_name/object_path",
                        help="Format of result data written in s3", required=False)
    parser.add_argument("--write_s3_root_path", dest="write_s3_root_path", metavar="s3a://bucket_name/object_path",
                        help="Format of result data written in s3", required=False)
    parser.add_argument("--util_script_path", dest="util_script_path",
                        help="Local path to util script")
    parser.add_argument("--region_name", dest="region_name",
                        help="AWS Region")

    args = parser.parse_args()
    return args.snapshot_date, args.target_s3_path, args.read_s3_root_path, args.write_s3_root_path, \
           args.util_script_path, args.region_name


if __name__ == "__main__":
    from pyspark.sql import SparkSession

    spark = SparkSession.builder.getOrCreate()
    snapshot_date, target_s3_path, read_s3_root_path, write_s3_root_path, \
        util_script_path, region_name = get_parameters()
    spark.sparkContext.addPyFile(util_script_path)
    spark_utils = import_module('spark_utils')
    snapshot_date_parsed = datetime.strptime(snapshot_date, '%Y-%m-%d')
    quarter = math.ceil(snapshot_date_parsed.month / 3.)
    demand_data = spark.read.format("parquet").load(read_s3_root_path + "scm/mrp/YYYY=" +
                                                    snapshot_date[:4] + "/MM=" +
                                                    snapshot_date[5:7] + "/DD=" +
                                                    snapshot_date[8:]) \
        .select("datasourceid", "plantcode", "materialcode", "snapshotdate", "processingrule", "quantity",
                "mrptypestdcode") \
        .filter(col("quantity") > 0).filter(upper(col("processingrule")) == "REGULAR") \
        .filter(col("mrptypestdcode").isin(['Allocation', 'Backflush Dependent Requirement',
                                            'Dependent Requirement', 'Dependent Reservation',
                                            'Interplant Transfer Order', 'SubContractor Requirement'])) \
        .select(concat_ws("_", col("datasourceid"), col("plantcode"), col("materialcode")).alias("MaterialKey"), ) \
        .distinct() \
        .withColumn("Year", lit(snapshot_date_parsed.year)) \
        .withColumn("Quarter", lit(quarter))

    quarter = str(quarter)
    quarter_data_exists = False
    s3_target = write_s3_root_path + target_s3_path + "/YYYY=" + snapshot_date[:4] + "/QQ=" + quarter
    try:
        quarter_data = spark.read.format("csv").option("header", "true")\
            .load(s3_target)
        if quarter_data.count() > 0:
            demand_data = demand_data.unionByName(quarter_data).distinct()
            quarter_data_exists = True
    except:
        print("No records for current quarter")

    if quarter_data_exists:
        s3path_new = s3_target + "_new/"
        demand_data.repartition(1).write.mode("overwrite").format("csv").option("header", "true").save(s3path_new)

        s3 = boto3.resource('s3', region_name=region_name)
        bucket_name = s3path_new[6:35]
        new_key_folder = s3path_new[36:-5] + "/"
        if len([obj for obj in s3.Bucket(bucket_name).objects.filter(Prefix=new_key_folder + "part-")]) > 0:
            new_key_part_file = [obj for obj in s3.Bucket(bucket_name).objects.filter(Prefix=new_key_folder + "part-")][0].key
            s3.Bucket(bucket_name).Object(new_key_part_file).delete()
            s3.Bucket(bucket_name).Object(new_key_folder + "_SUCCESS").delete()

        old_key_folder = s3path_new[36:]
        old_key_part_file = [obj for obj in s3.Bucket(bucket_name).objects.filter(Prefix=old_key_folder + "part-")][0].key

        s3.Bucket(bucket_name).Object(new_key_folder + "result_file.csv")\
            .copy_from(CopySource={'Bucket': bucket_name, 'Key': old_key_part_file})
        s3.Bucket(bucket_name).Object(old_key_part_file).delete()
        s3.Bucket(bucket_name).Object(old_key_folder+"_SUCCESS").delete()
        s3.Bucket(bucket_name).Object(old_key_folder).delete()

    else:
        demand_data.repartition(1).write.mode("overwrite").format("csv").option("header", "true").save(s3_target)
