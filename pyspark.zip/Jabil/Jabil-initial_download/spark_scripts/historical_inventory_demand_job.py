from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import StringType, DateType, DoubleType, IntegerType
from pyspark.sql.window import Window
from datetime import datetime
import argparse


def get_parameters():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--snapshotdate", dest="snapshot_date", metavar="9999-01-01",
                        help="Date in Y-MM-DD format for which query needs to run. If no Date is provided it will "
                             "run for today", required=False)
    parser.add_argument("--s3_root_path", dest="s3_root_path", metavar="s3a://bucket_name/object_path",
                        help="Format of result data written in s3", required=False)
    parser.add_argument("--region_name", dest="region_name",
                        help="AWS Region")
    parser.add_argument("--secrets_arn", dest="secrets_arn",
                        help="Secrets name to retrieve Aurora Credentials", required=False)
    parser.add_argument("--aurora_database_name", dest="aurora_database_name",
                        help="Database name for material snapshot data")
    parser.add_argument("--util_script_path", dest="util_script_path",
                        help="Local path to util script")
    parser.add_argument("--inventory_demand_table_name", dest="inventory_demand_table_name",
                        help="Table name of historical inventory vs demand data")
    parser.add_argument("--inventory_demand_summary_table_name", dest="inventory_demand_summary_table_name",
                        help="Table name of historical inventory vs demand data summary")
    parser.add_argument("--data_source", dest="data_source", required=True,
                        help="Source of raw data: 'S3' or 'EIP' ")

    args = parser.parse_args()
    return args.snapshot_date, args.aurora_database_name, args.secrets_arn, args.region_name, args.s3_root_path, \
           args.util_script_path, args.inventory_demand_table_name, args.data_source, \
           args.inventory_demand_summary_table_name


def columns_to_camel_case(data, columns):
    for data_col in columns:
        data = data.withColumnRenamed(data_col, data_col[0].lower() + data_col[1:])
    return data


def columns_to_pascal_case(data, columns):
    for data_col in columns:
        data = data.withColumnRenamed(data_col, data_col[0].upper() + data_col[1:])
    return data


def not_material_key_columns(columns):
    return list(filter(lambda column_name: column_name.lower() not in ['datasourceid', 'plantcode',
                                                                       'materialcode', 'materialKey'],
                       columns))


def read_s3_data(spark, s3_root_path, snapshot_date, domain_path, columns, drop_material_code=True, is_col_upper=False):
    s3path = s3_root_path + domain_path + \
             "/YYYY=" + snapshot_date[:4] + "/MM=" + snapshot_date[5:7] + "/DD=" + snapshot_date[8:]
    data_df = spark.read.format("parquet").load(s3path).select(columns)

    if is_col_upper:
        data_df = columns_to_camel_case(data_df, columns)
        data_df = data_df.withColumnRenamed("dataSourceId", "datasourceid") \
            .withColumnRenamed("plantCode", "plantcode") \
            .withColumnRenamed("materialCode", "materialcode")

    data_df = data_df.withColumn("materialKey", concat(col("datasourceid"), lit("_"),
                                                       col("plantcode"), lit("_"),
                                                       col("materialcode")))
    if drop_material_code:
        data_df = data_df.drop('datasourceid', 'materialcode', 'plantcode')
    else:
        data_df = data_df.withColumnRenamed("datasourceid", "dataSourceId") \
            .withColumnRenamed("materialcode", "materialCode") \
            .withColumnRenamed("plantcode", "plantCode")
    return data_df.repartition("materialKey").repartition(100)


def read_eip_data(spark, query, drop_material_code=True):
    data = spark.sql(query)
    data = data.withColumn("materialKey", concat(col("dataSourceId"), lit("_"),
                                                 col("plantCode"), lit("_"),
                                                 col("materialCode")))
    if drop_material_code:
        data = data.drop('dataSourceId', 'materialCode', 'plantCode')
    return data.repartition("materialKey").repartition(100)


def get_materials_data(spark, snapshot_date, s3_root_path, data_source):
    if data_source == 'S3':
        materials_columns = ['DataSourceId', 'PlantCode', 'MaterialCode', 'MinimumLotSize',
                             'SafetyStockQuantity', 'DockToStockLeadTime', 'SafetyLeadTime',
                             'SafetyTimeIndicator', 'FixedLeadTime', 'snapshotdate']
        materials_data = read_s3_data(spark, s3_root_path, snapshot_date, "dimensions/materials", materials_columns,
                                      drop_material_code=False, is_col_upper=True) \
            .withColumnRenamed("snapshotdate", "snapshotDate")
    else:
        sql = "select datasourceid as dataSourceId, plantcode as plantCode, materialcode as materialCode," \
              "minimumlotsize as minimumLotSize, safetystockqty as safetyStockQuantity, " \
              "docktostockleadtime as dockToStockLeadTime," \
              "safetyleadtime as safetyLeadTime, cast(safetytimeindicator as int) as safetyTimeIndicator," \
              "fixedleadtime as fixedLeadTime, '%s' as snapshotDate " \
              " from dimensions.vw_sl_materials" % snapshot_date
        materials_data = read_eip_data(spark, sql, drop_material_code=False)

    materials_data = materials_data \
        .withColumn("snapshotDate", col('snapshotDate').cast(StringType()).substr(1, 10)) \
        .withColumn("snapshotDate", col("snapshotDate").cast(DateType())) \
        .withColumn("leadTimeTotal",
                    coalesce(col("fixedLeadTime"), lit(0)) +
                    coalesce(col("dockToStockLeadTime"), lit(0)) +
                    when(col("safetyTimeIndicator").isin([1, 2]), col("safetyLeadTime")).otherwise(lit(0))) \
        .drop('dockToStockLeadTime', 'safetyLeadTime', 'safetyTimeIndicator')

    return materials_data


def get_on_hand_total_data(spark, snapshot_date, s3_root_path, data_source):
    if data_source == "S3":
        agedinventory_columns = ['datasourceid', 'plantcode', 'materialcode', 'onhandquantitynonconsigned']
        agedinventory_data = read_s3_data(spark, s3_root_path, snapshot_date, "scm/agedinventory",
                                          agedinventory_columns) \
            .withColumnRenamed("onhandquantitynonconsigned", "onHandQuantityNonConsigned")
    else:
        sql = "select datasourceid as dataSourceId, " \
              " plantcode as plantCode, " \
              " materialcode as materialCode, " \
              " onhandquantitynonconsigned as onHandQuantityNonConsigned" \
              " from incontrol.vw_sl_agedinventory_tmp"
        agedinventory_data = read_eip_data(spark, sql)

    return agedinventory_data.select("materialKey", "onHandQuantityNonConsigned") \
        .groupby("materialKey") \
        .agg(first("onHandQuantityNonConsigned").alias("onHandTotal"))


def aggregate_demand_data(demand_data):
    demand_records_count = demand_data.filter(upper(col("processingRule")) == 'REGULAR') \
        .groupBy("materialKey") \
        .agg(count("*").alias("demandRecordsCount"))

    demand_summary_by_deliveryfdts = demand_data \
        .withColumn("maxCancellationLeadTime",
                    max("cancellationLeadTime").over(Window().partitionBy("materialKey", "deliveryFinishDts"))) \
        .groupBy("materialKey", "deliveryFinishDts", "snapshotDate") \
        .agg(
            sum(when((col("mrpTypeStdCode") == 'Purchase Order') |
                     ((col("mrpTypeStdCode") == 'Purchase Agreement') & (
                             col("deliveryFinishDts") < col("fixedTimeLimit"))),
                     col("quantity")).otherwise(lit(0))).alias("onOrder"),

            sum(when(((col("mrpTypeStdCode") == 'Purchase Order') |
                      ((col("mrpTypeStdCode") == 'Purchase Agreement') & (
                              col("deliveryFinishDts") < col("fixedTimeLimit"))))
                     & (col("ncnrFlag") == 'TRUE'),
                     col("quantity")).otherwise(lit(0))).alias("ncnrOnOrder"),

            sum(when((upper(col("processingRule")) == 'REGULAR') &
                     (~col("mrpTypeStdCode").isin(['Purchase Agreement', 'Purchase Order'])),
                     col("quantity")).otherwise(lit(0))).alias("demandQuantity"),

            sum(when((upper(col("processingRule")) == 'REGULAR') &
                     (~col("mrpTypeStdCode").isin(['Purchase Agreement', 'Purchase Order'])) &
                     (datediff(col("deliveryFinishDts"), col("snapshotDate")) <= col("leadTimeTotal")),
                     col("quantity")).otherwise(lit(0))).alias("demandInLeadTime"),

            collect_set(
                when((col("cancellationLeadTime").isNotNull()) &
                     (col("cancellationLeadTime") == col("maxCancellationLeadTime")), col("ncnrFlag"))
                    .otherwise(None)).alias("ncnrFlags"),

            max("cancellationLeadTime").alias("cancellationLeadTime")
        ) \
        .withColumn("ncnrFlag", when(array_contains("ncnrFlags", "TRUE"), lit("TRUE")).
                    otherwise(when(array_contains("ncnrFlags", "FALSE"), lit("FALSE")).otherwise(lit(None)))
                    ) \
        .drop("snapshotDate", "ncnrFlags")

    return {"count": demand_records_count, "summary": demand_summary_by_deliveryfdts}


def get_demand_data(spark, snapshot_date, s3_root_path, data_source, materials_lead_time):
    if data_source == 'S3':
        on_order_columns = ['datasourceid', 'materialcode', 'plantcode', 'mrptypestdcode', 'deliveryfinishdts',
                            'quantity', 'cancellationleadtime', 'ncnrflag', 'processingrule']
        mrp_data = read_s3_data(spark, s3_root_path, snapshot_date, "scm/mrp", on_order_columns) \
            .withColumnRenamed("mrptypestdcode", "mrpTypeStdCode") \
            .withColumnRenamed("deliveryfinishdts", "deliveryFinishDts") \
            .withColumnRenamed("cancellationleadtime", "cancellationLeadTime") \
            .withColumnRenamed("ncnrflag", "ncnrFlag") \
            .withColumnRenamed("processingrule", "processingRule")
    else:
        sql = "select datasourceid as dataSourceId, " \
              "materialcode as materialCode, " \
              "plantcode as plantCode, " \
              "mrptypestdcode as mrpTypeStdCode, " \
              "deliveryfinishdts as deliveryFinishDts, " \
              "quantity, " \
              "cancellationleadtime as cancellationLeadTime, " \
              "ncnrflag as ncnrFlag, " \
              "processingrule as processingRule " \
              "from incontrol.vw_sl_mrp_tmp " \
              "where mrptypestdcode != 'SubContractor Requirement' OR ( mrpplanningsegment != '' " \
              "AND mrpplanningsegment IS NOT NULL)"
        mrp_data = read_eip_data(spark, sql)

    demand_data = mrp_data.join(materials_lead_time, ["materialKey"]) \
        .withColumn("deliveryFinishDts", col("deliveryFinishDts").cast(DateType())) \
        .withColumn("cancellationLeadTime", col("cancellationLeadTime").cast(IntegerType())) \
        .withColumn("fixedLeadTime", coalesce(col("fixedLeadTime"), lit(0))) \
        .withColumn("fixedTimeLimit", expr('date_add(snapshotDate, fixedLeadTime)')) \
        .filter(col("mrpTypeStdCode").isin(['Allocation', 'Backflush Dependent Requirement',
                                            'Dependent Requirement', 'Dependent Reservation',
                                            'Purchase Agreement', 'Purchase Order',
                                            'Interplant Transfer Order', 'Delivery', 'Independent Requirement',
                                            'Sales Agreement', 'Sales Order', 'SubContractor Requirement'])) \
        .cache()

    return aggregate_demand_data(demand_data)


def write_inventory_demand_data(inventory_demand, aurora_params, inventory_demand_table_name, spark_utils):
    aurora_params["aurora_table_name"] = inventory_demand_table_name
    inventory_demand = columns_to_pascal_case(inventory_demand, inventory_demand.columns).repartition(4000)
    spark_utils.write_to_aurora(inventory_demand, aurora_params, )


def run_inventory_demand_job():
    spark = SparkSession.builder.getOrCreate()

    snapshot_date, aurora_database_name, secrets_arn, region_name, s3_root_path, \
        util_script_path, inventory_demand_table_name, data_source, \
        inventory_demand_summary_table_name = get_parameters()
    spark.sparkContext.addPyFile(util_script_path)
    import spark_utils

    spark_utils.configure_logging(file_name="historical_inventory_demand")
    snapshot_date = snapshot_date if snapshot_date else datetime.today().strftime("%Y-%m-%d")
    spark_utils.logging.info("Snapshot date:   %s" % snapshot_date)

    materials_data = get_materials_data(spark, snapshot_date, s3_root_path, data_source)
    mrp_data = get_demand_data(spark, snapshot_date, s3_root_path, data_source,
                               materials_data.select("materialKey", "fixedLeadTime", "leadTimeTotal", "snapshotDate"))
    on_hand_total_data = get_on_hand_total_data(spark, snapshot_date, s3_root_path, data_source)

    inventory_demand_data = materials_data\
        .drop("fixedLeadTime") \
        .join(mrp_data['count'], ['materialKey'], how="left_outer") \
        .join(on_hand_total_data, ['materialKey'], how="left_outer") \
        .filter((col("onHandTotal").isNotNull() & (col("onHandTotal") > 0)) |
                ((col("demandRecordsCount").isNotNull()) & (col("demandRecordsCount") > 0))) \
        .drop("demandRecordsCount") \
        .join(mrp_data['summary'], ['materialKey'], how="left_outer") \
        .fillna(0.0,
                subset=["ncnrOnOrder", "demandQuantity", "onOrder", "demandInLeadTime"]) \
        .withColumn("createdAtUtc", current_timestamp()) \
        .cache()

    aurora_host, aurora_user, aurora_pwd = spark_utils.get_secrets(secrets_arn, region_name)
    aurora_params = {"aurora_database_name": aurora_database_name, "aurora_host": aurora_host,
                     "aurora_user": aurora_user, "aurora_pwd": aurora_pwd, "snapshot_date": snapshot_date,
                     "snapshot_date_column": "SnapshotDate", "drop_snapshot_date": True}

    write_inventory_demand_data(
        inventory_demand_data.drop("safetyStockQuantity", "minimumLotSize", "leadTimeTotal", "onHandTotal"),
        aurora_params, inventory_demand_table_name, spark_utils)

    inventory_demand_summary = inventory_demand_data \
        .groupBy("materialKey", "dataSourceId", "plantCode", "materialCode", "leadTimeTotal",
                 "safetyStockQuantity", "minimumLotSize", "onHandTotal", "snapshotDate") \
        .agg(
            sum("onOrder").alias("onOrderTotal"),
            sum("ncnrOnOrder").alias("ncnrOnOrderTotal"),
            sum("demandQuantity").alias("demandQuantityTotal"),
            sum("demandInLeadTime").alias("demandInLeadTimeTotal")
        ) \
        .withColumn("inventoryTotal", col("onHandTotal") + col("onOrderTotal")) \
        .withColumn("safetyStockQuantity", col("safetyStockQuantity").cast(DoubleType())) \
        .withColumn("minimumLotSize", col("minimumLotSize").cast(DoubleType())) \
        .fillna(0.0, subset=["ncnrOnOrderTotal", "demandQuantityTotal", "inventoryTotal", "onHandTotal",
                             "onOrderTotal", "demandInLeadTimeTotal"])\
        .withColumn("createdAtUtc", current_timestamp())


    write_inventory_demand_data(inventory_demand_summary, aurora_params,
                                inventory_demand_summary_table_name, spark_utils)

    spark_utils.logging.info("Process Completed")
    spark.stop()


def main():
    run_inventory_demand_job()


if __name__ == "__main__":
    main()
