!/bin/bash
# Get the hostname to determine the CLUSTER
case "${HOSTNAME:9:1}" in
  "d")
    # DEV only
    export CLUSTER=dev
    export CLUSTER_CODE=d
    ;;
  "q")
    # STG only
    export CLUSTER=stg
    export CLUSTER_CODE=s
    ;;
  "p")
    # PRD only
    export CLUSTER=prd
    export CLUSTER_CODE=c
    ;;
  *) # not good
    echo "\$HOSTNAME='${HOSTNAME}' unexpected server hostname"
    exit 1
esac
run_date=`date +%Y-%m-%d`
start_date=$(date -d "`date +%y%m%d` -9 day" +%Y-%m-%d)
end_date=$(date -d "`date +%y%m%d` " +%Y-%m-%d)
current_time=`date +"%H%M%S"`
#Evaludating the date interval
diff=$(($(($(date -d "$end_date" "+%s") - $(date -d "$start_date" "+%s"))) / 86400))
path="/eip_interfaces/logs/E_O_Mitigation/$run_date"
conf_path="/eip_interfaces/code/DIF/RDBMS/ComparisonReports/EO_propertyfile.conf"
source /eip_interfaces/code/DIF/RDBMS/ComparisonReports/EOreportmaillist.conf
#creating the directory
if [ -d $path ];then
 echo "Path exists">$path/E_O_script.log
else
 mkdir -p $path
 if [ $? -eq 0 ]; then
   echo "$run_date:Directory created" >$path/E_O_script.log
 else
   echo "Please check the access permission new make new directory"
 fi
fi
echo "The Start date : $start_date and End date: $end_date">>$path/E_O_script.log
#Pulling the table names out of config file
grep "," $conf_path | cut -d "," -f1 | sed "1d">$path/tbl_name.txt
#removing the interval file if exists already

if [ `find $path -name "interval.csv" | wc -l` -ne 0 ];then
rm $path/interval.csv
fi

#getting the date interval as a file
d=;n=0;until [ "$d" = "$end_date" ];do
((n++))
d=$(date -d "$start_date + $n days" +%Y-%m-%d)
echo $d>>$path/interval.csv
done
echo "The table list has been pulled from property file">>$path/E_O_script.log

#prod connection details
impalCon="impala-shell -k --ssl -i hadoop${CLUSTER}"
#generationg the hive query
while read -r tbl
do
param2=`grep "$tbl" $conf_path | cut -d "," -f2`
param3=`grep "$tbl" $conf_path | cut -d "," -f3`
param4=`grep "$tbl" $conf_path | cut -d "," -f4`

echo -n "select ">$path/$tbl.hql
if [ "$param2" != "NULL" ];then
 echo -n "$param2,">>$path/$tbl.hql
fi
echo -n "count(*)">>$path/$tbl.hql
if [ "$param3" != "NULL" -a "$param4" != "NULL" -a "$param2" != "NULL" ];then
 echo -n ",case when count(*)>$param3 and count(*)<$param4 then 'GOOD' else 'BAD' end as status">>$path/$tbl.hql
fi
if [ "$param4" = "NULL" -a "$param3" != "NULL" ];then
 echo -n ",case when count(*)>$param3 then 'GOOD' else 'BAD' end as status">>$path/$tbl.hql
fi
if [ "$param2" != "NULL" ];then
 echo -n " from domains.$tbl where $param2 between '$start_date' and '$end_date' group by $param2 order by $param2">>$path/$tbl.hql
else
 echo -n " from domains.$tbl">>$path/$tbl.hql
fi
 echo -n ";">>$path/$tbl.hql
 echo "$run_date:$tbl query created">>$path/E_O_script.log
done<$path/tbl_name.txt
#evaluating does the query file generated or not
if [ $? -eq 0 ];then
  echo "$run_date:The query file generated without any issue">>$path/E_O_script.log
else
  echo "$run_date:Failed to generate query file">>$path/E_O_script.log
fi

#pushing query to impala
while read -r tbl1
do
$impalCon -f $path/$tbl1.hql --output_delimiter='|' -B -o $path/$tbl1.csv
done<$path/tbl_name.txt
#evaluating does the query file executed or not
if [ $? -eq 0 ];then
  echo "$run_date:The impala executed the query">>$path/E_O_script.log
else
  echo "$run_date:impala failed to execute the queries ">>$path/E_O_script.log
fi
#Getting delta table names
awk -F, '{if($5=="FR" || $5=="DELTA") print $1;}' $conf_path>$path/delta_fr_tables.txt
awk -F, '{if($5=="DELTA") print $1;}' $conf_path>$path/delta_tables.txt
awk -F, '{if($5=="FR") print $1;}' $conf_path >$path/fr_tables.txt

if [ $? -eq 0 ];then
  echo "$run_date:The delta table names have been pulled from the configuration file">>$path/E_O_script.log
else
  echo "$run_date:Failed to pull the delta table names pull from the configuration file">>$path/E_O_script.log
fi

while read -r tbln
do
 if [ `cat $path/${tbln}.csv | wc -l` -eq 0 ]
  then
   echo "||" > $path/${tbln}.csv
 fi
done<$path/delta_fr_tables.txt
#FR table 
while read -r line 
do
awk -v d="$run_date" -F'|' 'FNR==NR{if($1 != ""){print $1"|"$2"|"$3} else {print d"|0|BAD"}}' $path/$line.csv>$path/$line'1'.csv
done<$path/fr_tables.txt

declare -a arr=(`cat "$path/delta_tables.txt"`)
for line in ${arr[@]}
do
awk -F'|' 'FNR==NR{a[$1]=$2;b[$1]=$3;next}{if($1 in a){print $1"|"a[$1]"|"b[$1]} else{print $1"|0|BAD"}}' $path/$line.csv $path/interval.csv>$path/$line'1'.csv
done

if [ $? -eq 0 ];then
  echo "$run_date:The Processed the Delta table and assigned the zero where there is no records specified between given interval">>$path/E_O_script.log
else
  echo "$run_date:failed to assign zero to the record which not listed by the query between the specified interval">>$path/E_O_script.log
fi
#removing the rr_invtrend table today record if runs before 3pm
while read -r line
do
if [ $line == rr_invtrend ];then

        if [ $current_time -gt 000000 -a $current_time -le 150000 ];then
         grep -v `date +%Y-%m-%d` $path/$line'1'.csv>$path/$line.csv
        else
         cat $path/$line'1'.csv>$path/$line.csv
        fi
else
 cat $path/$line'1'.csv>$path/$line.csv
fi
done<$path/delta_fr_tables.txt
#creating the HTML file to display in the mail

echo "<html>" >$path/email_content.html
echo "<Body>" >>$path/email_content.html
echo "<style type="text/css">
table, th, td {
      border: 1px solid black;
     border-collapse: collapse;
}
table {
            font-size:11px;
            color:#333333;
    }
    table th {
            background-color:#d4e3e5;
            padding: 5px;
    }
    table td {
            padding: 2px;
    }
        tr:nth-child(even) {
    background-color: #dddddd;
}
</style>" >>$path/email_content.html
check="<td style=\"font-size:150%;font-weight:bold;color:green;\">&#10004;</td>"
cross="<td style=\"font-size:150%;font-weight:bold;color:red;\">&#9747;</td>"

while read -r name1
do
echo "<p><b>$name1</b></p>">>$path/email_content.html
awk -v x="$check" -v y="$cross" -v z="$name1" 'BEGIN{FS="|";{print "<table><tr><th>RUN DATE</th><th>COUNT</th><th>STATUS</th></tr>"}}
{print "<tr>";for(i=1;i<=NF;i++){if($i=="GOOD"){print x}else if($i=="BAD"){print y}else {print "<td>"$i"</td>";}}print"</tr>"} END{print "</table>"}' $path/$name1.csv>>$path/email_content.html
done<$path/tbl_name.txt
if [ $? -eq 0 ];then
 echo "$run_date:The files with the HTML tags are generated">>$path/E_O_script.log
else
 echo "$run_date:Failed to generate the html tags">>$path/E_O_script.log
fi
echo "</Body>" >> $path/email_content.html
echo "</html>" >> $path/email_content.html

echo "Hi Team,<br><br>
The table count doesnt meet the constraint.Please check,<br><br>">$path/email_content1.html
echo "Hi Team,<br><br>
The Domain table count has been validated and the data count are good.<br><br>" >$path/email_content3.html

#na=$(grep "BAD" `find $path -type f \( -iname "*.csv" ! -iname "*1.csv" \)` | wc -l)
na=$(grep $run_date `find $path -type f \( -iname "*.csv" ! -iname "*1.csv" \)` | grep "BAD" | wc -l)
#Populating the mail content
if [ $na -ne 0 ];then
   status="FAILED"
   cat $path/email_content1.html>$path/final_email_content.html
   cat $path/email_content.html>>$path/final_email_content.html
   echo "$run_date:The records does not meet the constraint">>$path/E_O_script.log
else
   status="SUCCESS"
   cat $path/email_content3.html>$path/final_email_content.html
   cat $path/email_content.html>>$path/final_email_content.html
   echo "$run_date:The record counts are good validated successfully">>$path/E_O_script.log
fi

#sending email notification
  (
 echo "From: $Fromlist"
 echo "To:$Tolist"
 echo "MIME-Version: 1.0"
 echo "Content-Type: text/html"
 echo "Subject:$status:E&O Mitigation DB Load Status $run_date"
  cat $path/final_email_content.html
 echo "<br>Thank you,<br>EIP-Hadoop Support Team."
  ) | /usr/sbin/sendmail -t
  if [ $? == 0 ];then
   echo "$run_date:Email has been sent">>$path/E_O_script.log
  else
   echo "$run_date:Issue in sending email">>$path/E_O_script.log
  fi

#Code changes for createing Touch files and Send mail notification incontrol team.

touch_path="/eip_interfaces/code/inControl/touchfile"
eip_log_path="/eip_interfaces/logs/sap/${run_date}"
if [ -f $touch_path/eiploads_complete ]; then
  echo "Deleteing yesterday complete file">>$path/E_O_script.log
  rm $touch_path/eiploads_complete
elif [ -f $touch_path/eiploads_fail ]; then
    echo "Deleteing yesterday fail file">>$path/E_O_script.log
    rm $touch_path/eiploads_fail
else
  echo "File not exist">>$path/E_O_script.log
fi

cat ${path}/tbl_name.txt | grep 'bw*\|hcc*' >> ${path}/incontroldependent_tables.txt
file=${path}/incontroldependent_tables.txt
count=0;
cat $file | while IFS= read table
do
  echo "$table">>$path/E_O_script.log
status=`cat ${path}/$table.csv | grep ${run_date} | awk -F '|' '{print $3}'`
 if [ $status == "GOOD" ]
 then
     count=`expr $count + 1`
     if [ $count = 4 ]
     then
	   touch ${touch_path}/eiploads_complete
	   echo "Cretaed New Filee">>$path/E_O_script.log
           rm -r ${path}/incontroldependent_tables.txt
     fi
 fi

done

#sending email notification in control team
if [[ -n $(find ${eip_log_path}/ -name "sal_complete") ]] && [[ -n $(find ${touch_path}/ -name "eiploads_complete") ]];then
    stas="SUCCESS"
    status1="SUCCESS:EIP data loads (Persistent, Spend Analytic and Domains snapshots)."
    echo "$run_date:EIP data loads (Persistent, Spend Analytic and Domains snapshots) Success.">>$path/E_O_script.log
    
else
    stas="FAILED"
    status1="FAILED:EIP data loads (Persistent, Spend Analytic and Domains snapshots)."
	  touch ${touch_path}/eiploads_fail
           rm -r ${path}/incontroldependent_tables.txt
    echo "$run_date:EIP data loads (Persistent, Spend Analytic and Domains snapshots) FAIL">>$path/E_O_script.log
fi

  (
 echo "From: $Fromlist"
 echo "To:$Toincontrollist"
 echo "MIME-Version: 1.0"
 echo "Content-Type: text/html"
 echo "Subject:$stas:EIP data loads. $run_date"
 echo "Hi Team,<br><br>"

 echo "$status1<br><br>"

 echo "<br>Thank you,<br>EIP-Hadoop Support Team."
  ) | /usr/sbin/sendmail -t
  if [ $? == 0 ];then
   echo "$run_date:Email has been sent">>$path/E_O_script.log
  else
   echo "$run_date:Issue in sending email">>$path/E_O_script.log
  fi

