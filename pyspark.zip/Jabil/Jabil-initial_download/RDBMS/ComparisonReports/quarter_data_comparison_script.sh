#!/bin/bash
kinit $USER@CORP.JABIL.ORG -k -t /eip_interfaces/${USER}/.misc/${USER}.keytab -V
/opt/cloudera/parcels/SPARK2/bin/spark2-submit --jars /eip_interfaces/code/DIF/RDBMS/ComparisonReports/ngdbc.jar --packages com.databricks:spark-csv_2.10:1.2.0 --conf PYSPARK_PYTHON=/usr/local/bin/python3.6 /eip_interfaces/code/DIF/RDBMS/ComparisonReports/sap_to_hadoop_data_comparison_qly_report.py --deploy-mode cluster --executor-memory 5G

