'''
SAP vs Hadoop Data Comparison report for last 3 months data.
It will show the number of Matched, Hadoop layer missing with data,
existence of hard deletes/Duplicates days based on ZZDATE field.
'''
import subprocess
import smtplib
import datetime
import configparser
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
import getpass
import MySQLdb
from pyspark import SparkContext, SparkConf, HiveContext
from pyspark.sql import SQLContext
#new code
from pyspark.sql.functions import expr
#pylint: disable=E0611
from pyspark.sql.functions import udf, upper, col
#from pyspark.sql.functions import lower, col
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
import dateutil.relativedelta
import pandas as pd

TARGET_PATH_LIST = None
TODAY = None
NOW = None
THEN_MONTH = None
START_DATE = None
END_DATE = None
YEAR = None
CONF = None
SC = None
#SQLCONTEXT = None
#HSQLCONTEXT = None
#from here program will start
os.environ["PYSPARK_PYTHON"] = "/usr/local/bin/python3.6"
#set up the spark configuration and create contexts
SPARKCONF = SparkConf().setAppName("SparkSessionDataComparison").setMaster("yarn")
#reading configuration file
CONFIG = configparser.ConfigParser()
CONFIG.read('/eip_interfaces/code/DIF/RDBMS/ComparisonReports/datacomparisonreportconfig.ini')
HOSTNAME = CONFIG['DEFAULT']['host']
USER_ID = CONFIG['DEFAULT']['user']
PASSWORD = CONFIG['DEFAULT']['passwd']
DBNAME = CONFIG['DEFAULT']['db']
HA_DB = CONFIG['DEFAULT']['HA_DB']
BW_DB = CONFIG['DEFAULT']['BW_DB']
HA_JDBC_CONN = CONFIG['DEFAULT']['HA_JDBC_CONN']
HA_PWD = CONFIG['DEFAULT']['HA_PWD']
BW_JDBC_CONN = CONFIG['DEFAULT']['BW_JDBC_CONN']
BW_PWD = CONFIG['DEFAULT']['BW_PWD']
TO_ADDR = CONFIG['DEFAULT']['TO_ADDR']
FRM_ADDR = CONFIG['DEFAULT']['FRM_ADDR']
LOGPATH = CONFIG['DEFAULT']['LOGS']
SPARK_JARFILE = CONFIG['DEFAULT']['SPARK_JARFILE']
NUM_MONTH = CONFIG['DEFAULT']['NUM_MONTH']
THRESHOLD_FR = CONFIG['DEFAULT']['THRESHOLD_FR']
THRESHOLD_DELTA = CONFIG['DEFAULT']['THRESHOLD_DELTA']
DIFF_DAYS_INCREMENTAL = CONFIG['DEFAULT']['DIFF_DAYS_INCREMENTAL']
# your handle to SparkContext to access other context like SQLContext
#Setting date fomrat and conditions
TODAY = datetime.datetime.now()
NOW = TODAY+dateutil.relativedelta.relativedelta(days=-1)
THEN_MONTH = NOW + dateutil.relativedelta.relativedelta(months=-int(NUM_MONTH))
START_DATE = THEN_MONTH.strftime('%Y%m%d')
END_DATE = NOW.strftime('%Y%m%d')
YEAR = NOW.strftime('%Y')
print("start_date is :", START_DATE)
print("end_date is :", END_DATE)
USER_NAME = getpass.getuser()
SAP_INCREMENTAL_PATH = "/user/" + USER_NAME + "/sap_incremental_dataframe"
HADOOP_INCREMENTAL_PATH = "/user/" + USER_NAME + "/hadoop_incremental_dataframe"
SAP_FULLREFRESH_PATH = "/user/" + USER_NAME + "/sap_fullrefresh_dataframe"
HADOOP_FULLREFRESH_PATH = "/user/" + USER_NAME + "/hadoop_fullrefresh_dataframe"

def return_threshold_delta():
    '''return threshold of Delta load'''
    return THRESHOLD_DELTA

def return_threshold_fr():
    '''return threshold of FR load'''
    return THRESHOLD_FR

def check_error(error_message):
    '''check errors in case of send mail'''
    print(error_message)
    smtp_session = smtplib.SMTP('localhost', 25) # creates SMTP session
    smtp_session.sendmail(FRM_ADDR, TO_ADDR.split(','), error_message) # sending the mail
    smtp_session.quit()
    exit()

def get_list_from_skip_file():
    '''Finding harddeletes skiplist'''
    skip_hard_deletes = "/eip_interfaces/code/DIF/RDBMS/HiveQL_Generator_RDBMS/skip_harddeletes.sh"
    splited_skipped_table = None
    with open(skip_hard_deletes, 'r') as skip_hard_deletes_file:
        for line in skip_hard_deletes_file:
            if line.find('export') != -1:
                skipped_tables = line[line.find("(")+1:line.find(")")]
                formatted_tables1 = skipped_tables.replace('" "', '|')
                formatted_tables2 = formatted_tables1.replace('\"', '')
                splited_skipped_table = formatted_tables2.split('|')
            else:
                splited_skipped_table = None
    return splited_skipped_table

def find_primary_key(tbl, src):
    ''' Finding Primary Key for all Tables '''
    print("find_primary_key", tbl, src)
    #return
    data_base = MySQLdb.connect(host=HOSTNAME, user=USER_ID, passwd=PASSWORD, db=DBNAME)
    cursor1 = data_base.cursor()
    list_primary_key = []
    select_stmt = ""
    if src == 'HA':
        select_stmt = '''select * from source_column_details
where constraint_type ='PRIMARY KEY' and database_name='''\
+"'"+HA_DB+"' and table_name='"+tbl+"';"
    elif src == 'BW':
        select_stmt = '''select * from source_column_details
where constraint_type ='PRIMARY KEY' and database_name='''\
+"'"+BW_DB+"' and table_name='"+tbl+"';"
    else:
        print("Unknown error", " find_primary_key ", tbl)
        exit()
    cursor1.execute(select_stmt)
    for rows in cursor1.fetchall():
        list_primary_key.append(rows[8])
    return list_primary_key

def check_duplicate(table_name, zz_date, database):
    ''' Finding Duplicate data in Table '''
    print("check_duplicate", table_name, zz_date, database)
    #return
    if (table_name is None) or (zz_date is None) or (database is None):
        return None
    my_list = find_primary_key(table_name, database)
    #return
    if not my_list:
        check_error("the primary key for table " + table_name +\
        " source " + database + " is not available, existing the program")
    q_1 = "select count(*) from (select 'tbl' as HADOOP_TABLE_NAME,"
    count = 0
    primary_keys_string = ""
    for element in my_list:
        if count == 0:
            primary_keys_string = element
        elif count < len(element)-1:
            primary_keys_string = primary_keys_string+","+element
        elif count == len(element)-1:
            primary_keys_string = primary_keys_string+","+element
        else:
            print("Unknown error ", "check_duplicate ", table_name, zz_date)
        count = count+1
    q_2 = "count(*) from persistent.sap_hana_ecc_"+ database.lower()+ "_tbl "
    q_3 = "group by "
    q_4 = primary_keys_string
    q_5 = " having count(*)>1 ) as subquery"
    duplicate_query = q_1+q_2+q_3+q_4+q_5
    duplicate_query = duplicate_query.replace('tbl', table_name.lower())
    print("duplicate_query", duplicate_query)
    result1 = HSQLCONTEXT.sql(duplicate_query)
    for rows in result1.rdd.collect():
        if rows[0] == 0:
            return 0
        return rows[0]
    return result1

def duplicate_zzdate(table_name, database):
    '''Fing Duplicate Records'''
    my_list = find_primary_key(table_name, database)
    print("duplicate_zzdate", table_name, database)
    #return
    if (table_name is None) or (database is None):
        return None
    q_1 = "select zzdate"
    count = 0
    primary_keys_string = ""
    for element in my_list:
        if count == 0:
            primary_keys_string = element
        elif count < len(element)-1:
            primary_keys_string = primary_keys_string+","+element
        elif count == len(element)-1:
            primary_keys_string = primary_keys_string+","+element
        else:
            print("Unknown error ", " duplicate_zzdate ", table_name)
        count = count+1
    q_3 = " from persistent.sap_hana_ecc_"+ database.lower()+ "_tbl "+"group by "
    q_4 = primary_keys_string
    q_5 = ",zzdate having count(*)>1 order by zzdate"
    duplicate_query = q_1+q_3+q_4+q_5
    duplicate_query = duplicate_query.replace('tbl', table_name.lower())
    print("duplicate_zzdate", duplicate_query)
    result2 = HSQLCONTEXT.sql(duplicate_query)
    list_of_zzdates = []
    for row1 in result2.rdd.collect():
        list_of_zzdates.append(row1)
    return list_of_zzdates

def diff_count(hadoop_count, sap_count):
    '''Finding the difference of SAP count and Hadoop count'''
    if sap_count is None:
        sap_count = 0
    if hadoop_count is None:
        hadoop_count = 0
    return hadoop_count-sap_count

def find_threshold(hadoop_count, sap_count, threshold_value):
    '''Finding Threshold value for table'''
    final_value = 0
    if sap_count is None and hadoop_count is None:
        final_value = 0
    elif sap_count is None:
        final_value = hadoop_count
    elif hadoop_count is None:
        final_value = sap_count
    else:
        final_value = sap_count
    return float(final_value)*float(threshold_value)/100

def process_incremental_data():
    """
    (process_incremental_data) SAP vs Hadoop Data Comparison report for last 3 months data.
     It will show the number of Matched, Hadoop layer missing with data,
     existence of hard deletes/Duplicates days based on ZZDATE field.
    """
    # pylint: disable=R0914,R1702,R0912,R0915
    SQLCONTEXT.clearCache()
    incremental_db = MySQLdb.connect(host=HOSTNAME, user=USER_ID, passwd=PASSWORD, db=DBNAME)
    cursor = incremental_db.cursor()
    selet_stmt1 = """select table_name,view_name from source_table_details
    where database_name=%(bw_db)s and load_type='D'"""
    cursor.execute(selet_stmt1, {'bw_db':BW_DB})
    mylist = []
    for row in cursor.fetchall():
        mylist.append((row[0], row[1], "BW"))
    select_stmt2 = """select table_name,view_name from source_table_details
    where database_name=%(ha_db)s and load_type='D'"""
    cursor.execute(select_stmt2, {'ha_db':HA_DB})
    for row in cursor.fetchall():
        mylist.append((row[0], row[1], "HA"))
    print("mylist from source_table_details")
    print(mylist)
    for index, (table, view, source) in enumerate(mylist):
    #    if table not in {'BKPF'}:
    #        continue
        print (table, view, source)
        calcview_select_stmt = """
    Select ifnull(param_name1  ,'NA')as param_name1,ifnull(param_value1 ,'NA')as param_value1 ,
    ifnull(param_name2  ,'NA')as param_name2  ,ifnull(param_value2 ,'NA')as param_value2 ,
    ifnull(param_name3  ,'NA')as param_name3  ,ifnull(param_value3 ,'NA')as param_value3 ,
    ifnull(param_name4  ,'NA')as param_name4  ,ifnull(param_value4 ,'NA')as param_value4 ,
    ifnull(param_name5  ,'NA')as param_name5  ,ifnull(param_value5 ,'NA')as param_value5 ,
    ifnull(param_name6  ,'NA')as param_name6  ,ifnull(param_value6 ,'NA')as param_value6 ,
    ifnull(param_name7  ,'NA')as param_name7  ,ifnull(param_value7 ,'NA')as param_value7 ,
    ifnull(param_name8  ,'NA')as param_name8  ,ifnull(param_value8 ,'NA')as param_value8 ,
    ifnull(param_name9  ,'NA')as param_name9  ,ifnull(param_value9 ,'NA')as param_value9 ,
    ifnull(param_name10 ,'NA')as param_name10 ,ifnull(param_value10,'NA')as param_value10
     from calculative_view_details where view_name=%(calc_view_name)s"""
        cursor.execute(calcview_select_stmt, {'calc_view_name':view})
        calc_view_list = []
        for row in cursor.fetchall():
            calc_view_list = row
            query = """
    (SELECT 'table_name' AS SAP_TABLE_NAME,'database_name' AS SAP_DATABASE_NAME,zzdate as SAP_ZZDATE,Count(*) as SAP_COUNT
    FROM "_SYS_BIC"."view_name"(param_view) GROUP BY zzdate ORDER BY  zzdate ASC )"""
            param_view_str = ''
            zz_flag = 0
            for j in range(0, len(calc_view_list), 2):
                if calc_view_list[j] == 'IP_ZZDATE_START' and calc_view_list[j+1] != 'NA':
                    zz_flag = 1
                if not calc_view_list:
                    print("No parameter view details found")
                else:
                    param_view_str = ''
                    for k in range(0, len(calc_view_list), 2):
                        if calc_view_list[k] != "NA":
                            if calc_view_list[k+1] == "NA":
                                param_view_str += "'PLACEHOLDER' = ('$${}$$', ' '),"\
    .format(calc_view_list[k])
                            else:
                                if zz_flag == 1 and (calc_view_list[k] == "IP_BUDAT_START"
                                                     or calc_view_list[k] == "IP_BUDAT_END"):
                                    param_view_str += "'PLACEHOLDER' = ('$${}$$', ' '),"\
                                    .format(calc_view_list[k])
                                elif calc_view_list[k] == "IP_ZZDATE_START":
                                    param_view_str += "'PLACEHOLDER' = ('$${}$$', 'START_DATE'),"\
                                    .format(calc_view_list[k])
                                elif calc_view_list[k] == "IP_ZZDATE_END":
                                    param_view_str += "'PLACEHOLDER' = ('$${}$$', 'END_DATE'),"\
                                    .format(calc_view_list[k])
                                else:
                                    param_view_str += "'PLACEHOLDER' = ('$${}$$', '{}'),"\
                                    .format(calc_view_list[k], calc_view_list[k+1])
            param_result = param_view_str.rstrip(',')
            query = query.replace('table_name', table.lower())
            query = query.replace('database_name', source)
            query = query.replace('param_view', param_result)
            query = query.replace('view_name', view)
            query = query.replace('START_DATE', START_DATE)
            query = query.replace('END_DATE', END_DATE)
            print(query, index)
            if source == "HA":
                data_frame = SQLCONTEXT.read.format("jdbc")\
                .option("driver", "com.sap.db.jdbc.Driver")\
                     .option("url", HA_JDBC_CONN).option("dbtable", query)\
                     .option("user", "HADOOP_SYSTEM").option("PASSWORD", HA_PWD)\
                     .option("useSSL", "false").option("useUnicode", "true")\
                     .option("continueBatchOnError", "true").load()
            elif source == "BW":
                data_frame = SQLCONTEXT.read.format("jdbc")\
                .option("driver", "com.sap.db.jdbc.Driver")\
                     .option("url", BW_JDBC_CONN).option("dbtable", query)\
                     .option("user", "HADOOP_SYSTEM").option("PASSWORD", BW_PWD)\
                     .option("useSSL", "false").option("useUnicode", "true")\
                     .option("continueBatchOnError", "true").load()
            else:
                print("\n This view is not exists in both HA & BW.\n")
            data_frame.write.mode('append').save(path=SAP_INCREMENTAL_PATH,\
            source="com.databricks.spark.csv")
    for i, (table, view, source) in enumerate(mylist):
        #if table not in {'BKPF'}:
        #    continue
        if source == "HA":
            incremental_hadoop_query = ("""SELECT 'tbl' as HADOOP_TABLE_NAME,
                            'HA' as HADOOP_DATABASE_NAME,
                            zzdate as HADOOP_ZZDATE,
                            count(*) as HADOOP_COUNT FROM persistent.sap_hana_ecc_ha_tbl
                            where zzdate between 'startdate' and 'enddate'
                            GROUP BY zzdate ORDER BY zzdate asc""")
        elif source == "BW":
            incremental_hadoop_query = ("""SELECT 'tbl' as HADOOP_TABLE_NAME,
                            'BW' as HADOOP_DATABASE_NAME,
                            zzdate as HADOOP_ZZDATE,
                            count(*) as HADOOP_COUNT FROM persistent.sap_hana_ecc_bw_tbl
                            where zzdate between 'startdate' and 'enddate'
                            GROUP BY zzdate ORDER BY zzdate asc""")
        else:
            print("\n This table is not available in both Ha & BW..\n")
        incremental_hadoop_query = incremental_hadoop_query.replace('tbl', table.lower())
        incremental_hadoop_query = incremental_hadoop_query.replace('startdate', START_DATE)
        incremental_hadoop_query = incremental_hadoop_query.replace('enddate', END_DATE)
        print(incremental_hadoop_query)
        hadoop_df = HSQLCONTEXT.sql(incremental_hadoop_query)
        hadoop_df.write.mode('append').save(path=HADOOP_INCREMENTAL_PATH,\
        source="com.databricks.spark.csv")
        print(i)
    incremental_sap_data = SQLCONTEXT.read.parquet(SAP_INCREMENTAL_PATH)
    incremental_hadoop_data = SQLCONTEXT.read.parquet(HADOOP_INCREMENTAL_PATH)
    list_skip_tables = get_list_from_skip_file()
    for flag in list_skip_tables:
        print(flag)
    SQLCONTEXT.registerDataFrameAsTable(incremental_sap_data, "sap_table")
    SQLCONTEXT.registerDataFrameAsTable(incremental_hadoop_data, "hadoop_table")

    df_0 = SQLCONTEXT.sql("""select a.SAP_TABLE_NAME,a.SAP_DATABASE_NAME,a.SAP_ZZDATE,a.SAP_COUNT,
    b.HADOOP_TABLE_NAME,b.HADOOP_DATABASE_NAME,b.HADOOP_ZZDATE,b.HADOOP_COUNT,
    diff_count(b.HADOOP_COUNT,a.SAP_COUNT) as Difference,
    find_threshold(b.HADOOP_COUNT,a.SAP_COUNT,-return_threshold_delta()),
    find_threshold(b.HADOOP_COUNT,a.SAP_COUNT,return_threshold_delta()),
    CASE
    WHEN b.HADOOP_DATABASE_NAME IS NULL THEN 'Missing_Days'
    WHEN (diff_count(b.HADOOP_COUNT,a.SAP_COUNT)==0) THEN 'Matched'
    WHEN((diff_count(b.HADOOP_COUNT,a.SAP_COUNT)>-(find_threshold(b.HADOOP_COUNT,a.SAP_COUNT,return_threshold_delta())))
    and (diff_count(b.HADOOP_COUNT,a.SAP_COUNT)<find_threshold(b.HADOOP_COUNT,a.SAP_COUNT,return_threshold_delta())))
    THEN 'Matched'
    WHEN (diff_count(b.HADOOP_COUNT,a.SAP_COUNT)<-(find_threshold(b.HADOOP_COUNT,a.SAP_COUNT,return_threshold_delta()))) THEN 'Not_Matched'
    WHEN (diff_count(b.HADOOP_COUNT,a.SAP_COUNT)>find_threshold(b.HADOOP_COUNT,a.SAP_COUNT,return_threshold_delta()))
    THEN 'Hard_Deletes' ELSE 'Missing_Days' END as QUERY_STATUS
    from sap_table a full join hadoop_table b
    on a.SAP_TABLE_NAME=b.HADOOP_TABLE_NAME and a.SAP_ZZDATE=b.HADOOP_ZZDATE
     and a.SAP_DATABASE_NAME=b.HADOOP_DATABASE_NAME""")

    #df_0.toPandas().to_csv('/tmp/sap_hadoop/df_0.csv')
    df_1 = df_0.filter((df_0["HADOOP_ZZDATE"] >= START_DATE) | (df_0["SAP_ZZDATE"] >= START_DATE))
    #df_1.toPandas().to_csv('/tmp/sap_hadoop/df_1.csv')
    #exit()
    df_dup_suspects = df_1.filter(df_1["QUERY_STATUS"] == 'Hard_Deletes')
#   df_dup_suspects.show()
    list_result_duplicates = []
    set_tables_with_duplicates = set()
    #to know only impacted tables and partition
    for row in df_dup_suspects.rdd.collect():
        table = row[0]
        zzdate = row[2]
        source = row[1]
        if row[0] in set_tables_with_duplicates:
            continue
        set_tables_with_duplicates.add(row[0])
        print(set_tables_with_duplicates)
        ret = check_duplicate(table, zzdate, source)
        if ret is None:
            continue
        if ret == 0:
            list_result_duplicates\
            .append((table, zzdate, source, "Hard_Deletes"))
        else:
            ret = duplicate_zzdate(table, source)
            for result in ret:
                list_result_duplicates\
                .append((table, result[0], source, "Duplicates"))
           # new_set_tables_with_duplicates.add(row)
    print("""----------------------------------DF_list_duplicates_or_hd-
    --------------------------------""")
    schema_list_duplicates_or_hd = StructType([StructField("TABLE_NAME", StringType(), True),\
                                   StructField("ZZDATE", StringType(), True),\
                                   StructField("DATABASE_NAME", StringType(), True),\
                                   StructField("IS_DUPLICATE", StringType(), True)])
    rdd_list_duplicates_or_hd = SC.parallelize(list_result_duplicates)
    df_list_duplicates_or_hd = SQLCONTEXT.createDataFrame(rdd_list_duplicates_or_hd,\
                                                          schema_list_duplicates_or_hd)
    condition_duplicates = [df_1.HADOOP_TABLE_NAME == df_list_duplicates_or_hd.TABLE_NAME,\
                            df_1.HADOOP_DATABASE_NAME == df_list_duplicates_or_hd.DATABASE_NAME,\
                            df_1.HADOOP_ZZDATE == df_list_duplicates_or_hd.ZZDATE]
#   print("DF_LIST_DUPLICATES_OR_HD.show")
#   df_list_duplicates_or_hd.show()
    df_5 = df_1.join(df_list_duplicates_or_hd, condition_duplicates, how="outer")\
             .select(df_1['SAP_TABLE_NAME'], df_1['SAP_DATABASE_NAME'], df_1['SAP_ZZDATE'],\
                     df_1['SAP_COUNT'], df_1['HADOOP_TABLE_NAME'], df_1['HADOOP_DATABASE_NAME'],\
                     df_1['HADOOP_ZZDATE'], df_1['HADOOP_COUNT'], df_1['QUERY_STATUS'],\
                     df_1['Difference'],\
                     df_list_duplicates_or_hd["IS_DUPLICATE"])
#   print("DF5")
#   df_5.show()
    status = expr(
        """IF(IS_DUPLICATE is NULL,QUERY_STATUS,IS_DUPLICATE)"""
    )
    df_11 = df_5.withColumn("STATUS", status)
#   print("DF11")
#   df_11.show()
    all_tables = expr(
        """IF(SAP_TABLE_NAME is NULL, HADOOP_TABLE_NAME, SAP_TABLE_NAME)"""
    )
    df_11_with_all_tables = df_11.withColumn("all_tables", all_tables)
    df_11_only_tables = df_11_with_all_tables.select(df_11_with_all_tables['all_tables'])
    SQLCONTEXT.registerDataFrameAsTable(df_11_only_tables, "only_tables")
    df_distinct_tables = SQLCONTEXT.sql("select DISTINCT all_tables from only_tables")

    new_list_skip_tables = []
    for element in df_distinct_tables.rdd.collect():
    # if TABLE_NAME is already in set
        table_name = element[0]
        if table_name in list_skip_tables:
            new_list_skip_tables.append((table_name, "Y"))
        else:
            new_list_skip_tables.append((table_name, "N"))
    print(new_list_skip_tables)
    print("----------------------------------DF_SKIP_FLAG---------------------------------")
    schema_skip_flag = StructType([StructField("TABLE_NAME", StringType(), True),\
                       StructField("HD_SKIP_FLAG", StringType(), True)])
    rdd_skip_flag = SC.parallelize(new_list_skip_tables)
    df_skip_flag = SQLCONTEXT.createDataFrame(rdd_skip_flag, schema_skip_flag)
#   print("DF_SKIP_FLAG.show")
#   df_skip_flag.show()
    join_condition1 = [df_skip_flag.TABLE_NAME == df_11.SAP_TABLE_NAME]
    df_12 = df_11.join(df_skip_flag, join_condition1)\
               .select(df_11['SAP_TABLE_NAME'], df_11['SAP_DATABASE_NAME'],\
               df_11['SAP_ZZDATE'], df_11["SAP_COUNT"], df_11['HADOOP_TABLE_NAME'],\
               df_11['HADOOP_DATABASE_NAME'], df_11['HADOOP_ZZDATE'], df_11["HADOOP_COUNT"],\
               df_11["Difference"], df_11['STATUS'], df_skip_flag['HD_SKIP_FLAG'])
    join_condition_missing_days = [df_skip_flag.TABLE_NAME == df_11.HADOOP_TABLE_NAME]
    df_13 = df_11.join(df_skip_flag, join_condition_missing_days)\
               .select(df_11['SAP_TABLE_NAME'], df_11['SAP_DATABASE_NAME'], df_11['SAP_ZZDATE'],\
                       df_11["SAP_COUNT"], df_11['HADOOP_TABLE_NAME'],\
                       df_11['HADOOP_DATABASE_NAME'],\
                       df_11['HADOOP_ZZDATE'], df_11["HADOOP_COUNT"], df_11["Difference"],\
                       df_11['STATUS'], df_skip_flag['HD_SKIP_FLAG'])
    df_14 = df_12.union(df_13)
    df_15 = df_14.dropDuplicates()
    df_11.unpersist(blocking=True)
    df_12.unpersist(blocking=True)
    df_13.unpersist(blocking=True)
    df_1.unpersist(blocking=True)
    df_5.unpersist(blocking=True)
    df_list_duplicates_or_hd.unpersist(blocking=True)
    df_14.unpersist(blocking=True)
#   print("DF15")
#   df_15.show()
    source = expr(
        """IF(SAP_DATABASE_NAME is NULL, HADOOP_DATABASE_NAME, SAP_DATABASE_NAME)"""
    )
    df_16 = df_15.withColumn("SOURCE", source)
    table = expr(
        """IF(SAP_TABLE_NAME is NULL, HADOOP_TABLE_NAME, SAP_TABLE_NAME)"""
    )
    df_17 = df_16.withColumn("TABLE_LOWER_CASE", table)
#   print("DF17")
#   df_17.show()
    df_15.unpersist(blocking=True)
    df_16.unpersist(blocking=True)
    #pylint: enable=R0914,R1702,R0912,R0915
    #pylint: disable=E0602,E0603
    df_17_1 = df_17.withColumn('TABLE', upper(col('TABLE_LOWER_CASE')))
    return df_17_1

def process_fullrefresh_data():
    """
    (process_fullrefresh_data) SAP vs Hadoop Data Comparison report for last 3 months data.
    It will show the number of Matched, Hadoop layer missing with data,
    existence of hard deletes/Duplicates days based on ZZDATE field.
    """
    # pylint: disable=R0914
    SQLCONTEXT.clearCache()
    fr_db = MySQLdb.connect(host=HOSTNAME, user=USER_ID, passwd=PASSWORD, db=DBNAME)
    fr_cursor = fr_db.cursor()
    selet_stmt1 = """select table_name,view_name from source_table_details
    where database_name=%(bw_db)s and load_type='FR'"""
    fr_cursor.execute(selet_stmt1, {'bw_db':BW_DB})
    mylist = []
    for row in fr_cursor.fetchall():
        mylist.append((row[0], row[1], "BW"))
    select_stmt2 = """select table_name,view_name from source_table_details
    where database_name=%(ha_db)s and load_type='FR'"""
    fr_cursor.execute(select_stmt2, {'ha_db':HA_DB})
    for row in fr_cursor.fetchall():
        mylist.append((row[0], row[1], "HA"))
    for index, (table, view, source) in enumerate(mylist):
        print(table)
        query = """(SELECT 'table_name' AS SAP_TABLE_NAME,'database_name' AS SAP_DATABASE_NAME,
        Count(*) as SAP_COUNT FROM "_SYS_BIC"."view_name")"""
        query = query.replace('table_name', table)
        query = query.replace('view_name', view)
        query = query.replace('database_name', source)
        print(query)
        if source == "HA":
            data_frame = SQLCONTEXT.read.format("jdbc")\
            .option("driver", "com.sap.db.jdbc.Driver")\
            .option("url", HA_JDBC_CONN).option("dbtable", query)\
            .option("user", "HADOOP_SYSTEM").option("PASSWORD", HA_PWD)\
            .option("useSSL", "false").option("useUnicode", "true")\
            .option("continueBatchOnError", "true").load()
        elif source == "BW":
            data_frame = SQLCONTEXT.read.format("jdbc")\
            .option("driver", "com.sap.db.jdbc.Driver")\
            .option("url", BW_JDBC_CONN).option("dbtable", query)\
            .option("user", "HADOOP_SYSTEM").option("PASSWORD", BW_PWD)\
            .option("useSSL", "false").option("useUnicode", "true")\
            .option("continueBatchOnError", "true").load()
        else:
            print("\n This view is not exists in both HA & BW.\n", index)
        data_frame.show()
        data_frame.write.mode('append').save(path=SAP_FULLREFRESH_PATH,\
        source="com.databricks.spark.csv")
    for index, (table, view, source) in enumerate(mylist):
        if source == "HA":
            fullrefresh_hadoop_query = ("""SELECT 'tbl' as HADOOP_TABLE_NAME,
                                        count(*) as HADOOP_COUNT
                                        FROM persistent.sap_hana_ecc_ha_tbl""")
        elif source == "BW":
            print("\n SAP BW table \n")
            fullrefresh_hadoop_query = ("""SELECT 'tbl' as HADOOP_TABLE_NAME,
                                        count(*) as HADOOP_COUNT
                                        FROM persistent.sap_hana_ecc_bw_tbl""")
        else:
            print("\n This table is not available in both Ha & BW..\n", index)
        fullrefresh_hadoop_query = fullrefresh_hadoop_query.replace('tbl', table)
        print(fullrefresh_hadoop_query)
        hadoop_df = HSQLCONTEXT.sql(fullrefresh_hadoop_query)
        hadoop_df.write.mode('append').save(path=HADOOP_FULLREFRESH_PATH,\
        source="com.databricks.spark.csv")
    fullrefresh_sap_data = SQLCONTEXT.read.parquet(SAP_FULLREFRESH_PATH)
    fullrefresh_hadoop_data = SQLCONTEXT.read.parquet(HADOOP_FULLREFRESH_PATH)
    SQLCONTEXT.registerDataFrameAsTable(fullrefresh_sap_data, "sap_table")
    SQLCONTEXT.registerDataFrameAsTable(fullrefresh_hadoop_data, "hadoop_table")

    df_full_refresh = SQLCONTEXT.sql("""select a.SAP_DATABASE_NAME AS SOURCE,
    a.SAP_TABLE_NAME AS TABLE, b.HADOOP_COUNT AS TODAY_COUNT,
    CASE WHEN(diff_count(b.HADOOP_COUNT,a.SAP_COUNT)> find_threshold(b.HADOOP_COUNT,
    a.SAP_COUNT,-return_threshold_fr())) and (diff_count(b.HADOOP_COUNT,a.SAP_COUNT)
     <=find_threshold(b.HADOOP_COUNT,a.SAP_COUNT,return_threshold_fr()))
    THEN '\u2714' ELSE '\u2718' END as RESULT from sap_table a full join hadoop_table b
    on a.SAP_TABLE_NAME=b.HADOOP_TABLE_NAME ORDER BY a.SAP_DATABASE_NAME""")

    # pylint: enable=R0914
    return df_full_refresh


CONF = (SparkConf()\
.set("spark.driver.extraClassPath", SPARK_JARFILE)\
.set("spark.driver.extraLibraryPath", SPARK_JARFILE)\
.set("spark.executor.extraLibraryPath", SPARK_JARFILE)\
.set("spark.executor.extraClassPath", SPARK_JARFILE))
SC = SparkContext(conf=CONF)
SC.setLogLevel("OFF")
SQLCONTEXT = SQLContext(SC)
SQLCONTEXT.clearCache()
HSQLCONTEXT = HiveContext(SC)

#Removing existing hdfs files
TARGET_INCREMENTAL_PATH_LIST = [SAP_INCREMENTAL_PATH, HADOOP_INCREMENTAL_PATH]
for targetpath in TARGET_INCREMENTAL_PATH_LIST:
    print(targetpath)
    returncode = subprocess.call(["hdfs", "dfs", "-rm", "-f", "-r", targetpath])
    if returncode == 0:
        print(targetpath + ": HDFS FILES HAVE BEEN REMOVED -INCREMENTAL")
    else:
        print(targetpath + ": UNABLE TO REMOVE HDFS FILE -INCREMENTAL")
        exit()
TARGET_FULLREFRESH_PATH_LIST = [SAP_FULLREFRESH_PATH, HADOOP_FULLREFRESH_PATH]
for targetpath in TARGET_FULLREFRESH_PATH_LIST:
    print(targetpath)
    returncode = subprocess.call(["hdfs", "dfs", "-rm", "-f", "-r", targetpath])
    if returncode == 0:
        print(targetpath + ": HDFS FILES HAVE BEEN REMOVED -FULLREFRESH")
    else:
        print(targetpath + ": UNABLE TO REMOVE HDFS FILE -FULLREFRESH")
        exit()
# from here blocking for FR testing...
SQLCONTEXT.registerFunction("diff_count", diff_count)
SQLCONTEXT.registerFunction("find_threshold", find_threshold)
SQLCONTEXT.registerFunction("return_threshold_delta", return_threshold_delta)
SQLCONTEXT.registerFunction("return_threshold_fr", return_threshold_fr)

DF17 = process_incremental_data()
print("PDSDF")
PDSDF = DF17.toPandas()
print(PDSDF)
STATUS_BY_DAY = pd.crosstab([PDSDF.SOURCE,\
                             PDSDF.TABLE,\
                             PDSDF.HD_SKIP_FLAG],\
                             PDSDF.STATUS)
STATUS_BY_DAY['RESULT'] = 0
CONDITION_CONCLUSION = False
COUNT_MISSING_DAYS = 0
COUNT_MATCHED_DAYS = 0
COUNT_NOT_MATCHED_DAYS = 0
COUNT_DUPLICATES = 0
COUNT_HARD_DELETES = 0
if 'Missing_Days' in STATUS_BY_DAY.columns:
    COUNT_MISSING_DAYS = STATUS_BY_DAY['Missing_Days']
if 'Matched' in STATUS_BY_DAY.columns:
    COUNT_MATCHED_DAYS = STATUS_BY_DAY['Matched']
if 'Not_Matched' in STATUS_BY_DAY.columns:
    COUNT_NOT_MATCHED_DAYS = STATUS_BY_DAY['Not_Matched']
if 'Duplicates' in STATUS_BY_DAY.columns:
    COUNT_DUPLICATES = STATUS_BY_DAY['Duplicates']
if 'Hard_Deletes' in STATUS_BY_DAY.columns:
    COUNT_HARD_DELETES = STATUS_BY_DAY['Hard_Deletes']
print(COUNT_MISSING_DAYS)
print(COUNT_MATCHED_DAYS)
print(COUNT_NOT_MATCHED_DAYS)
print(COUNT_DUPLICATES)
print(COUNT_HARD_DELETES)

TOTAL_DAYS = 30 * int(NUM_MONTH)
TOTAL_COUNT = COUNT_MISSING_DAYS + COUNT_MATCHED_DAYS + \
              COUNT_NOT_MATCHED_DAYS + COUNT_DUPLICATES + COUNT_HARD_DELETES
CONDITION_CONCLUSION =  TOTAL_DAYS > TOTAL_COUNT
if 'Missing_Days' in STATUS_BY_DAY.columns:
    STATUS_BY_DAY.loc[CONDITION_CONCLUSION, 'Missing_Days'] = \
        STATUS_BY_DAY['Missing_Days'] + (TOTAL_DAYS-TOTAL_COUNT)

CONDITION_MATCHED_DAYS = True

# add last column for conclusion
if 'Matched' in STATUS_BY_DAY.columns:
    CONDITION_MATCHED_DAYS = STATUS_BY_DAY['Matched'] > \
                             (TOTAL_DAYS-int(DIFF_DAYS_INCREMENTAL)-1)
else:
    CONDITION_MATCHED_DAYS = False

STATUS_BY_DAY.loc[CONDITION_MATCHED_DAYS, 'RESULT'] = "\u2714"
STATUS_BY_DAY.loc[~CONDITION_MATCHED_DAYS, 'RESULT'] = "\u2718"
print(STATUS_BY_DAY)
PDSDF.to_csv('{}HAP_BW_Data_Comparsion.csv'.format(LOGPATH), sep=',')
DF17.unpersist(blocking=True)

# blocking till here
# full refresh blocking from here
#'''
SQLCONTEXT.clearCache()
HSQLCONTEXT = HiveContext(SC)
DF18 = process_fullrefresh_data()
PDSDF2 = DF18.toPandas()
FULL_REFRESH_DICT = {}
FILE_FOUND = 0
FILE_POINTER = 0
try:
    FILE_POINTER = open("{}fullrefresh.csv".format(LOGPATH), "r")
    FILE_FOUND = 1
except FileNotFoundError:
    print("{}fullrefresh.csv not found, creating it".format(LOGPATH))
#very first time
if FILE_FOUND == 0:
    PDSDF2.to_csv('{}fullrefresh.csv'.format(LOGPATH))
    for x in FILE_POINTER:
        line_fullrefresh_list = x.split(',')
        FULL_REFRESH_DICT[line_fullrefresh_list[2]] = line_fullrefresh_list[3]
    # if.close()
else:
# from second time onwards
    for x in FILE_POINTER:
        line_fullrefresh_list = x.split(',')
        FULL_REFRESH_DICT[line_fullrefresh_list[2]] = line_fullrefresh_list[3]
print("FULL_REFRESH_DICT:", FULL_REFRESH_DICT)

FULLREFRESH_PREVIOUS_DAYS = pd.DataFrame(list(FULL_REFRESH_DICT.items()),\
                            columns=['TABLE', 'PREVIOUS_DAY_COUNT'])
PDSDF2.to_csv('{}fullrefresh.csv'.format(LOGPATH))
PDSDF3 = pd.merge(PDSDF2,\
           FULLREFRESH_PREVIOUS_DAYS,\
           left_on='TABLE',\
           right_on='TABLE')
FINAL_FR = PDSDF3[['SOURCE', 'TABLE', 'TODAY_COUNT', 'PREVIOUS_DAY_COUNT', 'RESULT']]
print(PDSDF2)
print(PDSDF3)
print(FINAL_FR)
PDSDF2.to_csv('{}HAP_BW_Data_Comparsion_FR.csv'.format(LOGPATH), sep=',')
#print("----------------------------------STATUS BY DAY---------------------------------")
DF18.unpersist(blocking=True)
#'''
#full refresh blocking till here
LIST_STATUS_BY_DAY = []
LIST_COLUMNS = []
TOADDR = TO_ADDR
print(TOADDR.split(','))
# string to store the body of the mail
HEADER = '''
<html>
    <head> <style> div.ex1 { width:50px;} </style>
    <p>
<font size="3" face="Calibri" color="blue">
Hi All,<br>Please find the below summary for the <b>SAP vs Hadoop Data Comparison report.</b>It will show the number of Matched, Hadoop layer missing with data,existence of hard deletes/Duplicates days based on ZZDATE field.<br></br>Please find the <u><b>attached sheet</b></u> for detailed information.</font>
</p>
<font size="2" face="Calibri" color="blue">
<em>
For a given day in xls sheet</br>
HC = Hadoop count, SC = Sap count, difference = HC - SC, threshold is T ( % of SC), and threshold_value = T*SC/100</br>
if difference < -threshold_value =>  Not matched days</br>
if difference = 0 => Matched days</br>
if difference is between ( -threshold_value and threshold_value) =>  Matched days</br>
if difference > threshold_value => Dup or HD days</br>
if Hadoop parameters missing => Missing days</br>
RESULT : </br>
Based on the threshold defined in cofig parameter, it says if the table's status are good or bad, and need to pay attention for them. </br>
 ✘ =>  need to resolve </br>
 ✔ =>  good </br>

</em>
</font>
 </head>
   <body>
   <font size="4" face="Calibri" color="blue"> <b> SAP vs Hadoop Data Comparison Report Summary: </b></font>
</br>
'''
STYLE_OPEN = '''
<div class="ex1">
'''
STYLE_CLOSE = '''
</div>
'''
FR_STYLE_OPEN = '''
<style>
table {text-align: center;}
table thead th {text-align: center;}
'''
FR_STYLE_CLOSE = '''
</style>
'''
HEADER_FULL_REFRESH = '''
</br>
    <p>
<font size="3" face="Calibri" color="blue">
Hi All,<br>Please find the below summary for the <b>SAP vs Hadoop Data Comparison report</b> of FULL REFRESH tables.</font>
</p>
<font size="2" face="Calibri" color="blue">
<em>
HC = Hadoop count, SC = Sap count, difference = HC - SC, threshold is T ( % of SC), and threshold_value = T*SC/100</br>
if difference < -threshold_value =>  ✘</br>
if difference = 0 => ✔</br>
if difference is between ( -threshold_value and threshold_value) =>  ✔</br>
</em>
</font>
</br>
<font size="4" face="Calibri" color="blue"> <b> Full Refresh Tables - SAP vs Hadoop Data Comparison Report Summary: </b></font>
</br>
'''
FOOTER = '''
</br>
Thanks
EIP - Hadoop Support Team
</body>
</br>
</html>
'''
with open('{}test.html'.format(LOGPATH), 'w') as f:
    f.write(HEADER)
    f.write(STYLE_OPEN)
    f.write(STATUS_BY_DAY.to_html(classes='STATUS_BY_DAY'))
    f.write(STYLE_CLOSE)
    f.write(HEADER_FULL_REFRESH)
    f.write(FINAL_FR.to_html(classes="FINAL_FR", index=False))
    f.write(FOOTER)
SC.stop()
# attach the body with the msg instance
MSG = MIMEMultipart('alternative', None, \
                     [MIMEText(open('{}test.html'.format(LOGPATH)).read(), 'html')])
MSG['From'] = FRM_ADDR
MSG['To'] = TOADDR
if int(NUM_MONTH) > 1:
    MSG['Subject'] = "SAP vs HADOOP data comparison report for last "\
                      + NUM_MONTH + " months of data "
else:
    MSG['Subject'] = "SAP vs HADOOP data comparison report for last "\
                      + NUM_MONTH + " month of data "
FILENAME = "SapVsHadoop_Dataload_Comparison_Report.csv"
ATTACHMENT1 = open('{}HAP_BW_Data_Comparsion.csv'.format(LOGPATH), "rb")
P = MIMEBase('application', 'octet-stream') # instance of MIMEBase and named as p
P.set_payload((ATTACHMENT1).read()) # To change the payload into encoded form
encoders.encode_base64(P) # encode into base64
P.add_header('Content-Disposition', "ATTACHMENT; FILENAME= %s" % FILENAME)
MSG.attach(P) # attach the instance 'p' to instance 'msg'
S = smtplib.SMTP('localhost', 25) # creates SMTP session
TEXT = MSG.as_string() # Converts the Multipart msg into a string
S.sendmail(FRM_ADDR, TOADDR.split(','), TEXT) # sending the mail
S.quit()
print('''\n -------------------------
EMAIL HAS BEEN SENT SUCCESSFULLY to msg['To']
----------------------------------- \n''')