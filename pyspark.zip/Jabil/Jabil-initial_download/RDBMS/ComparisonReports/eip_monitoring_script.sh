#!/bin/bash

#==============================================================================================#
#Purpose : This generic script is used to check monthly, weekly & daily files availability     #
#Script  : eip_monitoring_script.sh                                                            #
#Author  : CTS Team                                                                            #
#==============================================================================================#
monitoring_alerts="/eip_interfaces/logs/monitoring_alerts"
final_mail_content="/eip_interfaces/logs/monitoring_alerts/mail_content.txt"
mail_attachment="/eip_interfaces/logs/monitoring_alerts/errors.txt"
eip_log_path="/eip_interfaces/logs"
#mime_mail_content="/eip_interfaces/logs/monitoring_alerts/mime_mail_content.txt"
source ./eip_alerts.conf

rm -rf ${monitoring_alerts}

mkdir -p ${monitoring_alerts}
touch ${mail_attachment}
prepare_mail()
{
  echo "</br>" >> ${mail_attachment}
  echo "<table width="30%" border=2>" >> ${final_mail_content}
  echo "<tr bgcolor="orange">" >> ${final_mail_content}
  echo "<font color="blue">" >> ${final_mail_content}
  echo "<th colspan="2">"$1"</th1>" >> ${final_mail_content}
  echo "</font>" >> ${final_mail_content}
  echo "</tr>" >> ${final_mail_content}
  cd $eip_log_path/$1
  for i in `ls -td -- */ | grep -v '[]a-zA-Z[]' | head -n ${record_count} | cut -d'/' -f1`
  do
    echo "<tr>" >> ${final_mail_content}
    echo "<td width="50%">" >> ${final_mail_content}
    echo "$i" >> ${final_mail_content}
    echo "</td>" >> ${final_mail_content}
    echo "<td width="50%" >" >> ${final_mail_content}
    OUTPUT=$(find ${eip_log_path}/$1/${i}/* -name \*FAIL\*)
    if [ -z $OUTPUT ];
    then
  #     echo "OK" >> ${final_mail_content}
        echo "✔" >> ${final_mail_content}

    else
  #     echo "$OUTPUT" >> ${final_mail_content}
        echo "X" >> ${final_mail_content}
        echo "$OUTPUT" >> ${mail_attachment}
        echo "</br>" >> ${mail_attachment}
    fi
    echo "</td>" >> ${final_mail_content}
    echo "</tr>" >> ${final_mail_content}
  done
  echo "</table>" >> ${final_mail_content}
echo "</html>" >> ${final_mail_content}
}


#creating the HTML file to display in the mail
echo "Hi Team,<br><br>
Please find the below check reports for various sources.<br><br>
It includes the dates of files received for all reports.<br><br>" >> ${final_mail_content}

prepare_mail TM1
prepare_mail TM1D
prepare_mail TM1W
prepare_mail ekaizen
prepare_mail ehsip
prepare_mail IHS
prepare_mail jdm
#sending email notification
 (
 echo "From: $Fromlist"
 echo "To:$Tolist"
 echo "MIME-Version: 1.0"
 echo "Content-Type: text/html: "
 if [ -s ${mail_attachment} ];
 then
   echo "Subject: Monitoring file alerts - ERROR"
 else
   echo "Subject: Monitoring file alerts"
 fi
 cat ${final_mail_content}
 echo "<br>"
 echo "<h1>Error messages</h1>"
 echo "<br>"
 cat ${mail_attachment}
 echo "<br><br>Thank you,<br>EIP-Hadoop Support Team."
 ) | sendmail -t

 if [ $? == 0 ];then
 echo "Email has been sent">> ${eip_log_path}/monitoring_alerts/mail_status.log
 else
 echo "Issue in sending email">> ${eip_log_path}/monitoring_alerts/mail_status.log
 fi
