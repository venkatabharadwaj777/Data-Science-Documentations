#!/bin/bash

##script to read Database credentials, Table name, Target directory.
##Then generate Sqoop script to import historical and incremental data.

##Fetch the required data from Stored Procedures, Operational Script, config file and Sqoop_args.
DB_USERNAME=${1}
DB_PASSWD=${2}
TBL_NAME=${3}
SPLIT_BY_COL=${4}
TBL_schema=${5}
DB_Type=${6}
DB_Instance_IP=${7}
DB_Port=${8}
DB_Name=${9}
CDC_COL=${10}
CDC_VAL="${11} ${12}"
LOAD_TYPE=${13}
script_location=${14}
rundate=${15}
sqoop_log=${16}
server_name=${17}
instance_name=${18}
UpperBound_date="${19} ${20}"
sequence=${21}
source_name=${22}
MAPPER=${23}
HDFS_TBL=${24}
config_file=${25}
temp_server_name=${26}
logical_name=${27}
FFQ_Flag=${28}
view_flag=${29}
QUERY_STRING1=${30}

QUERY_STRING=`echo "$QUERY_STRING1"|sed -e "s/|/ /g"`


logged_user=`whoami`

#echo $QUERY_STRING1
#echo $QUERY_STRING
##Source the path configuration file to read and call all the variables from config.txt into this script.
source $config_file

# Function to log messages with timestamp to defined log file
function log() {
 # log_time=`date "+%m-%d-%Y:%H:%M:%S"`
  echo -e "${log_time} $*" >> ${sqoop_log}/$source_name/$rundate/${logical_name}/${logical_name}\_instance.log
}
echo $#
##Check for number of arguments passed from OperationalScript
if [ $# -ne 30 ]
then

sqoop_query="sqoop ${sqp_arg[0]} --${sqp_arg[1]} 2>$sqoop_log/$source_name/$rundate/${logical_name}/${TBL_NAME}/${HDFS_TBL}_sqoop.log" 
echo $sqoop_query >>$script_location/$source_name/$rundate/${logical_name}/$TBL_NAME/${HDFS_TBL}.sh 
#    rm $sqoop_log/$source_name/$rundate/${logical_name}/${TBL_NAME}/_SQOOP_RUNNING
#    touch $sqoop_log/$source_name/$rundate/${logical_name}/${TBL_NAME}/_SQOOP_FAIL
#    echo "Error: Some arguments are missing in generate_SqoopQuery.sh" >> $sqoop_log/$source_name/$rundate/${logical_name}/${TBL_NAME}/${HDFS_TBL}_sqoop.log
									    
    exit 1
fi

##Check whether Target directory path and Mapper value is not empty.
if [ "$TARGET_DIR" == "" ] || [ "$Field_Terminator" == "" ] || [ "$Null_string" == "" ] || [ "$Hive_delim" == "" ]
then
log "Error: Target directory, Field_Terminator, Null_string or Hive_delim field is empty"
exit 1
fi
#echo "CDC_COL "$CDC_COL
#echo "CDC_VAL "$CDC_VAL
#echo "UpperBound_date "$UpperBound_date
Where_str="\"$CDC_COL >= '$CDC_VAL' and $CDC_COL < '$UpperBound_date'\"" #Where condition formation

Where_str_ffq="$CDC_COL >= '\"'\"'$CDC_VAL'\"'\"' and $CDC_COL < '\"'\"'$UpperBound_date'\"'\"'" #Where condition formation

#echo "Where_str "$Where_str
#Target_subdir=`find /d/temp/ -maxdepth 1 -type d | wc -l`
#Target_subdir=$TARGET_DIR/$TBL_NAME

if [ "$DB_Type" == "sap" ]
then
        ##Gather the required Sqoop arguments and store in a separate file.
        Req_args=`grep "YES=" $sap_Sqoop_Argument | cut -d'=' -f2`;
        echo $Req_args > Args1.txt
        sed 's/|/\n/g' Args1.txt >args_final.txt
        mapfile -t sqp_arg <args_final.txt

        DBCONN_STRING="\"jdbc:sap://${DB_Instance_IP}:${DB_Port}/?currentschema=${TBL_schema}\""

	if [ "$LOAD_TYPE" == "D" ];
	then 		
		if [ "$FFQ_Flag" == "Y" ] || [ "$FFQ_Flag" == "YQ" ];
        	then
			if [ "$view_flag" == "Y" ];
			then
				query_string_FFQ="$QUERY_STRING where \$CONDITIONS"
				sqoop_query="sqoop ${sqp_arg[0]} --${sqp_arg[1]} \$1 --password-file file:///home/$logged_user/$DB_Name.password --${sqp_arg[3]} $DBCONN_STRING --${sqp_arg[13]} '$query_string_FFQ' --${sqp_arg[5]} $MAPPER --${sqp_arg[6]} $SPLIT_BY_COL --${sqp_arg[7]} \\$Field_Terminator --${sqp_arg[8]} ${TARGET_DIR}${source_name,,}/${HDFS_TBL} --${sqp_arg[9]} $driver --${sqp_arg[10]} '$Null_string' --${sqp_arg[11]} '$Null_string' --${sqp_arg[12]} '$Hive_delim' 2>$sqoop_log/$source_name/$rundate/${logical_name}/${TBL_NAME}/${HDFS_TBL}_sqoop.log" 
				echo $sqoop_query

			else			
				#query_string_FFQ=`echo "$QUERY_STRING"|awk -F "where" '{print $1}'`
				#echo "query string first: "$query_string_FFQ
				#echo "where_str "$Where_str_ffq
				query_string_FFQ="$QUERY_STRING where $Where_str_ffq and \$CONDITIONS"
				#echo "query string 2nd: "$query_string_FFQ
				sqoop_query="sqoop ${sqp_arg[0]} --${sqp_arg[1]} \$1 --password-file file:///home/$logged_user/$DB_Name.password --${sqp_arg[3]} $DBCONN_STRING --${sqp_arg[13]} '$query_string_FFQ' --${sqp_arg[5]} $MAPPER --${sqp_arg[6]} $SPLIT_BY_COL --${sqp_arg[7]} \\$Field_Terminator --${sqp_arg[8]} ${TARGET_DIR}${source_name,,}/${HDFS_TBL} --${sqp_arg[9]} $driver --${sqp_arg[10]} '$Null_string' --${sqp_arg[11]} '$Null_string' --${sqp_arg[12]} '$Hive_delim' 2>$sqoop_log/$source_name/$rundate/${logical_name}/${TBL_NAME}/${HDFS_TBL}_sqoop.log" 
				#Changed by Gaurav
				#echo $sqoop_query
			fi
        	else
             		sqoop_query="sqoop ${sqp_arg[0]} --${sqp_arg[1]} \$1 --password-file file:///home/$logged_user/$DB_Name.password --${sqp_arg[3]} $DBCONN_STRING --${sqp_arg[4]} $TBL_NAME --${sqp_arg[5]} $MAPPER --${sqp_arg[6]} $SPLIT_BY_COL --${sqp_arg[7]} \\$Field_Terminator --${sqp_arg[8]} ${TARGET_DIR}${source_name,,}/${HDFS_TBL} --${sqp_arg[9]} $driver --${sqp_arg[9]} $Where_str --${sqp_arg[10]} '$Null_string' --${sqp_arg[11]} '$Null_string' --${sqp_arg[12]} '$Hive_delim' 2>$sqoop_log/$source_name/$rundate/${logical_name}/${TBL_NAME}/${HDFS_TBL}_sqoop.log"
			#Changed by Gaurav
			#echo $sqoop_query
		fi
	else
		if [ "$FFQ_Flag" == "Y" ] || [ "$FFQ_Flag" == "YQ" ];
        	then
		query_string_FFQ="$QUERY_STRING where \$CONDITIONS"
             	sqoop_query="sqoop ${sqp_arg[0]} --${sqp_arg[1]} \$1 --password-file file:///home/$logged_user/$DB_Name.password --${sqp_arg[3]} $DBCONN_STRING --${sqp_arg[13]} '$query_string_FFQ' --${sqp_arg[5]} $MAPPER --${sqp_arg[6]} $SPLIT_BY_COL --${sqp_arg[7]} \\$Field_Terminator --${sqp_arg[8]} ${TARGET_DIR}${source_name,,}/${HDFS_TBL} --${sqp_arg[9]} $driver --${sqp_arg[10]} '$Null_string' --${sqp_arg[11]} '$Null_string' --${sqp_arg[12]} '$Hive_delim' 2>$sqoop_log/$source_name/$rundate/${logical_name}/${TBL_NAME}/${HDFS_TBL}_sqoop.log"
#Changed by Gaurav
		#echo $sqoop_query
		else
             	sqoop_query="sqoop ${sqp_arg[0]} --${sqp_arg[1]} \$1 --password-file file:///home/$logged_user/$DB_Name.password --${sqp_arg[3]} $DBCONN_STRING --${sqp_arg[4]} $TBL_NAME --${sqp_arg[5]} $MAPPER --${sqp_arg[6]} $SPLIT_BY_COL --${sqp_arg[7]} \\$Field_Terminator --${sqp_arg[8]} ${TARGET_DIR}${source_name,,}/${HDFS_TBL} --${sqp_arg[9]} $driver --${sqp_arg[10]} '$Null_string' --${sqp_arg[11]} '$Null_string' --${sqp_arg[12]} '$Hive_delim' 2>$sqoop_log/$source_name/$rundate/${logical_name}/${TBL_NAME}/${HDFS_TBL}_sqoop.log"
#Changed by Gaurav
		#echo $sqoop_query
		fi
	fi 
else

##Gather the required Sqoop arguments and store in a separate file.
Req_args=`grep "YES=" $Sqoop_Argument | cut -d'=' -f2`;
echo $Req_args > Args1.txt
sed 's/|/\n/g' Args1.txt >args_final.txt
mapfile -t sqp_arg <args_final.txt

chmod 777 Args1.txt args_final.txt

	if [ "${server_name}" == "NULL" ];
	then
        DBCONN_STRING="\"jdbc:${DB_Type}://${DB_Instance_IP}:${DB_Port};database=${DB_Name};ApplicationIntent=ReadOnly;\""
else
        if [ "${instance_name}" == "NULL" ];
        then
                DBCONN_STRING="\"jdbc:${DB_Type}://${server_name};database=${DB_Name};ApplicationIntent=ReadOnly;\"" #Form DB connection string
        else
                DBCONN_STRING="\"jdbc:${DB_Type}://${server_name}\\${instance_name};database=${DB_Name};ApplicationIntent=ReadOnly;\"" #Form DB connection string
        fi
fi

##Sqoop query generation
        if [ "$LOAD_TYPE" = "D" ];
        then
             sqoop_query="sqoop ${sqp_arg[0]} --${sqp_arg[1]} ${DBCONN_STRING} --${sqp_arg[2]} \$1 --password-file file:///home/$logged_user/$DB_Name.password --${sqp_arg[4]} $TBL_NAME --${sqp_arg[5]} $MAPPER --${sqp_arg[6]} $SPLIT_BY_COL --${sqp_arg[7]} \\$Field_Terminator --${sqp_arg[8]} ${TARGET_DIR}${source_name,,}/${HDFS_TBL} --${sqp_arg[9]} $Where_str --${sqp_arg[10]} '$Null_string' --${sqp_arg[11]} '$Null_string' --${sqp_arg[12]} '$Hive_delim' -- --${sqp_arg[13]} $TBL_schema 2>>$sqoop_log/$source_name/$rundate/${logical_name}/${TBL_NAME}/${HDFS_TBL}_sqoop.log"
#Changed by Gaurav
        else
             sqoop_query="sqoop ${sqp_arg[0]} --${sqp_arg[1]} ${DBCONN_STRING} --${sqp_arg[2]} \$1 --password-file file:///home/$logged_user/$DB_Name.password --${sqp_arg[4]} $TBL_NAME --${sqp_arg[5]} $MAPPER --${sqp_arg[6]} $SPLIT_BY_COL --${sqp_arg[7]} \\$Field_Terminator --${sqp_arg[8]} ${TARGET_DIR}${source_name,,}/${HDFS_TBL} --${sqp_arg[10]} '$Null_string' --${sqp_arg[11]} '$Null_string' --${sqp_arg[12]} '$Hive_delim' -- --${sqp_arg[13]} $TBL_schema 2>>$sqoop_log/$source_name/$rundate/${logical_name}/${TBL_NAME}/${HDFS_TBL}_sqoop.log"
#Changed by Gaurav
        fi
fi

	echo $sqoop_query	
      echo $sqoop_query >>$script_location/$source_name/$rundate/${logical_name}/$TBL_NAME/${HDFS_TBL}.sh

##Remove the intermediate files once the required data is extracted.

rm Args1.txt args_final.txt

###EOF###
