#!/bin/bash

##script to initiate historical data load using Sqoop for MKPF and MSEG table.
#$1 load type
#$2 user name
#$3 password 
#$4 MJAHR
#$5 BUDAT_START/ZZDATE_START
#$6 BUDAT_END/ZZDATE_END

# Get the hostname to determine the CLUSTER
case "${HOSTNAME:9:1}" in
  "d")
    # DEV only
    export CLUSTER=dev
    export CLUSTER_CODE=d
    ;;
  "q")
    # STG only
    export CLUSTER=stg
    export CLUSTER_CODE=s
    ;;
  "p")
    # PRD only
    export CLUSTER=prd
    export CLUSTER_CODE=c
    ;;

  *) # not good
    echo "\$HOSTNAME='${HOSTNAME}' unexpected server hostname"
    exit 1
esac

cli="beeline -u 'jdbc:hive2://hadoop${CLUSTER}.corp.jabil.org:10000/default;principal=hive/_HOST@CORP.JABIL.ORG;ssl=true'"

hadoop fs -test -d /data/landing/sap/sap_hana_ecc_ha_mkpf_hist
if [ $? == 0 ]
then
	hadoop fs -rm -r /data/landing/sap/sap_hana_ecc_ha_mkpf_hist
fi

if [ $1 == I ];
then
	#sqoop import --username $2 --password $3 --connect "jdbc:sap://172.20.233.110:32015/?currentschema=_SYS_BIC" --query 'SELECT AEDAT,AWSYS,BFWMS,BKTXT,BLA2D,BLART,BLAUM,BLDAT,BUDAT,CPUDT,CPUTM,EXNUM,FLS_RSTO,FRATH,FRBNR,GTS_CUSREF_NO,KNUMV,LE_VBELN,MANDT,MBLNR,MJAHR,MSR_ACTIVE,SEQGEN,SPE_BUDAT_UHR,SPE_BUDAT_ZONE,SPE_LOGSYS,SPE_MDNUM_EWM,TCODE,TCODE2,USNAM,VGART,WEVER,XABLN,XBLNR,ZZDATE,ZZTIME FROM "_SYS_BIC"."production.mm/CA_MKPF_IP"('"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_BUDAT_END$$'"'"', '"'"'$6'"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_MJAHR$$'"'"', '"'"'$4'"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZDATE_END$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZTIME_END$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZDATE_START$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZTIME_START$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_BUDAT_START$$'"'"', '"'"'$5'"'"')) where $CONDITIONS ' --m 5 --split-by SEQGEN --fields-terminated-by \\001 --target-dir /data/landing/sap/sap_hana_ecc_ha_mkpf_hist --driver com.sap.db.jdbc.Driver --null-string '\\N' --null-non-string '\\N' --hive-delims-replacement ' ' 2>mkpf_$5_$6.log
else
	#sqoop import --username $2 --password $3 --connect "jdbc:sap://172.20.233.110:32015/?currentschema=_SYS_BIC" --query 'SELECT AEDAT,AWSYS,BFWMS,BKTXT,BLA2D,BLART,BLAUM,BLDAT,BUDAT,CPUDT,CPUTM,EXNUM,FLS_RSTO,FRATH,FRBNR,GTS_CUSREF_NO,KNUMV,LE_VBELN,MANDT,MBLNR,MJAHR,MSR_ACTIVE,SEQGEN,SPE_BUDAT_UHR,SPE_BUDAT_ZONE,SPE_LOGSYS,SPE_MDNUM_EWM,TCODE,TCODE2,USNAM,VGART,WEVER,XABLN,XBLNR,ZZDATE,ZZTIME FROM "_SYS_BIC"."production.mm/CA_MKPF_IP"('"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_BUDAT_END$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_MJAHR$$'"'"', '"'"'$4'"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZDATE_END$$'"'"', '"'"'$6'"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZTIME_END$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZDATE_START$$'"'"', '"'"'$5'"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZTIME_START$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_BUDAT_START$$'"'"', '"'"' '"'"')) where $CONDITIONS ' --m 5 --split-by SEQGEN --fields-terminated-by \\001 --target-dir /data/landing/sap/sap_hana_ecc_ha_mkpf_hist --driver com.sap.db.jdbc.Driver --null-string '\\N' --null-non-string '\\N' --hive-delims-replacement ' ' 2>mkpf_delta_$5_$6.log
fi

if [ "$exit_code" == 0 ];
then
	echo "MKPF table imported successfully for period : $5 and $6 "
	$cli --silent=true -e 'FROM LANDING.sap_hana_ecc_ha_MKPF_hist INSERT INTO table LANDING.sap_hana_ecc_ha_mkpf SELECT *;'
else
	echo "MKPF table imported failed for period : $5 and $6 "
	#exit 1
fi



hadoop fs -test -d /data/landing/sap/sap_hana_ecc_ha_mseg_hist
if [ $? == 0 ]
then
	hadoop fs -rm -r /data/landing/sap/sap_hana_ecc_ha_mseg_hist
fi

if [ $1 == I ];
then
	#sqoop import --username $2 --password $3 --connect "jdbc:sap://172.20.233.110:32015/?currentschema=_SYS_BIC" --query 'select BUDAT_MKPF,BUKRS,BWART,CHARG,DMBTR,EBELN,EBELP,EMATN,GRUND,INSMK,KDAUF,KDPOS,KZBEW,LGORT,LIFNR,MANDT,MATNR,MBLNR,MEINS,MENGE,MJAHR,SGTXT,SHKZG,SOBKZ,WAERS,WERKS,ZEILE,ZZDATE,ZZTIME FROM "_SYS_BIC"."production.mm/CA_MSEG_IP"('"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_BUDAT_END$$'"'"', '"'"'$6'"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_MJAHR$$'"'"', '"'"'$4'"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZDATE_END$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZTIME_END$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZDATE_START$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZTIME_START$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_BUDAT_START$$'"'"', '"'"'$5'"'"')) where $CONDITIONS ' --m 5 --split-by BUDAT_MKPF --fields-terminated-by \\001 --target-dir /data/landing/sap/sap_hana_ecc_ha_mseg_hist --driver com.sap.db.jdbc.Driver --null-string '\\N' --null-non-string '\\N' --hive-delims-replacement ' ' 2>mseg_$5_$6.log
else
	#sqoop import --username $2 --password $3 --connect "jdbc:sap://172.20.233.110:32015/?currentschema=_SYS_BIC" --query 'select BUDAT_MKPF,BUKRS,BWART,CHARG,DMBTR,EBELN,EBELP,EMATN,GRUND,INSMK,KDAUF,KDPOS,KZBEW,LGORT,LIFNR,MANDT,MATNR,MBLNR,MEINS,MENGE,MJAHR,SGTXT,SHKZG,SOBKZ,WAERS,WERKS,ZEILE,ZZDATE,ZZTIME FROM "_SYS_BIC"."production.mm/CA_MSEG_IP"('"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_BUDAT_END$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_MJAHR$$'"'"', '"'"'$4'"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZDATE_END$$'"'"', '"'"'$6'"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZTIME_END$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZDATE_START$$'"'"', '"'"'$5'"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_ZZTIME_START$$'"'"', '"'"' '"'"'), '"'"'PLACEHOLDER'"'"' = ('"'"'$$IP_BUDAT_START$$'"'"', '"'"' '"'"')) where $CONDITIONS ' --m 5 --split-by BUDAT_MKPF --fields-terminated-by \\001 --target-dir /data/landing/sap/sap_hana_ecc_ha_mseg_hist --driver com.sap.db.jdbc.Driver --null-string '\\N' --null-non-string '\\N' --hive-delims-replacement ' ' 2>mseg_delta_$5_$6.log
fi

if [ "$exit_code" == 0 ];
then
	echo "MSEG table imported successfully for period : $5 and $6 "
	$cli --silent=true -e 'FROM LANDING.sap_hana_ecc_ha_mseg_hist INSERT INTO table LANDING.sap_hana_ecc_ha_mseg SELECT *;'
else
	echo "MSEG table imported failed for period : $5 and $6 "
	#exit 1
fi
