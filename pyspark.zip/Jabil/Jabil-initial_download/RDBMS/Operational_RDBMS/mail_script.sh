#!/bin/bash

##Arguments

mail_cfg_file=$1
source_name=$2
run_date=$3
logical_name=$4
temp_server_name=$5
instance_name=$6
database_name=$7
status1=$8
mail_attachment=""      # Email attachment file & path

rundate=`date "+%Y-%m-%d"`
run_timestamp=`date "+%Y-%m-%d:%H:%M:%S"`

## Mailx config parameters
if [ -f ${mail_cfg_file} ];then
	source $mail_cfg_file # sourced from above config file mail_log_path, process_log, send_mail, mail_log_prefix
else
        echo "Error: "${mail_cfg_file} " file does not exist"
        exit 1
fi

send_mail=`grep "mail_${status1}" $mail_cfg_file | cut -d'=' -f2`

if [ ${status1} == "MEMORY_FAIL" ]
then

subject_line="Instance Status: ${status1} for ${logical_name} as Too less memory available"	# Subject line of the email to be sent
mail_body="Data load for server '${temp_server_name}' source '${source_name}' Instance '${instance_name}' database '${database_name}' is ${status1}. Available memory is too less to start, please clear the memory and re-run"		# email body content

else

subject_line="Instance Status: ${status1} for ${logical_name}"	# Subject line of the email to be sent
mail_body="Data load for server '${temp_server_name}' source '${source_name}' Instance '${instance_name}' database '${database_name}' is ${status1}. Check the log at: $process_log/${source_name}/$rundate/${logical_name}/${logical_name}_instance.log for more details"		# email body content

fi

##Fetch mail recipient list from mailing_list.conf
mail_recipient=`grep "$source_name=" $mailing_list | cut -d'=' -f2`

# Function to log messages with timestamp to defined log file
function log() {
        log_time=`date "+%m-%d-%Y:%H:%M:%S"`
        echo -e "${log_time} $*" >> ${mail_log_file}
}

#echo "mail_cfg_file: $mail_cfg_file"
#echo "source_name: $source_name"
#echo "run_date: $run_date"
#echo "logical_name: $logical_name"
#echo "temp_server_name: $temp_server_name"
#echo "instance_name: $instance_name"
#echo "database_name: $database_name"
#echo "status: $status1"
#echo "mail_attachment: $mail_attachment"
#echo "send_mail: $send_mail"
#echo "subject_line: $subject_line"
#echo "mail_body: $mail_body"
#echo "mail_recipient: $mail_recipient"

#echo "smtp: ${smtp}"
#echo "from: ${email_from}"
#echo "mailing_list: ${mailing_list}"

mail_log_file="${mail_log_path}/${mail_log_prefix}${rundate}.log"

if [ ! -f ${mail_log_file} ];
then
	echo "Mail log does not exists, creating a new log for ${rundate}: ${mail_log_file}"
	touch ${mail_log_file}
	if [ $? -ne 0 ]; then
		echo "Error creating mail log ${mail_log_file}"
		exit 1
	fi
fi

if [[ $# -eq 8 && $send_mail == "Y" ]]; then
		echo "Send email without attachments"
		log "Info: Sending email No Attachments"
		mailx -S smtp=${smtp} -s "${subject_line}" -S from=${email_from} ${mail_recipient} <<-EOF
			$run_timestamp

			Dear Team,	

			$mail_body
				
			Thanks,
			Hadoop Support team

			<End of message>
			EOF
			if [ $? -eq 0 ]; then
				log "Info: Email sent successfully No attachment"
			else
				log "Error: Error sending email no attachment"
				exit 1
			fi
elif [[ $# -eq 8 && $send_mail == "N" ]]; then
	log "No mail to be sent"
elif [[ $# -eq 9 && $send_mail == "Y" ]]; then
		echo "Send email with attachments"
		log "Info: Sending email with attachment"
		mailx -S smtp=${smtp} -s "success: ${subject_line}" -a ${mail_attachment} -S from=${email_from} ${mail_recipient} <<-EOF
			$run_timestamp

			Dear Team,
			
			$mail_body

			Thanks,
			Hadoop Support team

			<End of message>
			EOF
	                if [ $? -eq 0 ]; then
				log "Info: Email with attachment sent successfully"
				log "Info: Attachment '${mail_attachment}'"
			else
				log "Error: Error sending email with attachment"
				log "Error: Attachment ${mail_attachment}"
	                	exit 1
        	        fi
elif [[ $# -eq 9 && $send_mail == "N" ]]; then
	log "No mail to be sent"
fi
###EOF###