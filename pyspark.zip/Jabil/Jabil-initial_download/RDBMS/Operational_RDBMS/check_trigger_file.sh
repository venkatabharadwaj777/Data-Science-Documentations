#!/bin/bash
##################################################################################################################################
#Script Name :check_trigger_file.sh                                                                                              #
#Purpose :Script to check the status if the trigger file is present and if not then wait for it  to  run the operational script. #
##################################################################################################################################

##Arguments

logical_name=$1
config_file=$2  #Config file to Source Enviornmnet Variables.

source $config_file

#echo ${file_name}
file_path=$(ls ${file_name} |sort -n -r |head -1 )
filename=`basename $file_path`

max_file_date=`basename $filename | cut -d "_" -f 1`
#echo "$filename is filename"
echo "$max_file_date is max_date"
Curr_Date=`date +%Y%m%d`


#echo $Curr_Date

if [ "${max_file_date}" != "" ] && [ "${Curr_Date}" -eq "${max_file_date}" ]
then
  break;
else
  echo "touch file is not present so have to wait"
  touch /eip_interfaces/data/cdmjis/${Curr_Date}_JabilDB_AMERICAS_Succes.dat
   for (( k=0; k<${waitfortrigger}; k++ ))
  do
  
    #echo "system initiated wait for trigger"

     echo -en "\n******Script is waiting for File :"
     for i in {0..60}; do
     sleep 1
        echo -en "."
     done       

    file_path=$(ls ${file_name} | sort -n -r | head -1)
   # echo ${file_path}
    max_file_date=`basename $file_path | cut -d "_" -f 1`
    #echo "$max_file_date is maxfiledate"
    if [ "${max_file_date}" != "" ] && [ "${Curr_Date}" -eq "${max_file_date}" ]
    then
      flag="set"
      break;
    else
      continue;
    fi
#  done
  done

  if [ "${flag}" == "set" ]
  then
    break;
  else
    echo
    echo "error: did not find any file after waiting for ${waitfortrigger} minutes in the folder "
    exit 1
  fi
fi

Curr_Date=`date +%Y%m%d`
#echo ${Curr_Date}
#echo ${max_file_date}

if [ ${Curr_Date} != ${max_file_date} ]
then
 echo  " error: file date format incorrect in folder or no file found of current date "
  exit 1
fi

sh $File_PATH/OperationalScript_RDBMS.sh $1 $2
if [ $? == 0 ]
then
	rm $file_path
fi
