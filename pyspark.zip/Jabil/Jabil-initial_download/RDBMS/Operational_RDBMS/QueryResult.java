// ORM class for table 'null'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Tue May 21 02:27:39 EDT 2019
// For connector: org.apache.sqoop.manager.GenericJdbcManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QueryResult extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("AENAM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        AENAM = (String)value;
      }
    });
    setters.put("CEINM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CEINM = (java.math.BigDecimal)value;
      }
    });
    setters.put("CHARG", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CHARG = (String)value;
      }
    });
    setters.put("CHDLL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CHDLL = (String)value;
      }
    });
    setters.put("CHJIN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CHJIN = (String)value;
      }
    });
    setters.put("CHRUE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CHRUE = (String)value;
      }
    });
    setters.put("CINSM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CINSM = (java.math.BigDecimal)value;
      }
    });
    setters.put("CLABS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CLABS = (java.math.BigDecimal)value;
      }
    });
    setters.put("CRETM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CRETM = (java.math.BigDecimal)value;
      }
    });
    setters.put("CSPEM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CSPEM = (java.math.BigDecimal)value;
      }
    });
    setters.put("CUMLM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CUMLM = (java.math.BigDecimal)value;
      }
    });
    setters.put("CVMEI", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CVMEI = (java.math.BigDecimal)value;
      }
    });
    setters.put("CVMIN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CVMIN = (java.math.BigDecimal)value;
      }
    });
    setters.put("CVMLA", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CVMLA = (java.math.BigDecimal)value;
      }
    });
    setters.put("CVMRE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CVMRE = (java.math.BigDecimal)value;
      }
    });
    setters.put("CVMSP", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CVMSP = (java.math.BigDecimal)value;
      }
    });
    setters.put("CVMUM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CVMUM = (java.math.BigDecimal)value;
      }
    });
    setters.put("ERNAM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ERNAM = (String)value;
      }
    });
    setters.put("ERSDA", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ERSDA = (String)value;
      }
    });
    setters.put("HERKL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        HERKL = (String)value;
      }
    });
    setters.put("KZICE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        KZICE = (String)value;
      }
    });
    setters.put("KZICL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        KZICL = (String)value;
      }
    });
    setters.put("KZICQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        KZICQ = (String)value;
      }
    });
    setters.put("KZICS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        KZICS = (String)value;
      }
    });
    setters.put("KZVCE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        KZVCE = (String)value;
      }
    });
    setters.put("KZVCL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        KZVCL = (String)value;
      }
    });
    setters.put("KZVCQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        KZVCQ = (String)value;
      }
    });
    setters.put("KZVCS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        KZVCS = (String)value;
      }
    });
    setters.put("LAEDA", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        LAEDA = (String)value;
      }
    });
    setters.put("LFGJA", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        LFGJA = (String)value;
      }
    });
    setters.put("LFMON", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        LFMON = (String)value;
      }
    });
    setters.put("LGORT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        LGORT = (String)value;
      }
    });
    setters.put("LVORM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        LVORM = (String)value;
      }
    });
    setters.put("MANDT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        MANDT = (String)value;
      }
    });
    setters.put("MATNR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        MATNR = (String)value;
      }
    });
    setters.put("SEQGEN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        SEQGEN = (Long)value;
      }
    });
    setters.put("SGT_SCAT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        SGT_SCAT = (String)value;
      }
    });
    setters.put("SPERC", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        SPERC = (String)value;
      }
    });
    setters.put("WERKS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        WERKS = (String)value;
      }
    });
  }
  public QueryResult() {
    init0();
  }
  private String AENAM;
  public String get_AENAM() {
    return AENAM;
  }
  public void set_AENAM(String AENAM) {
    this.AENAM = AENAM;
  }
  public QueryResult with_AENAM(String AENAM) {
    this.AENAM = AENAM;
    return this;
  }
  private java.math.BigDecimal CEINM;
  public java.math.BigDecimal get_CEINM() {
    return CEINM;
  }
  public void set_CEINM(java.math.BigDecimal CEINM) {
    this.CEINM = CEINM;
  }
  public QueryResult with_CEINM(java.math.BigDecimal CEINM) {
    this.CEINM = CEINM;
    return this;
  }
  private String CHARG;
  public String get_CHARG() {
    return CHARG;
  }
  public void set_CHARG(String CHARG) {
    this.CHARG = CHARG;
  }
  public QueryResult with_CHARG(String CHARG) {
    this.CHARG = CHARG;
    return this;
  }
  private String CHDLL;
  public String get_CHDLL() {
    return CHDLL;
  }
  public void set_CHDLL(String CHDLL) {
    this.CHDLL = CHDLL;
  }
  public QueryResult with_CHDLL(String CHDLL) {
    this.CHDLL = CHDLL;
    return this;
  }
  private String CHJIN;
  public String get_CHJIN() {
    return CHJIN;
  }
  public void set_CHJIN(String CHJIN) {
    this.CHJIN = CHJIN;
  }
  public QueryResult with_CHJIN(String CHJIN) {
    this.CHJIN = CHJIN;
    return this;
  }
  private String CHRUE;
  public String get_CHRUE() {
    return CHRUE;
  }
  public void set_CHRUE(String CHRUE) {
    this.CHRUE = CHRUE;
  }
  public QueryResult with_CHRUE(String CHRUE) {
    this.CHRUE = CHRUE;
    return this;
  }
  private java.math.BigDecimal CINSM;
  public java.math.BigDecimal get_CINSM() {
    return CINSM;
  }
  public void set_CINSM(java.math.BigDecimal CINSM) {
    this.CINSM = CINSM;
  }
  public QueryResult with_CINSM(java.math.BigDecimal CINSM) {
    this.CINSM = CINSM;
    return this;
  }
  private java.math.BigDecimal CLABS;
  public java.math.BigDecimal get_CLABS() {
    return CLABS;
  }
  public void set_CLABS(java.math.BigDecimal CLABS) {
    this.CLABS = CLABS;
  }
  public QueryResult with_CLABS(java.math.BigDecimal CLABS) {
    this.CLABS = CLABS;
    return this;
  }
  private java.math.BigDecimal CRETM;
  public java.math.BigDecimal get_CRETM() {
    return CRETM;
  }
  public void set_CRETM(java.math.BigDecimal CRETM) {
    this.CRETM = CRETM;
  }
  public QueryResult with_CRETM(java.math.BigDecimal CRETM) {
    this.CRETM = CRETM;
    return this;
  }
  private java.math.BigDecimal CSPEM;
  public java.math.BigDecimal get_CSPEM() {
    return CSPEM;
  }
  public void set_CSPEM(java.math.BigDecimal CSPEM) {
    this.CSPEM = CSPEM;
  }
  public QueryResult with_CSPEM(java.math.BigDecimal CSPEM) {
    this.CSPEM = CSPEM;
    return this;
  }
  private java.math.BigDecimal CUMLM;
  public java.math.BigDecimal get_CUMLM() {
    return CUMLM;
  }
  public void set_CUMLM(java.math.BigDecimal CUMLM) {
    this.CUMLM = CUMLM;
  }
  public QueryResult with_CUMLM(java.math.BigDecimal CUMLM) {
    this.CUMLM = CUMLM;
    return this;
  }
  private java.math.BigDecimal CVMEI;
  public java.math.BigDecimal get_CVMEI() {
    return CVMEI;
  }
  public void set_CVMEI(java.math.BigDecimal CVMEI) {
    this.CVMEI = CVMEI;
  }
  public QueryResult with_CVMEI(java.math.BigDecimal CVMEI) {
    this.CVMEI = CVMEI;
    return this;
  }
  private java.math.BigDecimal CVMIN;
  public java.math.BigDecimal get_CVMIN() {
    return CVMIN;
  }
  public void set_CVMIN(java.math.BigDecimal CVMIN) {
    this.CVMIN = CVMIN;
  }
  public QueryResult with_CVMIN(java.math.BigDecimal CVMIN) {
    this.CVMIN = CVMIN;
    return this;
  }
  private java.math.BigDecimal CVMLA;
  public java.math.BigDecimal get_CVMLA() {
    return CVMLA;
  }
  public void set_CVMLA(java.math.BigDecimal CVMLA) {
    this.CVMLA = CVMLA;
  }
  public QueryResult with_CVMLA(java.math.BigDecimal CVMLA) {
    this.CVMLA = CVMLA;
    return this;
  }
  private java.math.BigDecimal CVMRE;
  public java.math.BigDecimal get_CVMRE() {
    return CVMRE;
  }
  public void set_CVMRE(java.math.BigDecimal CVMRE) {
    this.CVMRE = CVMRE;
  }
  public QueryResult with_CVMRE(java.math.BigDecimal CVMRE) {
    this.CVMRE = CVMRE;
    return this;
  }
  private java.math.BigDecimal CVMSP;
  public java.math.BigDecimal get_CVMSP() {
    return CVMSP;
  }
  public void set_CVMSP(java.math.BigDecimal CVMSP) {
    this.CVMSP = CVMSP;
  }
  public QueryResult with_CVMSP(java.math.BigDecimal CVMSP) {
    this.CVMSP = CVMSP;
    return this;
  }
  private java.math.BigDecimal CVMUM;
  public java.math.BigDecimal get_CVMUM() {
    return CVMUM;
  }
  public void set_CVMUM(java.math.BigDecimal CVMUM) {
    this.CVMUM = CVMUM;
  }
  public QueryResult with_CVMUM(java.math.BigDecimal CVMUM) {
    this.CVMUM = CVMUM;
    return this;
  }
  private String ERNAM;
  public String get_ERNAM() {
    return ERNAM;
  }
  public void set_ERNAM(String ERNAM) {
    this.ERNAM = ERNAM;
  }
  public QueryResult with_ERNAM(String ERNAM) {
    this.ERNAM = ERNAM;
    return this;
  }
  private String ERSDA;
  public String get_ERSDA() {
    return ERSDA;
  }
  public void set_ERSDA(String ERSDA) {
    this.ERSDA = ERSDA;
  }
  public QueryResult with_ERSDA(String ERSDA) {
    this.ERSDA = ERSDA;
    return this;
  }
  private String HERKL;
  public String get_HERKL() {
    return HERKL;
  }
  public void set_HERKL(String HERKL) {
    this.HERKL = HERKL;
  }
  public QueryResult with_HERKL(String HERKL) {
    this.HERKL = HERKL;
    return this;
  }
  private String KZICE;
  public String get_KZICE() {
    return KZICE;
  }
  public void set_KZICE(String KZICE) {
    this.KZICE = KZICE;
  }
  public QueryResult with_KZICE(String KZICE) {
    this.KZICE = KZICE;
    return this;
  }
  private String KZICL;
  public String get_KZICL() {
    return KZICL;
  }
  public void set_KZICL(String KZICL) {
    this.KZICL = KZICL;
  }
  public QueryResult with_KZICL(String KZICL) {
    this.KZICL = KZICL;
    return this;
  }
  private String KZICQ;
  public String get_KZICQ() {
    return KZICQ;
  }
  public void set_KZICQ(String KZICQ) {
    this.KZICQ = KZICQ;
  }
  public QueryResult with_KZICQ(String KZICQ) {
    this.KZICQ = KZICQ;
    return this;
  }
  private String KZICS;
  public String get_KZICS() {
    return KZICS;
  }
  public void set_KZICS(String KZICS) {
    this.KZICS = KZICS;
  }
  public QueryResult with_KZICS(String KZICS) {
    this.KZICS = KZICS;
    return this;
  }
  private String KZVCE;
  public String get_KZVCE() {
    return KZVCE;
  }
  public void set_KZVCE(String KZVCE) {
    this.KZVCE = KZVCE;
  }
  public QueryResult with_KZVCE(String KZVCE) {
    this.KZVCE = KZVCE;
    return this;
  }
  private String KZVCL;
  public String get_KZVCL() {
    return KZVCL;
  }
  public void set_KZVCL(String KZVCL) {
    this.KZVCL = KZVCL;
  }
  public QueryResult with_KZVCL(String KZVCL) {
    this.KZVCL = KZVCL;
    return this;
  }
  private String KZVCQ;
  public String get_KZVCQ() {
    return KZVCQ;
  }
  public void set_KZVCQ(String KZVCQ) {
    this.KZVCQ = KZVCQ;
  }
  public QueryResult with_KZVCQ(String KZVCQ) {
    this.KZVCQ = KZVCQ;
    return this;
  }
  private String KZVCS;
  public String get_KZVCS() {
    return KZVCS;
  }
  public void set_KZVCS(String KZVCS) {
    this.KZVCS = KZVCS;
  }
  public QueryResult with_KZVCS(String KZVCS) {
    this.KZVCS = KZVCS;
    return this;
  }
  private String LAEDA;
  public String get_LAEDA() {
    return LAEDA;
  }
  public void set_LAEDA(String LAEDA) {
    this.LAEDA = LAEDA;
  }
  public QueryResult with_LAEDA(String LAEDA) {
    this.LAEDA = LAEDA;
    return this;
  }
  private String LFGJA;
  public String get_LFGJA() {
    return LFGJA;
  }
  public void set_LFGJA(String LFGJA) {
    this.LFGJA = LFGJA;
  }
  public QueryResult with_LFGJA(String LFGJA) {
    this.LFGJA = LFGJA;
    return this;
  }
  private String LFMON;
  public String get_LFMON() {
    return LFMON;
  }
  public void set_LFMON(String LFMON) {
    this.LFMON = LFMON;
  }
  public QueryResult with_LFMON(String LFMON) {
    this.LFMON = LFMON;
    return this;
  }
  private String LGORT;
  public String get_LGORT() {
    return LGORT;
  }
  public void set_LGORT(String LGORT) {
    this.LGORT = LGORT;
  }
  public QueryResult with_LGORT(String LGORT) {
    this.LGORT = LGORT;
    return this;
  }
  private String LVORM;
  public String get_LVORM() {
    return LVORM;
  }
  public void set_LVORM(String LVORM) {
    this.LVORM = LVORM;
  }
  public QueryResult with_LVORM(String LVORM) {
    this.LVORM = LVORM;
    return this;
  }
  private String MANDT;
  public String get_MANDT() {
    return MANDT;
  }
  public void set_MANDT(String MANDT) {
    this.MANDT = MANDT;
  }
  public QueryResult with_MANDT(String MANDT) {
    this.MANDT = MANDT;
    return this;
  }
  private String MATNR;
  public String get_MATNR() {
    return MATNR;
  }
  public void set_MATNR(String MATNR) {
    this.MATNR = MATNR;
  }
  public QueryResult with_MATNR(String MATNR) {
    this.MATNR = MATNR;
    return this;
  }
  private Long SEQGEN;
  public Long get_SEQGEN() {
    return SEQGEN;
  }
  public void set_SEQGEN(Long SEQGEN) {
    this.SEQGEN = SEQGEN;
  }
  public QueryResult with_SEQGEN(Long SEQGEN) {
    this.SEQGEN = SEQGEN;
    return this;
  }
  private String SGT_SCAT;
  public String get_SGT_SCAT() {
    return SGT_SCAT;
  }
  public void set_SGT_SCAT(String SGT_SCAT) {
    this.SGT_SCAT = SGT_SCAT;
  }
  public QueryResult with_SGT_SCAT(String SGT_SCAT) {
    this.SGT_SCAT = SGT_SCAT;
    return this;
  }
  private String SPERC;
  public String get_SPERC() {
    return SPERC;
  }
  public void set_SPERC(String SPERC) {
    this.SPERC = SPERC;
  }
  public QueryResult with_SPERC(String SPERC) {
    this.SPERC = SPERC;
    return this;
  }
  private String WERKS;
  public String get_WERKS() {
    return WERKS;
  }
  public void set_WERKS(String WERKS) {
    this.WERKS = WERKS;
  }
  public QueryResult with_WERKS(String WERKS) {
    this.WERKS = WERKS;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.AENAM == null ? that.AENAM == null : this.AENAM.equals(that.AENAM));
    equal = equal && (this.CEINM == null ? that.CEINM == null : this.CEINM.equals(that.CEINM));
    equal = equal && (this.CHARG == null ? that.CHARG == null : this.CHARG.equals(that.CHARG));
    equal = equal && (this.CHDLL == null ? that.CHDLL == null : this.CHDLL.equals(that.CHDLL));
    equal = equal && (this.CHJIN == null ? that.CHJIN == null : this.CHJIN.equals(that.CHJIN));
    equal = equal && (this.CHRUE == null ? that.CHRUE == null : this.CHRUE.equals(that.CHRUE));
    equal = equal && (this.CINSM == null ? that.CINSM == null : this.CINSM.equals(that.CINSM));
    equal = equal && (this.CLABS == null ? that.CLABS == null : this.CLABS.equals(that.CLABS));
    equal = equal && (this.CRETM == null ? that.CRETM == null : this.CRETM.equals(that.CRETM));
    equal = equal && (this.CSPEM == null ? that.CSPEM == null : this.CSPEM.equals(that.CSPEM));
    equal = equal && (this.CUMLM == null ? that.CUMLM == null : this.CUMLM.equals(that.CUMLM));
    equal = equal && (this.CVMEI == null ? that.CVMEI == null : this.CVMEI.equals(that.CVMEI));
    equal = equal && (this.CVMIN == null ? that.CVMIN == null : this.CVMIN.equals(that.CVMIN));
    equal = equal && (this.CVMLA == null ? that.CVMLA == null : this.CVMLA.equals(that.CVMLA));
    equal = equal && (this.CVMRE == null ? that.CVMRE == null : this.CVMRE.equals(that.CVMRE));
    equal = equal && (this.CVMSP == null ? that.CVMSP == null : this.CVMSP.equals(that.CVMSP));
    equal = equal && (this.CVMUM == null ? that.CVMUM == null : this.CVMUM.equals(that.CVMUM));
    equal = equal && (this.ERNAM == null ? that.ERNAM == null : this.ERNAM.equals(that.ERNAM));
    equal = equal && (this.ERSDA == null ? that.ERSDA == null : this.ERSDA.equals(that.ERSDA));
    equal = equal && (this.HERKL == null ? that.HERKL == null : this.HERKL.equals(that.HERKL));
    equal = equal && (this.KZICE == null ? that.KZICE == null : this.KZICE.equals(that.KZICE));
    equal = equal && (this.KZICL == null ? that.KZICL == null : this.KZICL.equals(that.KZICL));
    equal = equal && (this.KZICQ == null ? that.KZICQ == null : this.KZICQ.equals(that.KZICQ));
    equal = equal && (this.KZICS == null ? that.KZICS == null : this.KZICS.equals(that.KZICS));
    equal = equal && (this.KZVCE == null ? that.KZVCE == null : this.KZVCE.equals(that.KZVCE));
    equal = equal && (this.KZVCL == null ? that.KZVCL == null : this.KZVCL.equals(that.KZVCL));
    equal = equal && (this.KZVCQ == null ? that.KZVCQ == null : this.KZVCQ.equals(that.KZVCQ));
    equal = equal && (this.KZVCS == null ? that.KZVCS == null : this.KZVCS.equals(that.KZVCS));
    equal = equal && (this.LAEDA == null ? that.LAEDA == null : this.LAEDA.equals(that.LAEDA));
    equal = equal && (this.LFGJA == null ? that.LFGJA == null : this.LFGJA.equals(that.LFGJA));
    equal = equal && (this.LFMON == null ? that.LFMON == null : this.LFMON.equals(that.LFMON));
    equal = equal && (this.LGORT == null ? that.LGORT == null : this.LGORT.equals(that.LGORT));
    equal = equal && (this.LVORM == null ? that.LVORM == null : this.LVORM.equals(that.LVORM));
    equal = equal && (this.MANDT == null ? that.MANDT == null : this.MANDT.equals(that.MANDT));
    equal = equal && (this.MATNR == null ? that.MATNR == null : this.MATNR.equals(that.MATNR));
    equal = equal && (this.SEQGEN == null ? that.SEQGEN == null : this.SEQGEN.equals(that.SEQGEN));
    equal = equal && (this.SGT_SCAT == null ? that.SGT_SCAT == null : this.SGT_SCAT.equals(that.SGT_SCAT));
    equal = equal && (this.SPERC == null ? that.SPERC == null : this.SPERC.equals(that.SPERC));
    equal = equal && (this.WERKS == null ? that.WERKS == null : this.WERKS.equals(that.WERKS));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.AENAM == null ? that.AENAM == null : this.AENAM.equals(that.AENAM));
    equal = equal && (this.CEINM == null ? that.CEINM == null : this.CEINM.equals(that.CEINM));
    equal = equal && (this.CHARG == null ? that.CHARG == null : this.CHARG.equals(that.CHARG));
    equal = equal && (this.CHDLL == null ? that.CHDLL == null : this.CHDLL.equals(that.CHDLL));
    equal = equal && (this.CHJIN == null ? that.CHJIN == null : this.CHJIN.equals(that.CHJIN));
    equal = equal && (this.CHRUE == null ? that.CHRUE == null : this.CHRUE.equals(that.CHRUE));
    equal = equal && (this.CINSM == null ? that.CINSM == null : this.CINSM.equals(that.CINSM));
    equal = equal && (this.CLABS == null ? that.CLABS == null : this.CLABS.equals(that.CLABS));
    equal = equal && (this.CRETM == null ? that.CRETM == null : this.CRETM.equals(that.CRETM));
    equal = equal && (this.CSPEM == null ? that.CSPEM == null : this.CSPEM.equals(that.CSPEM));
    equal = equal && (this.CUMLM == null ? that.CUMLM == null : this.CUMLM.equals(that.CUMLM));
    equal = equal && (this.CVMEI == null ? that.CVMEI == null : this.CVMEI.equals(that.CVMEI));
    equal = equal && (this.CVMIN == null ? that.CVMIN == null : this.CVMIN.equals(that.CVMIN));
    equal = equal && (this.CVMLA == null ? that.CVMLA == null : this.CVMLA.equals(that.CVMLA));
    equal = equal && (this.CVMRE == null ? that.CVMRE == null : this.CVMRE.equals(that.CVMRE));
    equal = equal && (this.CVMSP == null ? that.CVMSP == null : this.CVMSP.equals(that.CVMSP));
    equal = equal && (this.CVMUM == null ? that.CVMUM == null : this.CVMUM.equals(that.CVMUM));
    equal = equal && (this.ERNAM == null ? that.ERNAM == null : this.ERNAM.equals(that.ERNAM));
    equal = equal && (this.ERSDA == null ? that.ERSDA == null : this.ERSDA.equals(that.ERSDA));
    equal = equal && (this.HERKL == null ? that.HERKL == null : this.HERKL.equals(that.HERKL));
    equal = equal && (this.KZICE == null ? that.KZICE == null : this.KZICE.equals(that.KZICE));
    equal = equal && (this.KZICL == null ? that.KZICL == null : this.KZICL.equals(that.KZICL));
    equal = equal && (this.KZICQ == null ? that.KZICQ == null : this.KZICQ.equals(that.KZICQ));
    equal = equal && (this.KZICS == null ? that.KZICS == null : this.KZICS.equals(that.KZICS));
    equal = equal && (this.KZVCE == null ? that.KZVCE == null : this.KZVCE.equals(that.KZVCE));
    equal = equal && (this.KZVCL == null ? that.KZVCL == null : this.KZVCL.equals(that.KZVCL));
    equal = equal && (this.KZVCQ == null ? that.KZVCQ == null : this.KZVCQ.equals(that.KZVCQ));
    equal = equal && (this.KZVCS == null ? that.KZVCS == null : this.KZVCS.equals(that.KZVCS));
    equal = equal && (this.LAEDA == null ? that.LAEDA == null : this.LAEDA.equals(that.LAEDA));
    equal = equal && (this.LFGJA == null ? that.LFGJA == null : this.LFGJA.equals(that.LFGJA));
    equal = equal && (this.LFMON == null ? that.LFMON == null : this.LFMON.equals(that.LFMON));
    equal = equal && (this.LGORT == null ? that.LGORT == null : this.LGORT.equals(that.LGORT));
    equal = equal && (this.LVORM == null ? that.LVORM == null : this.LVORM.equals(that.LVORM));
    equal = equal && (this.MANDT == null ? that.MANDT == null : this.MANDT.equals(that.MANDT));
    equal = equal && (this.MATNR == null ? that.MATNR == null : this.MATNR.equals(that.MATNR));
    equal = equal && (this.SEQGEN == null ? that.SEQGEN == null : this.SEQGEN.equals(that.SEQGEN));
    equal = equal && (this.SGT_SCAT == null ? that.SGT_SCAT == null : this.SGT_SCAT.equals(that.SGT_SCAT));
    equal = equal && (this.SPERC == null ? that.SPERC == null : this.SPERC.equals(that.SPERC));
    equal = equal && (this.WERKS == null ? that.WERKS == null : this.WERKS.equals(that.WERKS));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.AENAM = JdbcWritableBridge.readString(1, __dbResults);
    this.CEINM = JdbcWritableBridge.readBigDecimal(2, __dbResults);
    this.CHARG = JdbcWritableBridge.readString(3, __dbResults);
    this.CHDLL = JdbcWritableBridge.readString(4, __dbResults);
    this.CHJIN = JdbcWritableBridge.readString(5, __dbResults);
    this.CHRUE = JdbcWritableBridge.readString(6, __dbResults);
    this.CINSM = JdbcWritableBridge.readBigDecimal(7, __dbResults);
    this.CLABS = JdbcWritableBridge.readBigDecimal(8, __dbResults);
    this.CRETM = JdbcWritableBridge.readBigDecimal(9, __dbResults);
    this.CSPEM = JdbcWritableBridge.readBigDecimal(10, __dbResults);
    this.CUMLM = JdbcWritableBridge.readBigDecimal(11, __dbResults);
    this.CVMEI = JdbcWritableBridge.readBigDecimal(12, __dbResults);
    this.CVMIN = JdbcWritableBridge.readBigDecimal(13, __dbResults);
    this.CVMLA = JdbcWritableBridge.readBigDecimal(14, __dbResults);
    this.CVMRE = JdbcWritableBridge.readBigDecimal(15, __dbResults);
    this.CVMSP = JdbcWritableBridge.readBigDecimal(16, __dbResults);
    this.CVMUM = JdbcWritableBridge.readBigDecimal(17, __dbResults);
    this.ERNAM = JdbcWritableBridge.readString(18, __dbResults);
    this.ERSDA = JdbcWritableBridge.readString(19, __dbResults);
    this.HERKL = JdbcWritableBridge.readString(20, __dbResults);
    this.KZICE = JdbcWritableBridge.readString(21, __dbResults);
    this.KZICL = JdbcWritableBridge.readString(22, __dbResults);
    this.KZICQ = JdbcWritableBridge.readString(23, __dbResults);
    this.KZICS = JdbcWritableBridge.readString(24, __dbResults);
    this.KZVCE = JdbcWritableBridge.readString(25, __dbResults);
    this.KZVCL = JdbcWritableBridge.readString(26, __dbResults);
    this.KZVCQ = JdbcWritableBridge.readString(27, __dbResults);
    this.KZVCS = JdbcWritableBridge.readString(28, __dbResults);
    this.LAEDA = JdbcWritableBridge.readString(29, __dbResults);
    this.LFGJA = JdbcWritableBridge.readString(30, __dbResults);
    this.LFMON = JdbcWritableBridge.readString(31, __dbResults);
    this.LGORT = JdbcWritableBridge.readString(32, __dbResults);
    this.LVORM = JdbcWritableBridge.readString(33, __dbResults);
    this.MANDT = JdbcWritableBridge.readString(34, __dbResults);
    this.MATNR = JdbcWritableBridge.readString(35, __dbResults);
    this.SEQGEN = JdbcWritableBridge.readLong(36, __dbResults);
    this.SGT_SCAT = JdbcWritableBridge.readString(37, __dbResults);
    this.SPERC = JdbcWritableBridge.readString(38, __dbResults);
    this.WERKS = JdbcWritableBridge.readString(39, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.AENAM = JdbcWritableBridge.readString(1, __dbResults);
    this.CEINM = JdbcWritableBridge.readBigDecimal(2, __dbResults);
    this.CHARG = JdbcWritableBridge.readString(3, __dbResults);
    this.CHDLL = JdbcWritableBridge.readString(4, __dbResults);
    this.CHJIN = JdbcWritableBridge.readString(5, __dbResults);
    this.CHRUE = JdbcWritableBridge.readString(6, __dbResults);
    this.CINSM = JdbcWritableBridge.readBigDecimal(7, __dbResults);
    this.CLABS = JdbcWritableBridge.readBigDecimal(8, __dbResults);
    this.CRETM = JdbcWritableBridge.readBigDecimal(9, __dbResults);
    this.CSPEM = JdbcWritableBridge.readBigDecimal(10, __dbResults);
    this.CUMLM = JdbcWritableBridge.readBigDecimal(11, __dbResults);
    this.CVMEI = JdbcWritableBridge.readBigDecimal(12, __dbResults);
    this.CVMIN = JdbcWritableBridge.readBigDecimal(13, __dbResults);
    this.CVMLA = JdbcWritableBridge.readBigDecimal(14, __dbResults);
    this.CVMRE = JdbcWritableBridge.readBigDecimal(15, __dbResults);
    this.CVMSP = JdbcWritableBridge.readBigDecimal(16, __dbResults);
    this.CVMUM = JdbcWritableBridge.readBigDecimal(17, __dbResults);
    this.ERNAM = JdbcWritableBridge.readString(18, __dbResults);
    this.ERSDA = JdbcWritableBridge.readString(19, __dbResults);
    this.HERKL = JdbcWritableBridge.readString(20, __dbResults);
    this.KZICE = JdbcWritableBridge.readString(21, __dbResults);
    this.KZICL = JdbcWritableBridge.readString(22, __dbResults);
    this.KZICQ = JdbcWritableBridge.readString(23, __dbResults);
    this.KZICS = JdbcWritableBridge.readString(24, __dbResults);
    this.KZVCE = JdbcWritableBridge.readString(25, __dbResults);
    this.KZVCL = JdbcWritableBridge.readString(26, __dbResults);
    this.KZVCQ = JdbcWritableBridge.readString(27, __dbResults);
    this.KZVCS = JdbcWritableBridge.readString(28, __dbResults);
    this.LAEDA = JdbcWritableBridge.readString(29, __dbResults);
    this.LFGJA = JdbcWritableBridge.readString(30, __dbResults);
    this.LFMON = JdbcWritableBridge.readString(31, __dbResults);
    this.LGORT = JdbcWritableBridge.readString(32, __dbResults);
    this.LVORM = JdbcWritableBridge.readString(33, __dbResults);
    this.MANDT = JdbcWritableBridge.readString(34, __dbResults);
    this.MATNR = JdbcWritableBridge.readString(35, __dbResults);
    this.SEQGEN = JdbcWritableBridge.readLong(36, __dbResults);
    this.SGT_SCAT = JdbcWritableBridge.readString(37, __dbResults);
    this.SPERC = JdbcWritableBridge.readString(38, __dbResults);
    this.WERKS = JdbcWritableBridge.readString(39, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(AENAM, 1 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CEINM, 2 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeString(CHARG, 3 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(CHDLL, 4 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(CHJIN, 5 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(CHRUE, 6 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CINSM, 7 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CLABS, 8 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CRETM, 9 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSPEM, 10 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CUMLM, 11 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CVMEI, 12 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CVMIN, 13 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CVMLA, 14 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CVMRE, 15 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CVMSP, 16 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CVMUM, 17 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeString(ERNAM, 18 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(ERSDA, 19 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(HERKL, 20 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZICE, 21 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZICL, 22 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZICQ, 23 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZICS, 24 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZVCE, 25 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZVCL, 26 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZVCQ, 27 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZVCS, 28 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(LAEDA, 29 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(LFGJA, 30 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(LFMON, 31 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(LGORT, 32 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(LVORM, 33 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(MANDT, 34 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(MATNR, 35 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeLong(SEQGEN, 36 + __off, -5, __dbStmt);
    JdbcWritableBridge.writeString(SGT_SCAT, 37 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(SPERC, 38 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(WERKS, 39 + __off, -9, __dbStmt);
    return 39;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(AENAM, 1 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CEINM, 2 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeString(CHARG, 3 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(CHDLL, 4 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(CHJIN, 5 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(CHRUE, 6 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CINSM, 7 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CLABS, 8 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CRETM, 9 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSPEM, 10 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CUMLM, 11 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CVMEI, 12 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CVMIN, 13 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CVMLA, 14 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CVMRE, 15 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CVMSP, 16 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CVMUM, 17 + __off, 3, __dbStmt);
    JdbcWritableBridge.writeString(ERNAM, 18 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(ERSDA, 19 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(HERKL, 20 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZICE, 21 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZICL, 22 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZICQ, 23 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZICS, 24 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZVCE, 25 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZVCL, 26 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZVCQ, 27 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(KZVCS, 28 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(LAEDA, 29 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(LFGJA, 30 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(LFMON, 31 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(LGORT, 32 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(LVORM, 33 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(MANDT, 34 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(MATNR, 35 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeLong(SEQGEN, 36 + __off, -5, __dbStmt);
    JdbcWritableBridge.writeString(SGT_SCAT, 37 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(SPERC, 38 + __off, -9, __dbStmt);
    JdbcWritableBridge.writeString(WERKS, 39 + __off, -9, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.AENAM = null;
    } else {
    this.AENAM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CEINM = null;
    } else {
    this.CEINM = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CHARG = null;
    } else {
    this.CHARG = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CHDLL = null;
    } else {
    this.CHDLL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CHJIN = null;
    } else {
    this.CHJIN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CHRUE = null;
    } else {
    this.CHRUE = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CINSM = null;
    } else {
    this.CINSM = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLABS = null;
    } else {
    this.CLABS = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CRETM = null;
    } else {
    this.CRETM = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CSPEM = null;
    } else {
    this.CSPEM = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CUMLM = null;
    } else {
    this.CUMLM = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CVMEI = null;
    } else {
    this.CVMEI = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CVMIN = null;
    } else {
    this.CVMIN = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CVMLA = null;
    } else {
    this.CVMLA = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CVMRE = null;
    } else {
    this.CVMRE = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CVMSP = null;
    } else {
    this.CVMSP = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CVMUM = null;
    } else {
    this.CVMUM = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ERNAM = null;
    } else {
    this.ERNAM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ERSDA = null;
    } else {
    this.ERSDA = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HERKL = null;
    } else {
    this.HERKL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KZICE = null;
    } else {
    this.KZICE = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KZICL = null;
    } else {
    this.KZICL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KZICQ = null;
    } else {
    this.KZICQ = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KZICS = null;
    } else {
    this.KZICS = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KZVCE = null;
    } else {
    this.KZVCE = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KZVCL = null;
    } else {
    this.KZVCL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KZVCQ = null;
    } else {
    this.KZVCQ = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KZVCS = null;
    } else {
    this.KZVCS = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LAEDA = null;
    } else {
    this.LAEDA = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LFGJA = null;
    } else {
    this.LFGJA = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LFMON = null;
    } else {
    this.LFMON = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LGORT = null;
    } else {
    this.LGORT = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LVORM = null;
    } else {
    this.LVORM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MANDT = null;
    } else {
    this.MANDT = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MATNR = null;
    } else {
    this.MATNR = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SEQGEN = null;
    } else {
    this.SEQGEN = Long.valueOf(__dataIn.readLong());
    }
    if (__dataIn.readBoolean()) { 
        this.SGT_SCAT = null;
    } else {
    this.SGT_SCAT = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SPERC = null;
    } else {
    this.SPERC = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.WERKS = null;
    } else {
    this.WERKS = Text.readString(__dataIn);
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.AENAM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AENAM);
    }
    if (null == this.CEINM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CEINM, __dataOut);
    }
    if (null == this.CHARG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHARG);
    }
    if (null == this.CHDLL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHDLL);
    }
    if (null == this.CHJIN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHJIN);
    }
    if (null == this.CHRUE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHRUE);
    }
    if (null == this.CINSM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CINSM, __dataOut);
    }
    if (null == this.CLABS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CLABS, __dataOut);
    }
    if (null == this.CRETM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CRETM, __dataOut);
    }
    if (null == this.CSPEM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CSPEM, __dataOut);
    }
    if (null == this.CUMLM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CUMLM, __dataOut);
    }
    if (null == this.CVMEI) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CVMEI, __dataOut);
    }
    if (null == this.CVMIN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CVMIN, __dataOut);
    }
    if (null == this.CVMLA) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CVMLA, __dataOut);
    }
    if (null == this.CVMRE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CVMRE, __dataOut);
    }
    if (null == this.CVMSP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CVMSP, __dataOut);
    }
    if (null == this.CVMUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CVMUM, __dataOut);
    }
    if (null == this.ERNAM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ERNAM);
    }
    if (null == this.ERSDA) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ERSDA);
    }
    if (null == this.HERKL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HERKL);
    }
    if (null == this.KZICE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZICE);
    }
    if (null == this.KZICL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZICL);
    }
    if (null == this.KZICQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZICQ);
    }
    if (null == this.KZICS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZICS);
    }
    if (null == this.KZVCE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZVCE);
    }
    if (null == this.KZVCL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZVCL);
    }
    if (null == this.KZVCQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZVCQ);
    }
    if (null == this.KZVCS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZVCS);
    }
    if (null == this.LAEDA) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LAEDA);
    }
    if (null == this.LFGJA) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LFGJA);
    }
    if (null == this.LFMON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LFMON);
    }
    if (null == this.LGORT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LGORT);
    }
    if (null == this.LVORM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LVORM);
    }
    if (null == this.MANDT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MANDT);
    }
    if (null == this.MATNR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MATNR);
    }
    if (null == this.SEQGEN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SEQGEN);
    }
    if (null == this.SGT_SCAT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SGT_SCAT);
    }
    if (null == this.SPERC) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SPERC);
    }
    if (null == this.WERKS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, WERKS);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.AENAM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AENAM);
    }
    if (null == this.CEINM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CEINM, __dataOut);
    }
    if (null == this.CHARG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHARG);
    }
    if (null == this.CHDLL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHDLL);
    }
    if (null == this.CHJIN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHJIN);
    }
    if (null == this.CHRUE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHRUE);
    }
    if (null == this.CINSM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CINSM, __dataOut);
    }
    if (null == this.CLABS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CLABS, __dataOut);
    }
    if (null == this.CRETM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CRETM, __dataOut);
    }
    if (null == this.CSPEM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CSPEM, __dataOut);
    }
    if (null == this.CUMLM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CUMLM, __dataOut);
    }
    if (null == this.CVMEI) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CVMEI, __dataOut);
    }
    if (null == this.CVMIN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CVMIN, __dataOut);
    }
    if (null == this.CVMLA) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CVMLA, __dataOut);
    }
    if (null == this.CVMRE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CVMRE, __dataOut);
    }
    if (null == this.CVMSP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CVMSP, __dataOut);
    }
    if (null == this.CVMUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.CVMUM, __dataOut);
    }
    if (null == this.ERNAM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ERNAM);
    }
    if (null == this.ERSDA) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ERSDA);
    }
    if (null == this.HERKL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HERKL);
    }
    if (null == this.KZICE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZICE);
    }
    if (null == this.KZICL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZICL);
    }
    if (null == this.KZICQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZICQ);
    }
    if (null == this.KZICS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZICS);
    }
    if (null == this.KZVCE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZVCE);
    }
    if (null == this.KZVCL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZVCL);
    }
    if (null == this.KZVCQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZVCQ);
    }
    if (null == this.KZVCS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KZVCS);
    }
    if (null == this.LAEDA) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LAEDA);
    }
    if (null == this.LFGJA) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LFGJA);
    }
    if (null == this.LFMON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LFMON);
    }
    if (null == this.LGORT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LGORT);
    }
    if (null == this.LVORM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LVORM);
    }
    if (null == this.MANDT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MANDT);
    }
    if (null == this.MATNR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MATNR);
    }
    if (null == this.SEQGEN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SEQGEN);
    }
    if (null == this.SGT_SCAT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SGT_SCAT);
    }
    if (null == this.SPERC) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SPERC);
    }
    if (null == this.WERKS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, WERKS);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(AENAM==null?"\\N":AENAM, " ", delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CEINM==null?"\\N":CEINM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(CHARG==null?"\\N":CHARG, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(CHDLL==null?"\\N":CHDLL, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(CHJIN==null?"\\N":CHJIN, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(CHRUE==null?"\\N":CHRUE, " ", delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CINSM==null?"\\N":CINSM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLABS==null?"\\N":CLABS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CRETM==null?"\\N":CRETM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSPEM==null?"\\N":CSPEM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUMLM==null?"\\N":CUMLM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CVMEI==null?"\\N":CVMEI.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CVMIN==null?"\\N":CVMIN.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CVMLA==null?"\\N":CVMLA.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CVMRE==null?"\\N":CVMRE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CVMSP==null?"\\N":CVMSP.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CVMUM==null?"\\N":CVMUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(ERNAM==null?"\\N":ERNAM, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(ERSDA==null?"\\N":ERSDA, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(HERKL==null?"\\N":HERKL, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZICE==null?"\\N":KZICE, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZICL==null?"\\N":KZICL, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZICQ==null?"\\N":KZICQ, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZICS==null?"\\N":KZICS, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZVCE==null?"\\N":KZVCE, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZVCL==null?"\\N":KZVCL, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZVCQ==null?"\\N":KZVCQ, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZVCS==null?"\\N":KZVCS, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(LAEDA==null?"\\N":LAEDA, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(LFGJA==null?"\\N":LFGJA, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(LFMON==null?"\\N":LFMON, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(LGORT==null?"\\N":LGORT, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(LVORM==null?"\\N":LVORM, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(MANDT==null?"\\N":MANDT, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(MATNR==null?"\\N":MATNR, " ", delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SEQGEN==null?"\\N":"" + SEQGEN, delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(SGT_SCAT==null?"\\N":SGT_SCAT, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(SPERC==null?"\\N":SPERC, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(WERKS==null?"\\N":WERKS, " ", delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(AENAM==null?"\\N":AENAM, " ", delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CEINM==null?"\\N":CEINM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(CHARG==null?"\\N":CHARG, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(CHDLL==null?"\\N":CHDLL, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(CHJIN==null?"\\N":CHJIN, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(CHRUE==null?"\\N":CHRUE, " ", delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CINSM==null?"\\N":CINSM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLABS==null?"\\N":CLABS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CRETM==null?"\\N":CRETM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSPEM==null?"\\N":CSPEM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUMLM==null?"\\N":CUMLM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CVMEI==null?"\\N":CVMEI.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CVMIN==null?"\\N":CVMIN.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CVMLA==null?"\\N":CVMLA.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CVMRE==null?"\\N":CVMRE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CVMSP==null?"\\N":CVMSP.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CVMUM==null?"\\N":CVMUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(ERNAM==null?"\\N":ERNAM, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(ERSDA==null?"\\N":ERSDA, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(HERKL==null?"\\N":HERKL, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZICE==null?"\\N":KZICE, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZICL==null?"\\N":KZICL, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZICQ==null?"\\N":KZICQ, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZICS==null?"\\N":KZICS, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZVCE==null?"\\N":KZVCE, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZVCL==null?"\\N":KZVCL, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZVCQ==null?"\\N":KZVCQ, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(KZVCS==null?"\\N":KZVCS, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(LAEDA==null?"\\N":LAEDA, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(LFGJA==null?"\\N":LFGJA, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(LFMON==null?"\\N":LFMON, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(LGORT==null?"\\N":LGORT, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(LVORM==null?"\\N":LVORM, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(MANDT==null?"\\N":MANDT, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(MATNR==null?"\\N":MATNR, " ", delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SEQGEN==null?"\\N":"" + SEQGEN, delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(SGT_SCAT==null?"\\N":SGT_SCAT, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(SPERC==null?"\\N":SPERC, " ", delimiters));
    __sb.append(fieldDelim);
    // special case for strings hive, replacing delimiters \n,\r,\01 with ' ' from strings
    __sb.append(FieldFormatter.hiveStringReplaceDelims(WERKS==null?"\\N":WERKS, " ", delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.AENAM = null; } else {
      this.AENAM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CEINM = null; } else {
      this.CEINM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CHARG = null; } else {
      this.CHARG = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CHDLL = null; } else {
      this.CHDLL = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CHJIN = null; } else {
      this.CHJIN = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CHRUE = null; } else {
      this.CHRUE = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CINSM = null; } else {
      this.CINSM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CLABS = null; } else {
      this.CLABS = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CRETM = null; } else {
      this.CRETM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSPEM = null; } else {
      this.CSPEM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CUMLM = null; } else {
      this.CUMLM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CVMEI = null; } else {
      this.CVMEI = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CVMIN = null; } else {
      this.CVMIN = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CVMLA = null; } else {
      this.CVMLA = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CVMRE = null; } else {
      this.CVMRE = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CVMSP = null; } else {
      this.CVMSP = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CVMUM = null; } else {
      this.CVMUM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ERNAM = null; } else {
      this.ERNAM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ERSDA = null; } else {
      this.ERSDA = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.HERKL = null; } else {
      this.HERKL = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZICE = null; } else {
      this.KZICE = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZICL = null; } else {
      this.KZICL = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZICQ = null; } else {
      this.KZICQ = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZICS = null; } else {
      this.KZICS = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZVCE = null; } else {
      this.KZVCE = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZVCL = null; } else {
      this.KZVCL = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZVCQ = null; } else {
      this.KZVCQ = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZVCS = null; } else {
      this.KZVCS = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LAEDA = null; } else {
      this.LAEDA = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LFGJA = null; } else {
      this.LFGJA = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LFMON = null; } else {
      this.LFMON = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LGORT = null; } else {
      this.LGORT = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LVORM = null; } else {
      this.LVORM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.MANDT = null; } else {
      this.MANDT = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.MATNR = null; } else {
      this.MATNR = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SEQGEN = null; } else {
      this.SEQGEN = Long.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.SGT_SCAT = null; } else {
      this.SGT_SCAT = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.SPERC = null; } else {
      this.SPERC = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.WERKS = null; } else {
      this.WERKS = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.AENAM = null; } else {
      this.AENAM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CEINM = null; } else {
      this.CEINM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CHARG = null; } else {
      this.CHARG = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CHDLL = null; } else {
      this.CHDLL = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CHJIN = null; } else {
      this.CHJIN = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CHRUE = null; } else {
      this.CHRUE = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CINSM = null; } else {
      this.CINSM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CLABS = null; } else {
      this.CLABS = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CRETM = null; } else {
      this.CRETM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSPEM = null; } else {
      this.CSPEM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CUMLM = null; } else {
      this.CUMLM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CVMEI = null; } else {
      this.CVMEI = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CVMIN = null; } else {
      this.CVMIN = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CVMLA = null; } else {
      this.CVMLA = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CVMRE = null; } else {
      this.CVMRE = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CVMSP = null; } else {
      this.CVMSP = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CVMUM = null; } else {
      this.CVMUM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ERNAM = null; } else {
      this.ERNAM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ERSDA = null; } else {
      this.ERSDA = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.HERKL = null; } else {
      this.HERKL = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZICE = null; } else {
      this.KZICE = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZICL = null; } else {
      this.KZICL = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZICQ = null; } else {
      this.KZICQ = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZICS = null; } else {
      this.KZICS = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZVCE = null; } else {
      this.KZVCE = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZVCL = null; } else {
      this.KZVCL = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZVCQ = null; } else {
      this.KZVCQ = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KZVCS = null; } else {
      this.KZVCS = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LAEDA = null; } else {
      this.LAEDA = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LFGJA = null; } else {
      this.LFGJA = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LFMON = null; } else {
      this.LFMON = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LGORT = null; } else {
      this.LGORT = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.LVORM = null; } else {
      this.LVORM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.MANDT = null; } else {
      this.MANDT = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.MATNR = null; } else {
      this.MATNR = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SEQGEN = null; } else {
      this.SEQGEN = Long.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.SGT_SCAT = null; } else {
      this.SGT_SCAT = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.SPERC = null; } else {
      this.SPERC = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.WERKS = null; } else {
      this.WERKS = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    QueryResult o = (QueryResult) super.clone();
    return o;
  }

  public void clone0(QueryResult o) throws CloneNotSupportedException {
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("AENAM", this.AENAM);
    __sqoop$field_map.put("CEINM", this.CEINM);
    __sqoop$field_map.put("CHARG", this.CHARG);
    __sqoop$field_map.put("CHDLL", this.CHDLL);
    __sqoop$field_map.put("CHJIN", this.CHJIN);
    __sqoop$field_map.put("CHRUE", this.CHRUE);
    __sqoop$field_map.put("CINSM", this.CINSM);
    __sqoop$field_map.put("CLABS", this.CLABS);
    __sqoop$field_map.put("CRETM", this.CRETM);
    __sqoop$field_map.put("CSPEM", this.CSPEM);
    __sqoop$field_map.put("CUMLM", this.CUMLM);
    __sqoop$field_map.put("CVMEI", this.CVMEI);
    __sqoop$field_map.put("CVMIN", this.CVMIN);
    __sqoop$field_map.put("CVMLA", this.CVMLA);
    __sqoop$field_map.put("CVMRE", this.CVMRE);
    __sqoop$field_map.put("CVMSP", this.CVMSP);
    __sqoop$field_map.put("CVMUM", this.CVMUM);
    __sqoop$field_map.put("ERNAM", this.ERNAM);
    __sqoop$field_map.put("ERSDA", this.ERSDA);
    __sqoop$field_map.put("HERKL", this.HERKL);
    __sqoop$field_map.put("KZICE", this.KZICE);
    __sqoop$field_map.put("KZICL", this.KZICL);
    __sqoop$field_map.put("KZICQ", this.KZICQ);
    __sqoop$field_map.put("KZICS", this.KZICS);
    __sqoop$field_map.put("KZVCE", this.KZVCE);
    __sqoop$field_map.put("KZVCL", this.KZVCL);
    __sqoop$field_map.put("KZVCQ", this.KZVCQ);
    __sqoop$field_map.put("KZVCS", this.KZVCS);
    __sqoop$field_map.put("LAEDA", this.LAEDA);
    __sqoop$field_map.put("LFGJA", this.LFGJA);
    __sqoop$field_map.put("LFMON", this.LFMON);
    __sqoop$field_map.put("LGORT", this.LGORT);
    __sqoop$field_map.put("LVORM", this.LVORM);
    __sqoop$field_map.put("MANDT", this.MANDT);
    __sqoop$field_map.put("MATNR", this.MATNR);
    __sqoop$field_map.put("SEQGEN", this.SEQGEN);
    __sqoop$field_map.put("SGT_SCAT", this.SGT_SCAT);
    __sqoop$field_map.put("SPERC", this.SPERC);
    __sqoop$field_map.put("WERKS", this.WERKS);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("AENAM", this.AENAM);
    __sqoop$field_map.put("CEINM", this.CEINM);
    __sqoop$field_map.put("CHARG", this.CHARG);
    __sqoop$field_map.put("CHDLL", this.CHDLL);
    __sqoop$field_map.put("CHJIN", this.CHJIN);
    __sqoop$field_map.put("CHRUE", this.CHRUE);
    __sqoop$field_map.put("CINSM", this.CINSM);
    __sqoop$field_map.put("CLABS", this.CLABS);
    __sqoop$field_map.put("CRETM", this.CRETM);
    __sqoop$field_map.put("CSPEM", this.CSPEM);
    __sqoop$field_map.put("CUMLM", this.CUMLM);
    __sqoop$field_map.put("CVMEI", this.CVMEI);
    __sqoop$field_map.put("CVMIN", this.CVMIN);
    __sqoop$field_map.put("CVMLA", this.CVMLA);
    __sqoop$field_map.put("CVMRE", this.CVMRE);
    __sqoop$field_map.put("CVMSP", this.CVMSP);
    __sqoop$field_map.put("CVMUM", this.CVMUM);
    __sqoop$field_map.put("ERNAM", this.ERNAM);
    __sqoop$field_map.put("ERSDA", this.ERSDA);
    __sqoop$field_map.put("HERKL", this.HERKL);
    __sqoop$field_map.put("KZICE", this.KZICE);
    __sqoop$field_map.put("KZICL", this.KZICL);
    __sqoop$field_map.put("KZICQ", this.KZICQ);
    __sqoop$field_map.put("KZICS", this.KZICS);
    __sqoop$field_map.put("KZVCE", this.KZVCE);
    __sqoop$field_map.put("KZVCL", this.KZVCL);
    __sqoop$field_map.put("KZVCQ", this.KZVCQ);
    __sqoop$field_map.put("KZVCS", this.KZVCS);
    __sqoop$field_map.put("LAEDA", this.LAEDA);
    __sqoop$field_map.put("LFGJA", this.LFGJA);
    __sqoop$field_map.put("LFMON", this.LFMON);
    __sqoop$field_map.put("LGORT", this.LGORT);
    __sqoop$field_map.put("LVORM", this.LVORM);
    __sqoop$field_map.put("MANDT", this.MANDT);
    __sqoop$field_map.put("MATNR", this.MATNR);
    __sqoop$field_map.put("SEQGEN", this.SEQGEN);
    __sqoop$field_map.put("SGT_SCAT", this.SGT_SCAT);
    __sqoop$field_map.put("SPERC", this.SPERC);
    __sqoop$field_map.put("WERKS", this.WERKS);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}
