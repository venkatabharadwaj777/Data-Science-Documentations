#!/bin/bash
# common.sh
#
# Copyright (C) 2019 Jabil Inc.
#
# This script sets up execution of other installation shell scripts.
#
# Edit env_parameters.sh to set the values for:
# USECASE = use-case name
# MANAGER = the manager portion of the service account name
# DB_TYPE = Valid Database Types: 'tenants/', 'use_cases/'. 'semantic/', 'data_science/' or <blank>
# SUPPORT_SUFFIX = "rw" if the support group suffix is "rw" instead of "sppt"
# 
# The -m parameter allows override of the manager attribute if there are multiple manager accounts.
# For example, there may be a manager service account for processing data and another for ingestion.

# Get the directory we're executing from
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" 
  # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"

function dts { date --rfc-3339=ns; }
# dts -- example usage:
#   dts
#   echo "$(dts)"
# example output: 2015-10-10 19:09:59.804928435+00:00

function errmsg { echo "$(dts)${1:+, $@:} an error occurred"; }
# errmsg -- example usage:
#   false || { errmsg; exit 1; }
#   false || { errmsg "your error" message here; exit 1; }

DISPLAYHELP=""
export SUPPORT_SUFFIX=sppt

# Read the environment perameters
#source "${DIR}/env_parameters.sh"

# Allow environment variable overrides
while getopts "h?m:t:u:12r" opt; do
  case "$opt" in
    # Help
    h|\?) DISPLAYHELP="X"
      ;;
    # Get the Manager
    m) export MANAGER=$OPTARG
      ;;
    # Get the Database Type
    t) export DB_TYPE=$OPTARG/
      echo "-t :${DB_TYPE}"
      ;;
    # Get the Use Case
    u) export USECASE=$OPTARG
      ;;
    # Get the Encryption Types
    1) export USE_AES128="X"
      ;;
    2) export USE_AES256="X"
      ;;
    r) export USE_RC4_HMAC="X"
      ;;
   esac
done  

# Set the environment variables.
if [[ ${MANAGER} == '' ]]; then
    export MANAGER=${USECASE}
fi

# Limit database type values.
if [[ ${DISPLAYHELP} == "" ]]; then
  # Turn on DISPLAYHELP initially, and turn it back off if the DB_TYPE is a valid value
  DISPLAYHELP="X"
  case "${DB_TYPE}" in
    "")
      DISPLAYHELP=""
      ;;
    "data_science/")
      DISPLAYHELP=""
      ;;
    "semantic/")
      DISPLAYHELP=""
      ;;
    "tenants/")
      DISPLAYHELP=""
      ;;
    "use_cases/")
      DISPLAYHELP=""
      ;;
    *) echo "Valid Database Types: 'tenants/', 'use_cases/'. 'semantic/', 'data_science/' or <blank>"
      DISPLAYHELP="X"
      ;;
  esac
fi

# Get the hostname to determine the CLUSTER
case "${HOSTNAME:9:1}" in
  "d")
    # DEV only
    export CLUSTER=dev
    export CLUSTER_CODE=d
    ;;
  "q")
    # STG only
    export CLUSTER=stg
    export CLUSTER_CODE=s
    ;;
  "p")
    # PRD only
    export CLUSTER=prd
    export CLUSTER_CODE=c
    ;;
  *) # not good
    errmsg "\$HOSTNAME='${HOSTNAME}' unexpected server hostname"
    exit 1
esac


# Implement IT Security Policy 00-IT60-SEC-004 – 6.3.4: 
#    The same service account should not be used in multiple runtime environments 
#    (Development, Staging, Production, etc)
export ACCOUNT=svccor_hdp_${CLUSTER}
export ADMIN=svccor_hdp${CLUSTER}adm

# Set up groups
#export ADM_GROUP=hadoop${CLUSTER}_${USECASE}adm
#export READ_GROUP=hadoop${CLUSTER}_${USECASE}read
#export SUPPORT_GROUP=hadoop${CLUSTER}_${USECASE}${SUPPORT_SUFFIX}
#export CLUSTER_ADMINS=hadoopalph${CLUSTER}hdfssuper

