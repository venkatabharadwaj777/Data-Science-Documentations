#!/bin/bash

if [[ "$1" == "T" ]]; then
	if [[ $# -ne 6 ]]; then
  		echo "Arguments missing"
  		exit 1
	fi
	delimiter=\\t
	source_name=${2}
	table_name=${3}
	region=${4}
	filedate=${5}
	source_status=${6}
	handshake_file_path=/data/spend_analytics/handshake/tablelevel
	handshake_file_name=handshake_spend_analytics_table_load_status.dat
	log_path=/eip_interfaces/logs

	if hadoop fs -test -f ${handshake_file_path}/${handshake_file_name}
	then
	 echo "" | hadoop fs -put - ${handshake_file_path}/${handshake_file_name}
	fi

	echo -e ${source_name}${delimiter}${table_name}${delimiter}${region}${delimiter}${filedate}${delimiter}${source_status}${delimiter}`date +"%Y-%m-%d %H:%M:%S"` | hadoop fs -appendToFile - ${handshake_file_path}/${handshake_file_name}
 
else 

	if [ $# -ne 5 ]; then
  		echo "Arguments missing"
  		exit 1
	fi
	delimiter=\\t
	source_name=${2}
	region=${3}
	filedate=${4}
	source_status=${5}
	handshake_file_path=/data/spend_analytics/handshake/instancelevel
	handshake_file_name=handshake_instance_load_status.dat
	log_path=/eip_interfaces/logs

	if hadoop fs -test -f ${handshake_file_path}/${handshake_file_name}
	then
  		echo "" | hadoop fs -put - ${handshake_file_path}/${handshake_file_name}
	fi

	echo -e ${source_name}${delimiter}${region}${delimiter}${filedate}${delimiter}${source_status}${delimiter}`date +"%Y-%m-%d %H:%M:%S"` | hadoop fs -appendToFile - ${handshake_file_path}/${handshake_file_name}
fi
