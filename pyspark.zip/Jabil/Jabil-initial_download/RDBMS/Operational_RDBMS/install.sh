#!/bin/bash
# RDBMS/Operational_RDBMS/install.sh
#
# Copyright (C) 2019 Jabil Inc.
#
# This script sets up execution of the program.  It must be executed
# by the service account
#
if [[ ${USER} == 'root' ]]; then
  echo "This program must be executed by the service account."
fi

# Get the directory we're executing from
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"

# Run the common code across all install files.
. "${DIR}/common.sh"

# Diplay the internal parameters.
echo "Use Case:        ${USECASE}"
echo "Cluster:         ${CLUSTER}"
echo "Account:         ${ACCOUNT}"
echo "Administrator:   ${ADMIN}"
echo "Admins:          ${ADM_GROUP}"
echo "Read-Only:       ${READ_GROUP}"
echo "Support:         ${SUPPORT_GROUP}"
echo "DB Type:         ${DB_TYPE}"

if [[ ${DISPLAYHELP} == "X" ]]; then
  # Establish a Kerberos ticket.
  kinit "${ADMIN}@CORP.JABIL.ORG" -k -t "/eip_interfaces/${ACCOUNT}/.misc/${ACCOUNT}.keytab" -V

  echo "This install.sh program must be executed by the DIF service accont."
  exit 0
fi

# Turn on echo
set -x

if [[ ${DISPLAYHELP} == "" ]]; then
  # Copy the config files from the safe source directory
  cp /eip_interfaces/${ACCOUNT}/DIF/RDBMS/Operational_RDBMS/*.conf ${DIR}
  cp /eip_interfaces/${ACCOUNT}/DIF/RDBMS/HiveQL_Generator_RDBMS/*.conf ${DIR}/../HiveQL_Generator_RDBMS/
fi

# Turn off echo
set +x

