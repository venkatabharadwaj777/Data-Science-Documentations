#!/bin/bash

##Wrapper script to call the Stored Procedures to fetch DB and table details.
##And to call the other shell scripts to initiate Sqoop and HQL process for historical or delta load.

##Arguments

	logical_name=$1
	config_file=$2

##Source the path configuration file to read and call all the variables from config.txt into this script.
	source $config_file
	logged_user=`whoami`


##Calculate current date
	rundate=`date "+%Y-%m-%d"`
	run_timestamp=`date +"%Y-%m-%d:%H:%M:%S"`

##Call Stored Procedure to fetch Database details.
	Instance=$(mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"call $SP_Database('$logical_name')")

	db_arr=(${Instance// / })
	source_name=$(mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"select distinct source from source_table_details where database_name='${db_arr[4]}';")
	dbname=`echo ${db_arr[4]}`
## Added variable to handle (.) value in instance name.

	temp_server_name=`echo "${db_arr[1]}"|cut -d '.' -f1`

##Process validation ${logical_name}

	if [ ! -d "$process_log/${source_name}/$rundate/${logical_name}" ];
	then
		mkdir -p $process_log/${source_name}/$rundate/${logical_name}
	fi

##Check log availablilty
	if [ -f "$process_log/${source_name}/$rundate/${logical_name}/${logical_name}_instance.log" ]
	then
		mv $process_log/${source_name}/$rundate/${logical_name}/${logical_name}_instance.log $process_log/${source_name}/$rundate/${logical_name}/${logical_name}_instance_$run_timestamp.log
	else
                 echo ""
        fi

# Function to log messages with timestamp to defined log file
	function log() {
			log_time=`date "+%m-%d-%Y:%H:%M:%S"`
			echo -e "${log_time} $*" >> $process_log/${source_name}/$rundate/${logical_name}/${logical_name}\_instance.log
			}

	log_func="function log() {\n
					log_time=\`date \"+%m-%d-%Y:%H:%M:%S\"\`\n
					echo -e \"\${log_time} \$*\" >> $process_log/${source_name}/$rundate/${logical_name}/${logical_name}\_instance.log\n
					}"
echo "${db_arr[0]}, ${db_arr[3]}, ${db_arr[4]}, ${db_arr[7]}, ${db_arr[8]}"
##Check and exit if any of the column values in source_db_details is Null.
	if [ "${db_arr[6]}" == "sap" ]
	then

		if [ "${db_arr[0]}" == "NULL" ] || [ "${db_arr[3]}" == "NULL" ] || [ "${db_arr[4]}" == "NULL" ] || [ "${db_arr[7]}" == "NULL" ] || [ "${db_arr[8]}" == "NULL" ] 
			then
				log "Error: one of the SAP DB values is missing"
			exit 1
		fi
elif [ "${db_arr[0]}" == "NULL" ] || [ "${db_arr[1]}" == "NULL" ] || [ "${db_arr[3]}" == "NULL" ] || [ "${db_arr[4]}" == "NULL" ] || [ "${db_arr[5]}" == "NULL" ] || [ "${db_arr[6]}" == "NULL" ] || [ "${db_arr[7]}" == "NULL" ] || [ "${db_arr[8]}" == "NULL" ]
        then
                log "Error: one of the DB values is missing"
                exit 1
fi

##Instance Restartability
	if [ -f $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_SUCCESS ]; then
		log "INSTANCE-INFO: Process for instance ${db_arr[2]} is already completed" 
		log "INSTANCE-INFO: skipping run for instance: "${db_arr[2]}""
		exit 1
	fi
	if [ -f $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_FAIL ]; then
		log "INSTANCE-WARNING: As this is re-run for failed script for instance: "${db_arr[2]}" , changing status to Running"
		rm $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_FAIL
		log "Status for Instance is changed to running"
		touch $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_RUNNING
		log "INSTANCE-INFO: This is re-run, setting up the skipping flags"
	elif [ -f $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_RUNNING ]; then
		log "INSTANCE-WARNING: As script is running for instance: "${db_arr[2]}" ,skipping the re-run"
		exit 1
	else
                                log "INSTANCE-INFO: It seems it is fresh run, marking status as running for instance: "${db_arr[2]}""
                                touch $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_RUNNING
                                log "Status is changed to running for instance: "${db_arr[2]}""
                        fi

##Gather the required Sqoop arguments and store in a separate file.
if [ "${db_arr[6]}" == "sap" ]
then
        Req_args_opr=`grep "YES=" $sap_Sqoop_Argument | cut -d'=' -f2`;
        echo $Req_args_opr > Args1_opr.txt
        sed 's/|/\n/g' Args1_opr.txt >args_final_opr.txt
        mapfile -t sqp_arg_opr <args_final_opr.txt
else
        Req_args_opr=`grep "YES=" $Sqoop_Argument | cut -d'=' -f2`;
        echo $Req_args_opr > Args1_opr.txt
        sed 's/|/\n/g' Args1_opr.txt >args_final_opr.txt
        mapfile -t sqp_arg_opr <args_final_opr.txt
fi

##Connection string
                        if [ "${db_arr[6]}" == "sap" ]
                        then
                                DBCONN_STRING_opr="\"jdbc:sap://${db_arr[0]}:${db_arr[3]}/?currentschema=${db_arr[5]}\""
                        else
                                if [ "${db_arr[1]}" == "NULL" ]
                                then
                                        DBCONN_STRING_opr="\"jdbc:${db_arr[6]}://${db_arr[0]}:${db_arr[3]};database=${db_arr[4]}\""
                                else
                                        if [ "${db_arr[2]}" == "NULL" ]
                                        then
                                                DBCONN_STRING_opr="\"jdbc:${db_arr[6]}://${db_arr[1]};database=${db_arr[4]}\"" #Form DB connection string
                                        else
                                                DBCONN_STRING_opr="\"jdbc:${db_arr[6]}://${db_arr[1]}\\${db_arr[2]};database=${db_arr[4]}\""
                                        fi
                                fi
                        fi
                 
##Calculate upper bound date and time for Sqoop query.
if  [ "${db_arr[6]}" == "sap" ]
then
	UpperBound_date="`sqoop eval --${sqp_arg_opr[3]} $DBCONN_STRING_opr --${sqp_arg_opr[1]} ${db_arr[7]} --password-file file:///home/$logged_user/${dbname}.password --${sqp_arg_opr[9]} $driver --query "SELECT CURRENT_DATE FROM DUMMY"| grep -Eo '[[:digit:]]{4}-[[:digit:]]{2}-[[:digit:]]{2}' | tail -1`"
	
else
	UpperBound_date="`nohup sqoop eval --${sqp_arg_opr[1]} $DBCONN_STRING_opr --${sqp_arg_opr[2]} ${db_arr[7]} --password-file file:///home/$logged_user/${dbname}.password --query "select convert(varchar(10),getdate(),121)"| grep -Eo '[[:digit:]]{4}-[[:digit:]]{2}-[[:digit:]]{2}' | tail -1`"

fi

if [ ! "$UpperBound_date" ]
then
	log "Unable to fetch upperbound date from source. Exiting.."
 	rm $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_RUNNING
        touch $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_FAIL
	exit
else
	UpperBound="$UpperBound_date 00:00:00.000"
fi


##Read the MYSQL table line by line
mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"call $SP_Table('${db_arr[0]}','${db_arr[3]}','${db_arr[4]}','${db_arr[5]}','${db_arr[1]}','${db_arr[2]}')" | while IFS= read -r ROW

do
                        tbl_arr=(${ROW// / })
			echo "${tbl_arr}"
			##Process validation 

                        if [ -d "$process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}" ] && [ -d "$process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}" ];
                        then
                                if [ -f "$process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_SQOOP_FAIL" ]
                                then
                                        rm -r $process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/*
                                fi

                        else
                                mkdir -p $process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}
                                mkdir -p $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}
                                chmod -R 700 $process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}
                        fi
						
			##Check and exit if any of the column values in source_table_details is Null.
                        if [ "${tbl_arr[5]}" != "NULL" ]
                        then

                                if [ "${tbl_arr[5]}" == "D" ] || [ "${tbl_arr[5]}" == "F-D" ]
                                then

                                  if [[ "${tbl_arr[0]}" == "NULL" ]] || [[ "${tbl_arr[1]}" == "NULL" && "${tbl_arr[13]}" != "Y" ]]  || [[ "${tbl_arr[2]}" == "NULL" ]] || [[ "${tbl_arr[3]}" == "NULL" ]] || [[ "${tbl_arr[4]}" == "NULL" ]] || [[ "${tbl_arr[6]}" == "NULL" ]] || [[ "${tbl_arr[7]}" == "NULL" ]] || [[ "${tbl_arr[8]}" == "NULL" ]] || [[ "${tbl_arr[9]}" == "NULL" ]]
                                        then

                                        log "Error: For Delta load, one or more Table metadata field is Null"
                                        exit 1
                                        fi
                                else

                                        if [ "${tbl_arr[0]}" == "NULL" ] || [ "${tbl_arr[3]}" == "NULL" ] || [ "${tbl_arr[5]}" == "NULL" ] || [ "${tbl_arr[6]}" == "NULL" ] || [ "${tbl_arr[7]}" == "NULL" ] || [ "${tbl_arr[8]}" == "NULL" ] || [ "${tbl_arr[9]}" == "NULL" ]
                                        then
                                        log "Error: For Full load, one or more Table metadata field is Null"
                                        exit 1
                                        fi
                                fi
                        elif [ "${tbl_arr[5]}" == "NULL" ]
                        then
                        #else
                                log "Error: Load type is missing"
                                exit 1
                        fi
	##HDFS file name

	HDFS_TBL=${logical_name,,}_${tbl_arr[0],,}

	
	query_str1=""
	query_str=""
 
	######Fetch free form query for sqoop from database#######
	echo "load type: ${tbl_arr[5]}"

	if [ "${tbl_arr[10]}" = "YQ" ]
	then
		query_str1=$(mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"select ff_query from source_table_details where ip_hostname='${db_arr[0]}' AND database_name='${db_arr[4]}' AND table_schema='${db_arr[5]}' AND server_name='${db_arr[1]}' AND instance_name='${db_arr[2]}' AND table_name='${tbl_arr[0]}';")
		query_str=`echo $query_str1|sed -e "s/ /|/g"`
	#######Fetching column names from metadata to form freeform query for sqoop#######
	elif [ "${tbl_arr[10]}" = "Y" ]
	then
		echo "select column_name from source_column_details where ip_hostname='${db_arr[0]}' and database_name= '${db_arr[4]}' and table_schema = '${db_arr[5]}' and table_name = '${tbl_arr[0]}' and server_name = '${db_arr[1]}' and instance_name = '${db_arr[2]}'"
		column_str1=$(mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"select column_name from source_column_details where ip_hostname='${db_arr[0]}' and database_name= '${db_arr[4]}' and table_schema = '${db_arr[5]}' and table_name = '${tbl_arr[0]}' and server_name = '${db_arr[1]}' and instance_name = '${db_arr[2]}' order by srno" | tr '\n' ',')
		echo "${column_str1}"
		key=(${column_str1//,/ })
		key_length=${#key[@]}
		if [ $key_length == 0 ]
		then
			column_str='NA'
		else
			column_str=`echo $column_str1 | sed -e 's/\,*$//g'`
        	fi
		echo "table Name " ${tbl_arr[0]}
		echo "New Column string " $column_str
		if [ "${db_arr[6]}" == "sap" ]
		then
			query_str1="select $column_str from \"${db_arr[5]}\".\"${tbl_arr[12]}\""
		else
			query_str1="select $column_str from ${tbl_arr[0]}"
		fi
		query_str=`echo $query_str1|sed -e "s/ /|/g"`
		echo "New query string " $query_str
	else 
		query_str='NA'
	fi

#################### Fetching Parameterised view details to form sqoop query####### 
param_view_str=""
echo "parameterised view flag = ${tbl_arr[13]}"
	if [ "${tbl_arr[13]}" = "Y" ]
	then
		echo "Here I am "
		view_data=$(mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"Select ifnull(param_name1  ,'NA')as param_name1,ifnull(param_value1 ,'NA')as param_value1 ,ifnull(param_name2  ,'NA')as param_name2  ,ifnull(param_value2 ,'NA')as param_value2 ,ifnull(param_name3  ,'NA')as param_name3  ,ifnull(param_value3 ,'NA')as param_value3 ,ifnull(param_name4  ,'NA')as param_name4  ,ifnull(param_value4 ,'NA')as param_value4 ,ifnull(param_name5  ,'NA')as param_name5  ,ifnull(param_value5 ,'NA')as param_value5 ,ifnull(param_name6  ,'NA')as param_name6  ,ifnull(param_value6 ,'NA')as param_value6 ,ifnull(param_name7  ,'NA')as param_name7  ,ifnull(param_value7 ,'NA')as param_value7 ,ifnull(param_name8  ,'NA')as param_name8  ,ifnull(param_value8 ,'NA')as param_value8 ,ifnull(param_name9  ,'NA')as param_name9  ,ifnull(param_value9 ,'NA')as param_value9 ,ifnull(param_name10 ,'NA')as param_name10 ,ifnull(param_value10,'NA')as param_value10 from calculative_view_details where view_name='${tbl_arr[12]}';")
		echo $view_data		
		view_arr_lwr=(${view_data// / })
		echo ${view_arr_lwr[@]}
		echo "ARRAY length:" ${#view_arr_lwr[@]}
		zz_flag=0
		for (( i=0; i<${#view_arr_lwr[@]}; i+=2 ))
		do
		        if [[ "${view_arr_lwr[i]}" == 'IP_ZZDATE_START' && "${view_arr_lwr[i+1]}" != 'NA' ]]
		        then
                		zz_flag=1
		                echo $zz_flag
        		fi
		done
		if [ ${#view_arr_lwr[@]} == 0 ]
                then
                        echo "Error: No parameter view details found"
                else
			for (( i=0; i<${#view_arr_lwr[@]}; i+=2 ))
			do
			        if [ "${view_arr_lwr[i]}" != 'NA'  ]
			        then
			                if [[ ${view_arr_lwr[i+1]} == 'NA' ]]
                			then
			                        param_view_str=`echo $param_view_str "'\"'\"'PLACEHOLDER'\"'\"' = ('\"'\"'\$\\$"${view_arr_lwr[i]}"\\$\$'\"'\"', '\"'\"' '\"'\"'),"`
			                else
                        			if [[ "$zz_flag" == '1' ]]  && [[ "${view_arr_lwr[i]}" == 'IP_BUDAT_START' || "${view_arr_lwr[i]}" == 'IP_BUDAT_END' ]]
                        			then
			                                param_view_str=`echo $param_view_str "'\"'\"'PLACEHOLDER'\"'\"' = ('\"'\"'\$\\$"${view_arr_lwr[i]}"\\$\$'\"'\"', '\"'\"' '\"'\"'),"`
                        			else
			                                param_view_str=`echo $param_view_str "'\"'\"'PLACEHOLDER'\"'\"' = ('\"'\"'\$\\$"${view_arr_lwr[i]}"\\$\$'\"'\"', '\"'\"'${view_arr_lwr[i+1]}'\"'\"'),"`
                        			fi
                			fi
        			fi
			done
		fi
##		final_string=`echo "($param_view_str) where \\$CONDITIONS"|sed -e "s/,)/)/g"|sed -e "s/ /|/g"`
		final_string=`echo "($param_view_str) "|sed -e "s/,)/)/g"|sed -e "s/ /|/g"`
		echo "finalstring=" $final_string
		query_str=`echo $query_str$final_string`
		echo $query_str		
	fi

##Table Restartability                                          
                        table_status="if [ -f $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_SUCCESS ]; then \n
                                log \"TABLEINFO: Process for table ${tbl_arr[0]} is already completed\" \n
                                log \"TABLEINFO: skipping run for table: \"${tbl_arr[0]}\"\" \n
                                exit 1\n
                                fi\n
                        if [ -f $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_FAIL ]; then\n
                                log \"TABLEWARNING: As this is re-run for failed script for table: \"${tbl_arr[0]}\" , changing status to Running \"\n
                                rm $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_FAIL\n
                                log \"Status for Table is changed to running\"\n
                                touch $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_RUNNING\n
                                log \"TABLEINFO: This is re-run, setting up the skipping flags\"\n
                        elif [ -f $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_RUNNING ]; then\n
                                log \"TABLEWARNING: As script is running for table: \"${tbl_arr[0]}\" ,skipping the re-run\"\n
                                exit 1\n
                        else\n
                                log \"TABLEINFO: It seems it is fresh run, marking status as running for table: \"${tbl_arr[0]}\"\"\n
                                touch $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_RUNNING\n
                                log \"Status is changed to running for table: \"${tbl_arr[0]}\"\"\n
                        fi\n"

##Passing arguments for Hive and Sqoop process
		if [ "${tbl_arr[5]}" == "D" ]
		then
                        hive_query="$hive_path/HiveQL.sh $hive_path/hive_config.conf ${db_arr[0]} ${db_arr[4]} ${db_arr[5]} ${tbl_arr[0]} \"${tbl_arr[1]}\" ${tbl_arr[5]} ${tbl_arr[6]} ${process_log}/${source_name}/$rundate/${logical_name}/${tbl_arr[0]} ${db_arr[1]} ${db_arr[2]} ${UpperBound} ${db_arr[3]} ${source_name} ${HDFS_TBL} ${logical_name}\n
                        if [ \$? == 0 ];\n
                        then\n
			mysql --defaults-file=/home/$logged_user/.mysql.cnf -h$MYSQL_HOST -D$MYSQL_DB_NAME -e\"update $MYSQL_TBL_NAME set last_extracted_datetime='$UpperBound' where ip_hostname='${db_arr[0]}' and server_name='${db_arr[1]}' and instance_name='${db_arr[2]}' and database_name='${db_arr[4]}' and table_schema='${db_arr[5]}' and table_name='${tbl_arr[0]}';\"\n
                        if [ \$? == 0 ];\n
                        then\n
                                rm $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_RUNNING\n
                                touch $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_SUCCESS\n
                        fi\n
                        else\n
                                rm $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_RUNNING\n
                                log \"ERROR: Process for table ${tbl_arr[0]} failed to update last_extracted_datetime\" \n
                                touch $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_FAIL\n	
                        fi\n"
			
		else
			 hive_query="$hive_path/HiveQL.sh $hive_path/hive_config.conf ${db_arr[0]} ${db_arr[4]} ${db_arr[5]} ${tbl_arr[0]} ${tbl_arr[1]} ${tbl_arr[5]} ${tbl_arr[6]} ${process_log}/${source_name}/$rundate/${logical_name}/${tbl_arr[0]} ${db_arr[1]} ${db_arr[2]} ${UpperBound} ${db_arr[3]} ${source_name} ${HDFS_TBL} ${logical_name}\n
                        if [ \$? == 0 ];\n
                        then\n
                                rm $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_RUNNING\n
                                touch $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_SUCCESS\n
                        else\n
                                rm $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_RUNNING\n
                                touch $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_FAIL\n
                        fi\n"
		fi
			echo "${db_arr[7]} ${db_arr[8]} ${tbl_arr[0]} ${tbl_arr[4]} ${db_arr[5]} ${db_arr[6]} ${db_arr[0]} ${db_arr[3]} ${db_arr[4]} ${tbl_arr[1]} ${tbl_arr[2]} ${tbl_arr[3]} ${tbl_arr[5]} ${process_script} ${rundate} ${process_log} ${db_arr[1]} ${db_arr[2]} $UpperBound ${tbl_arr[7]} ${source_name} ${tbl_arr[9]} ${HDFS_TBL} ${config_file} ${temp_server_name} ${logical_name} ${tbl_arr[10]} ${tbl_arr[13]} ${query_str}"

                        sqoop="sh $sqoop_path/generate_SqoopQuery.sh ${db_arr[7]} ${db_arr[8]} ${tbl_arr[0]} ${tbl_arr[4]} ${db_arr[5]} ${db_arr[6]} ${db_arr[0]} ${db_arr[3]} ${db_arr[4]} ${tbl_arr[1]} ${tbl_arr[2]} ${tbl_arr[3]} ${tbl_arr[5]} ${process_script} ${rundate} ${process_log} ${db_arr[1]} ${db_arr[2]} $UpperBound ${tbl_arr[7]} ${source_name} ${tbl_arr[9]} ${HDFS_TBL} ${config_file} ${temp_server_name} ${logical_name} ${tbl_arr[10]} ${tbl_arr[13]} ${query_str}"
			sqoop_status="exit_code=\$?;\n
                        if [ \"\$exit_code\" == 0 ];\n
                        then\n
                                rm $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_SQOOP_RUNNING\n
                                touch $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_SQOOP_SUCCESS\n
                        else\n
                                rm $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_SQOOP_RUNNING\n
                                rm $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_RUNNING\n
                                touch $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_SQOOP_FAIL\n
                                touch $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_FAIL\n
                                exit 1\n
                        fi\n"

        		record_count="rec_count=\`cat $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/${HDFS_TBL}_sqoop.log | tail -1 | awk -F\" \" '{ print \$6}'\`\n
			echo \$rec_count \n
			if [ \$rec_count == 0 ]\n
			 then\n
				
				echo \"$run_timestamp: No record imported through sqoop. Skipping hive run for table '${tbl_arr[0]}'..\" >$process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/${HDFS_TBL}_hive.log \n
				rm $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_RUNNING\n
				touch $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_${tbl_arr[0]}_SUCCESS\n
			        exit 1\n 
			fi\n"

##Create Sqoop and Hive query for each table
                        for t_name in ${tbl_arr[0]}
                        do
                    
##Folder check in HDFS
                        Target_subdir="hadoop fs -test -d $TARGET_DIR${tbl_arr[8],,}/${HDFS_TBL,,}\n
                        if [ \$? == 0 ]\n
                        then\n
                                hadoop fs -rm -r $TARGET_DIR${tbl_arr[8],,}/${HDFS_TBL,,}\n
                        fi\n"

##Sqoop Restartability
                        script_status="if [ -f $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_SQOOP_SUCCESS ]; then \n
                                log \"SQOOPINFO: Sqoop job for table ${tbl_arr[0]} is already completed\" \n
                                log \"SQOOPINFO: skipping run for table: \"${tbl_arr[0]}\"\" \n
                                $hive_query\n
                                exit 1\n
                        fi\n
                        if [ -f $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_SQOOP_FAIL ]; then\n
                                log \"SQOOPWARNING: As this is re-run for failed script for table: \"${tbl_arr[0]}\" , changing status to Running \"\n
                                rm $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_SQOOP_FAIL\n
                                log \"Status for Sqoop is changed to running\"\n
                                touch $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_SQOOP_RUNNING\n
                                log \"SQOOPINFO: This is re-run, setting up the skipping flags\"\n
                        elif [ -f $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_SQOOP_RUNNING ]; then\n
                                log \"SQOOPWARNING: As script is running for table: \"${tbl_arr[0]}\" ,skipping the re-run\"\n
                                exit 1\n
                        else\n
                                log \"SQOOPINFO: It seems it is fresh run, marking status as running for table: \"${tbl_arr[0]}\"\"\n
                                touch $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/_SQOOP_RUNNING\n
                                log \"Status for Sqoop is changed to running for table: \"${tbl_arr[0]}\"\"\n
                        fi\n"

##Final Sqoop and Hive query generation for each table
                                                                
               			echo -e ${log_func} >$process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/${HDFS_TBL}.sh
				echo -e ${instance_status} >>$process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/${HDFS_TBL}.sh
				echo -e ${seq_status} >>$process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/${HDFS_TBL}.sh
				echo -e ${table_status} >>$process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/${HDFS_TBL}.sh
				echo -e ${script_status} >>$process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/${HDFS_TBL}.sh
				echo -e $Target_subdir  >>$process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/${HDFS_TBL}.sh
				$sqoop
				echo -e ${sqoop_status} >>$process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/${HDFS_TBL}.sh
				if [ "${tbl_arr[6]}" = "N" ]
            			then
					echo -e ${record_count} >>$process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/${HDFS_TBL}.sh
				fi
				echo -e $hive_query >>$process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/${HDFS_TBL}.sh
        done

#calculate number of sqoop can be run on client
#	free_ram_memory=`free -g | grep 'cache:' | awk -F" " '{ print $4}' | sed 's/^[ \t]*//;s/[ \t]*$//'`
#	log "free_ram_memory: $free_ram_memory"
#	num_poss_tables=`expr $free_ram_memory \/ $coeffcient`
#	run_num_tables=`expr $num_poss_tables - $reserved_mem`
#	log "run_num_tables: $run_num_tables"
	echo $num_poss_tables
	echo $run_num_tables
#	if [ ${run_num_tables} -le 0 ]; then
#        	echo "Error: available memory is too less to start, please clear the memory and re-run"
#		mem_status="MEMORY_FAIL"
#		rm $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_RUNNING
#		touch $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_FAIL
#		status=INSTANCE_FAIL
#		sh $File_PATH/mail_script.sh $config_file $source_name $rundate $logical_name $temp_server_name ${db_arr[2]} ${db_arr[4]} $mem_status
#        	#sh $File_PATH/mail_script.sh $config_file ${mail_log_path} $process_log/${source_name}/$rundate/${logical_name}/${logical_name}\_instance.log Memory "Too less memory available" "Available memory is too less to start, please clear the memory and re-run"
#        	exit 1
#	fi

	free_ram_memory=`free -g | grep 'cache:' | awk -F" " '{ print $4}' | sed 's/^[ \t]*//;s/[ \t]*$//'`
	log "free_ram_memory: $free_ram_memory"
	#echo "coeffcient $coeffcient"
	#echo "reserved_mem $reserved_mem"
	num_poss_tables=`expr $free_ram_memory \/ $coeffcient`
	run_num_tables=`expr $num_poss_tables - $reserved_mem`
	log "run_num_tables: $run_num_tables"

	#echo "num_poss_tables $num_poss_tables"
	#echo "run_num_tables $run_num_tables"
	counter_mem_wait=0
	run_num_tables_do=0
	#echo $counter_mem_wait
	#echo $run_num_tables_do
	#echo "num_poss_tables" $num_poss_tables
	#echo "run_num_tables" $run_num_tables
	#echo "wait_cycle_for_mem_avlb" ${wait_cycle_for_mem_avlb}

	if [ ${run_num_tables} -le 0 ] && [ ${counter_mem_wait} -le ${wait_cycle_for_mem_avlb} ]
        then
                while [ ${counter_mem_wait} -le 10 ] && [ ${run_num_tables_do} -le 0 ]; do
                	counter_mem_wait=`expr $counter_mem_wait + 1`
                	free_ram_memory_do=`free -g | grep 'cache:' | awk -F" " '{ print $4}' | sed 's/^[ \t]*//;s/[ \t]*$//'`
                	log "free_ram_memory: $free_ram_memory_do"
                	num_poss_tables_do=`expr $free_ram_memory_do \/ $coeffcient`
                	run_num_tables_do=`expr $num_poss_tables_do - $reserved_mem`
                	#echo $counter_mem_wait
                	#echo $num_poss_tables_do
                	#echo $run_num_tables_do
                	sleep ${wait_cycle_interval_for_mem_avlb}
        	done
	fi
	
	if [ ${run_num_tables} -le 0 ] && [ ${run_num_tables_do} -le 0 ]; then
        	echo "Error: available memory is too less to start, please clear the memory and re-run"
        	mem_status="MEMORY_FAIL"
        	rm $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_RUNNING
        	touch $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_FAIL
        	status=INSTANCE_FAIL
        	sh $File_PATH/mail_script.sh $config_file $source_name $rundate $logical_name $temp_server_name ${db_arr[2]} ${db_arr[4]} $mem_status
        	#sh $File_PATH/mail_script.sh $config_file ${mail_log_path} $process_log/${source_name}/$rundate/${logical_name}/${logical_name}\_instance.log Memory "Too less memory available" "Available memory is too less to start, please clear the memory and re-run"
        exit 1
	fi


	while [ `find $process_log/${source_name}/$rundate/${logical_name}/ -name '*RUNNING*'|grep -v '/_INSTANCE_' |wc -l` -gt ${limit_of_running_process} ]
	do
		sleep 3
		free_ram_memory_l=`free -g | grep 'cache:' | awk -F" " '{ print $4}' | sed 's/^[ \t]*//;s/[ \t]*$//'`
		log "free_ram_memory: $free_ram_memory_rp"
		num_poss_tables_rp=`expr $free_ram_memory_rp \/ $coeffcient`
		run_num_tables_rp_curr=`expr $num_poss_tables_rp - $reserved_mem`
		log "run_num_tables: $run_num_tables_rp_curr"
		counter_mem_wait_rp=0
		run_num_tables_rp=0
		#echo $counter_mem_wait_rp
		#echo $run_num_tables_rp

		if [ ${run_num_tables_rp_curr} -le 0 ] && [ ${counter_mem_wait_rp} -le ${wait_cycle_for_mem_avlb} ]; then
		        while [ ${counter_mem_wait_rp} -le 10 ] && [ ${run_num_tables_rp} -le 0 ]; do
                		counter_mem_wait_rp=`expr $counter_mem_wait_rp + 1`
	                	free_ram_memory_rp=`free -g | grep 'cache:' | awk -F" " '{ print $4}' | sed 's/^[ \t]*//;s/[ \t]*$//'`
	                	log "free_ram_memory: $free_ram_memory_rp"
		                num_poss_tables_rp=`expr $free_ram_memory_rp \/ $coeffcient`
        		        run_num_tables_rp=`expr $num_poss_tables_rp - $reserved_mem`
                		#echo $counter_mem_wait
		                #echo $num_poss_tables_rp
        		        #echo $run_num_tables_rp
                		sleep ${wait_cycle_interval_for_mem_avlb}
        		done
		fi

		if [ ${run_num_tables_rp_curr} -le 0 ] && [ ${run_num_tables_rp} -le 0 ]; then
  			log "Error: available memory is too less to start, please clear the memory and re-run"
  			mem_status="MEMORY_FAIL"
			rm $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_RUNNING
			touch $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_FAIL
			status=INSTANCE_FAIL
  			sh $File_PATH/mail_script.sh $config_file $source_name $rundate $logical_name $temp_server_name ${db_arr[2]} ${db_arr[4]} $mem_status
  			#sh $File_PATH/mail_script.sh $config_file ${mail_log_path} $process_log/${source_name}/$rundate/${logical_name}/${logical_name}\_instance.log Memory "Too less memory available" "Available memory is too less to start, please clear the memory and re-run"
		exit 1
		fi
	done

##Run the process for each Table

	nohup sh $process_script/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}/${HDFS_TBL}.sh ${db_arr[7]} ${db_arr[8]} >> $process_log/${source_name}/$rundate/${logical_name}/${logical_name}\_instance.log 2>&1 &
	
	$CONNECT_IMPALA -q "invalidate metadata landing.${HDFS_TBL}"
	if [ $? == 0 ]
	then
		log "Successfuly invalidate metadata in landing layer for table ${HDFS_TBL} in impala"
	else
		log "Issue in invalidate metadata in landing layer for table ${HDFS_TBL} in impala"
	fi

	$CONNECT_IMPALA -q "invalidate metadata raw.${HDFS_TBL}"
	if [ $? == 0 ]
	then
		log "Successfuly invalidate metadata in raw layer for table ${HDFS_TBL} in impala"	
	else
		log "Issue in invalidate metadata in raw layer for table ${HDFS_TBL} in impala"	
	fi

    	$CONNECT_IMPALA -q "invalidate metadata persistent.${HDFS_TBL}"
	if [ $? == 0 ]
	then
		log "Successfuly invalidate metadata in persistent layer for table ${HDFS_TBL} in impala"
	else
		log "Issue in invalidate metadata in persistent layer for table ${HDFS_TBL} in impala"
	fi


	pid=$!	
	pids[$pid]=$t_name
        echo "process ids: pids[$pid]"
        sqoop_run_count=$(($sqoop_run_count+1))
        echo "sqoop_run_count: $sqoop_run_count"

        if [ "$sqoop_run_count" = "$run_num_tables" ]
        then
		init_num_back_processes=`echo ${#pids[@]}`
            echo "Debug: init_num_back_processes=${init_num_back_processes}"
            while [ -n "${pids[*]}" ]; do
                sleep 60
                for pid in "${!pids[@]}"; do
					log "Info: checking for the process id: "$pid
					ps -p $pid > /dev/null
                    if [ $? == 1 ]; then
						unset pids[$pid]
                        log "Info: Completed process: "${pid}
                        log "Debug: as one child has completed, decrement sqoop_run_count by 1"
                        sqoop_run_count=`expr $sqoop_run_count - 1`
                    fi
                done
                end_num_back_processes=`echo ${#pids[@]}`
                if [ ${end_num_back_processes} -lt ${init_num_back_processes} ]; then
                    log "Info: As one of the sqoop process is finished, breaking up the monitoring, to allow next table to be added in the batch: "
                    break
                fi
            done
                sqoop_run_count=0
        fi

done

## Waiting for completion of all running tables script
while find $process_log/${source_name}/$rundate/${logical_name}/ -name "*_RUNNING"|grep -v '/_INSTANCE_'>/dev/null; do
sleep 3
done

mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"call $SP_Table('${db_arr[0]}','${db_arr[3]}','${db_arr[4]}','${db_arr[5]}','${db_arr[1]}','${db_arr[2]}')" | while IFS= read -r ROW

do
        tbl_arr=(${ROW// / })
	if [ "${tbl_arr[13]}" = "Y" ]
	then
		view_data=$(mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"Select ifnull(param_name1  ,'NA')as param_name1,ifnull(param_value1 ,'NA')as param_value1 ,ifnull(param_name2  ,'NA')as param_name2  ,ifnull(param_value2 ,'NA')as param_value2 ,ifnull(param_name3  ,'NA')as param_name3  ,ifnull(param_value3 ,'NA')as param_value3 ,ifnull(param_name4  ,'NA')as param_name4  ,ifnull(param_value4 ,'NA')as param_value4 ,ifnull(param_name5  ,'NA')as param_name5  ,ifnull(param_value5 ,'NA')as param_value5 ,ifnull(param_name6  ,'NA')as param_name6  ,ifnull(param_value6 ,'NA')as param_value6 ,ifnull(param_name7  ,'NA')as param_name7  ,ifnull(param_value7 ,'NA')as param_value7 ,ifnull(param_name8  ,'NA')as param_name8  ,ifnull(param_value8 ,'NA')as param_value8 ,ifnull(param_name9  ,'NA')as param_name9  ,ifnull(param_value9 ,'NA')as param_value9 ,ifnull(param_name10 ,'NA')as param_name10 ,ifnull(param_value10,'NA')as param_value10 from calculative_view_details where view_name='${tbl_arr[12]}';")
		view_arr_lwr=(${view_data// / })
		echo ${view_arr_lwr[@]}
		echo "ARRAY length:" ${#view_arr_lwr[@]}
		zz_flag=0
		for (( i=0; i<${#view_arr_lwr[@]}; i+=2 ))
		do
			if [[ "${view_arr_lwr[i]}" == 'IP_ZZDATE_START' && "${view_arr_lwr[i+1]}" != 'NA' ]]
			then
				zz_flag=1
				echo $zz_flag
			fi
		done
		echo "$process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]}"
		if [[ $(find $process_log/${source_name}/$rundate/${logical_name}/${tbl_arr[0]} -name "_${tbl_arr[0]}_SUCCESS") ]]
		then
			echo "found table success"
			if [ "${tbl_arr[13]}" == "Y" ];
			then
				for (( i=0; i<${#view_arr_lwr[@]}; i+=2 ))
				do
					if [[ "${view_arr_lwr[i]}" == 'IP_ZZDATE_END' ]]
					then
						echo "zz_flag_"$zz_flag	
						if [[  "$zz_flag" != '1' ]] 
						then
							MJAHR=$(date +'%Y' )
							updated_DATE=$( date +'%Y%m%d' )
							echo "BUDAT found"
							mysql --defaults-file=/home/$logged_user/.mysql.cnf -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"update calculative_view_details set param_value1 = '$MJAHR', param_value4 = '$updated_DATE', param_value5='000000', param_value6='$updated_DATE', param_value7='235959' where view_name='${tbl_arr[12]}';"
							if [ $? != 0 ];
							then
								log "Error: update table calculative_view_details failed"
								break
							else
								log "Update table calculative_view_details success"
								break
							fi
						else
							if [[ "${view_arr_lwr[i]}" == 'IP_ZZDATE_END' ]] && [[ "${view_arr_lwr[i+1]}" != 'NA' ]];
							then
								run_date=`date +'%Y%m%d'`
								echo "rundate" $run_date
								if [[ "${view_arr_lwr[i+1]}" == "$run_date" ]]
								then
									MJAHR=$( date -d "${view_arr_lwr[i+1]}" +'%Y' )
									updated_DATE=$( date -d "${view_arr_lwr[i+1]}" +'%Y%m%d' )
									echo "FOUND same zzdate as rundate"
								else
									MJAHR=$( date -d "${view_arr_lwr[i+1]} +1 days" +'%Y' )
									updated_DATE=$( date -d "${view_arr_lwr[i+1]} +1 days" +'%Y%m%d' )
									echo "FOUND different zzdate "
								fi										
								echo "ZZDATE found"
								mysql --defaults-file=/home/$logged_user/.mysql.cnf -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"update calculative_view_details set param_value1 = '$MJAHR',param_value4 = '$updated_DATE', param_value5='000000', param_value6='$updated_DATE',  param_value7='235959'  where view_name='${tbl_arr[12]}';"
								if [ $? != 0 ]
								then
									log "Error: update table calculative_view_details failed "
									break
								else
									log "Update table calculative_view_details success"
									break
								fi
							fi
						fi
					fi
				done
			fi
		fi
	fi
done




## Code for Spend Analytics Layer Begins ##
if [ "${db_arr[12]}" = "Y" ]
then
#	if [[ $(find $process_log/${source_name}/$rundate/${logical_name}/ -name "*SQOOP_FAIL") ]] || [[ $(find $process_log/${source_name}/$rundate/${logical_name}/ -name "*PERSISTENT_FAIL") ]] || [[ $(find $process_log/${source_name}/$rundate/${logical_name}/ -name "*INITIAL_FAIL") ]] || [[ $(find $process_log/${source_name}/$rundate/${logical_name}/ -name "_FULL_REFRESH_FAIL") ]] 
	if [[ $(find $process_log/${source_name}/$rundate/${logical_name}/ -name "*_FAIL") ]]
	then
 		rm $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_RUNNING
        	touch $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_FAIL
		status=INSTANCE_FAIL
		sh $File_PATH/mail_script.sh $config_file $source_name $rundate $logical_name $temp_server_name ${db_arr[2]} ${db_arr[4]} $status
		echo $status
		exit 1
	else
		if [[ "${db_arr[6]}" == "sap" ]]
		then
			if [ -f $process_log/${source_name}/$rundate/${rundate}_sap_run_1 ]
			then
				if [ -f $process_log/${source_name}/$rundate/${rundate}_sap_run_2 ]
				then
					log "Both Files exists"
				else
					touch $process_log/${source_name}/$rundate/${rundate}_sap_run_2
					chmod 755 $process_log/${source_name}/$rundate/${rundate}_sap_run_2
				fi
			else
				touch $process_log/${source_name}/$rundate/${rundate}_sap_run_1
				chmod 755 $process_log/${source_name}/$rundate/${rundate}_sap_run_1
			fi
		fi

		if [[ -f $process_log/${source_name}/$rundate/${rundate}_sap_run_1 && -f $process_log/${source_name}/$rundate/${rundate}_sap_run_2 && "${db_arr[6]}" == "sap" ]] || [[ "${db_arr[6]}" != "sap" ]]
		then 
			source $hive_path/hive_config.conf
	 		#if [ -d "$process_log/${source_name}/$rundate/${logical_name}/sal" ];
			if [ -d "$process_log/${source_name}/$rundate/sal" ];

			then
				log "SAL-INFO: Log Directory for SAL Tables exists"                    
			else
				#mkdir -p $process_log/${source_name}/$rundate/${logical_name}/sal/

				mkdir -p $process_log/${source_name}/$rundate/sal/
				#chmod -R 700 $process_script/${source_name}/$rundate/${logical_name}/sal
			fi

			mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"select * from source_sal_table_details where source= '$source_name' and run_flag = 'Y' order by 1" | while IFS= read -r ROW
			do
        		sal_tbl_arr=(${ROW// / })
			sal_tbl_name=${sal_tbl_arr[1]}
			sal_initial_load=${sal_tbl_arr[2]}
			sal_load_type=${sal_tbl_arr[3]}
			sal_primary_key=${sal_tbl_arr[5]}
			sal_cdc_column=${sal_tbl_arr[6]}
			sal_last_ex_date=${sal_tbl_arr[7]}
			sal_generate_hql_flag=${sal_tbl_arr[10]}
		
			log "SAL_INFO: DATA LOADING STARTED FROM PERSISTENT TO SAL ZONE FOR TABLE ${sal_tbl_arr[1]}"

			#echo "sal_tbl_name  :$sal_tbl_name" 
			#echo "sal_initial_load  :$sal_initial_load" 
			#echo "sal_load_type  :$sal_load_type" 
			#echo "sal_primary_key  :$sal_primary_key" 
			#echo "sal_cdc_column  :$sal_cdc_column" 
			#echo "sal_last_ex_date  :$sal_last_ex_date" 
			#echo "process_log  :${process_log}/${source_name}/$rundate/${logical_name}/sal" 
			#echo "hive_path  :$hive_path/hive_config.conf" 
			#echo "rundate :$rundate" 
			#echo "$source_name  :$source_name" 
			#echo "logical_name  :$logical_name" 
			#echo "sal_generate_hql_flag :$sal_generate_hql_flag"

			#sh $hive_path/persistent_to_sal.sh $sal_tbl_name $sal_initial_load $sal_load_type $sal_primary_key $sal_cdc_column $sal_last_ex_date ${process_log}/${source_name}/$rundate/${logical_name}/sal $hive_path/hive_config.conf $rundate $source_name $logical_name $sal_generate_hql_flag
			sh $hive_path/persistent_to_sal.sh $sal_tbl_name $sal_initial_load $sal_load_type $sal_primary_key $sal_cdc_column $sal_last_ex_date ${process_log}/${source_name}/$rundate/sal $hive_path/hive_config.conf $rundate $source_name $logical_name $sal_generate_hql_flag

		        if [ $? -ne 0 ];
	        	then
		             echo "HIVE_ERROR: HIVE PERSITENT TO SAL LOAD PROCESS FAILED FOR TABLE ${sal_tbl_name}" 
			     echo "HIVE_INFO: FOR DETAILED LOG REFER ${log_dir}/${sal_tbl_name}_hive.log"
			else
				if [ "${sal_initial_load}" == "Y" ];
				then
					mysql --defaults-file=/home/$logged_user/.mysql.cnf -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"update source_sal_table_details set initial_load = 'N',last_extracted_datetime = '$rundate' where source= '$source_name' and table_name = '$sal_tbl_name'"
					if [ $? -ne 0 ];
		  			then
						log "MYSQL_ERROR: FAIL TO UPDATE initial_load and last_extracted_datetime FOR TABLE ${sal_tbl_name}"
  					else
  		   		    		log "MYSQL_INFO: SUCCESSFULLY UPDATED initial_load and last_extracted_datetime FOR TABLE ${sal_tbl_name}"
  					fi

				else
					mysql --defaults-file=/home/$logged_user/.mysql.cnf -h$MYSQL_HOST -D$MYSQL_DB_NAME -e"update source_sal_table_details set last_extracted_datetime = '$rundate' where source= '$source_name' and table_name = '$sal_tbl_name'"
					if [ $? -ne 0 ];
  					then
  		   	    			log "MYSQL_ERROR: FAIL TO UPDATE initial_load and last_extracted_datetime FOR TABLE ${sal_tbl_name}"
  					else
  		   	    			log "MYSQL_INFO: SUCCESSFULLY UPDATED initial_load and last_extracted_datetime FOR TABLE ${sal_tbl_name}"
  					fi
				fi
			$CONNECT_IMPALA -q "invalidate metadata spend_analytics.${sal_tbl_name}"
			if [ $? == 0 ]
			then
				log "Successfuly invalidate metadata for table ${sal_tbl_name} in impala"
				table_status=SUCCESS
			else
				log "Issue in invalidate metadata for table ${sal_tbl_name} in impala"
				table_status=FAIL
			fi

	        	hs_source_table="${source_name}"

			sh $File_PATH/data_lake_handshake_script.sh T ${hs_source_table} ${sal_tbl_name} NULL $table_status NULL >>$process_log/${source_name}/$rundate/${logical_name}/${hs_source_table}_handshake.log 2>&1
			if [ $? == 0 ]
			then
				log "Handshake trigger generated successfully for source: ${source_name} and SAL table ${sal_tbl_name} "
			else
				log "Issue in generating handshake trigger for source: ${source_name} and SAL table ${sal_tbl_name}"
			fi

			fi
			$CONNECT_IMPALA -q "invalidate metadata spend_analytics.table_load_status"
			if [ $? == 0 ]
			then
				log "Successfuly invalidate metadata for table table_load_status in impala "
			else
				log "Issue in invalidate metadata for table table_load_status in impala"
			fi
 
			done
		else
			log "SAL-INFO: SAL Run bypassed as both instance of SAP Load is not complete"
		fi
	fi
else
	log "SAL-INFO: SAL Run not required, load_sal_flag set to N"
fi


## Code for Spend Analytics Layer Ends ##

if [[ -n $(find /eip_interfaces/logs/sap/2017-04-21/sap_hana_ecc_ha/ -name "*_FAIL") ]] || [[ -n $(find /eip_interfaces/logs/sap/2017-04-21/sal/ -name "*_FAIL") ]]
#if [[ -n $(find $process_log/${source_name}/$rundate/${logical_name}/ -name "*_FAIL") ]] 
then
	rm $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_RUNNING
	touch $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_FAIL
	status=INSTANCE_FAIL
	sh $File_PATH/mail_script.sh $config_file $source_name $rundate $logical_name $temp_server_name ${db_arr[2]} ${db_arr[4]} $status
	echo $status
else
	###check table fail or table running status 
	rm $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_RUNNING
	touch $process_log/${source_name}/$rundate/${logical_name}/_INSTANCE_${db_arr[2]}_SUCCESS


	status=INSTANCE_SUCCESS
	sh $File_PATH/mail_script.sh $config_file $source_name $rundate $logical_name $temp_server_name ${db_arr[2]} ${db_arr[4]} $status
fi

hs_source="${source_name}_${temp_server_name}"

sh $File_PATH/data_lake_handshake_script.sh I ${hs_source} NULL $status NULL >>$process_log/${source_name}/$rundate/${logical_name}/${hs_source}_handshake.log 2>&1
if [ $? == 0 ]
then
	echo "Handshake trigger generated successfully"
else
	echo "Issue in generating handshake trigger"
fi

##Removing intermediate files
rm Args1_opr.txt args_final_opr.txt
rm *.java
#rm $File_PATH/temp_table

###EOF###
