#!/bin/bash
# +===================================================================================================================================================+|
# |                                                                                                                                                    |
# | FileName    : landing_to_raw.sh                                                                                                                    |
# |                                                                                                                                                    |
# | Language    : Shell script                                                                                                                         |
# |                                                                                                                                                    |
# | Description : This script  generate hql to load data from landing layer to raw layer                                                                                                                        |
# +===================================================================================================================================================+|
function log() {
        log_time=`date "+%m-%d-%Y:%H:%M:%S"`
        #echo -e "${log_time} $@"
        echo -e "${log_time} $@" >> ${log_dir}/${table_name_new}_hive.log
}
table_name=${1}
table_name_new=${2}
config_filepath=${3}
log_dir=${4}
source_name=${5}
run_date=${6}
filepath=$(dirname $3)
server_name=${7}
instance_name=${8}
logical_name=${9}

source ${config_filepath}
#Condition to check all parameters
if [ $# -ne 9 ]
then
     log "Usage : sh <script name> <table_name> table_name_new> <config_filepath> <log_dir> <source_name> <run_date><server_name><instance_name> <logical_name>"
     log "For example : sh HiveDDL.sh $table_name $table_name_new $config_filepath $log_dir $source_name $run_date $server_name $instance_name ${logical_name}"
     log "HIVE_ERROR:EXITING ....."
     exit 1;
fi

if [ ! -d "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}" ]
then
    log "HIVE_ERROR: INITIAL LOAD FOR ${table_name_new} NOT PERFORMED,FIRST LOAD INITIAL DATA"
    exit 1;
fi

#---------------------------------------------RESTARTABILTY BLOCK------------------------------------------------------|
if [ -f ${log_dir}/_LANDING_TO_RAW_SUCCESS ]; then
   log "HIVE_INFO: LANDING TO RAW LOAD FOR TABLE "${table_name_new}" IS ALREADY COMPLETED"
   log "HIVE_INFO: SKIPPING RUN FOR TABLE: "${table_name_new}
   exit 0
fi

if [ -f ${log_dir}/_LANDING_TO_RAW_FAIL ]; then
    log "HIVE_WARNING: AS THIS IS RE-RUN FOR FAILED SCRIPT FOR TABLE: "${table_name_new} ", CHANGING STATUS TO RUNNING "
    rm ${log_dir}/_LANDING_TO_RAW_FAIL
    state_change_status=`echo $?`
    if [ $state_change_status == 0 ]; then
        log "HIVE_INFO: STATUS IS CHANGED TO RUNNING"
        touch ${log_dir}/_LANDING_TO_RAW_RUNNING
    else
        log "HIVE_ERROR: FAILED TO CHANGE THE STAUS FROM FAIL TO RUNNING FOR TABLE: "${table_name_new}
        log "HIVE_ERROR: EXITING..... "
        exit 1
    fi
elif [ -f ${log_dir}/_LANDING_TO_RAW_RUNNING ]; then
     log "HIVE_WARNING: AS SCRIPT IS RUNNING FOR TABLE: "${table_name_new}" ,SKIPPING THE RE-RUN"
     exit 0
else
    log "HIVE_INFO: IT SEEMS IT IS FRESH RUN, MARKING STATUS AS RUNNING FOR TABLE: "${table_name_new}
    touch ${log_dir}/_LANDING_TO_RAW_RUNNING
    state_change_status=`echo $?`
    if [ $state_change_status == 0 ]; then
        log "HIVE_INFO: STATUS IS CHANGED TO RUNNING FOR TABLE: "${table_name_new}
    fi
fi
#---------------------------------------END RESTARTABILTY BLOCK---------------------------------------------|

if $(hadoop fs -test -d ${raw_zone_path}/${source_name}/${table_name_new}/load_type=DELTA/run_date=$run_date)
then 
     log "HIVE_INFO: IT IS RE-RUN FOR INCOMPLETE DATA LOAD FROM LANDING TO RAW ZONE FOR TABLE ${table_name_new}"
     hadoop fs -rm -r ${raw_zone_path}/${source_name}/${table_name_new}/load_type=DELTA/run_date=$run_date &>>${log_dir}/${table_name_new}_hive.log
     if [ $? -ne 0 ];
     then
        log "HIVE_ERROR: FAIL TO REMOVE HDFS DIRECTORY ${raw_zone_path}/${source_name}/${table_name_new}/load_type=DELTA/run_date=$run_date"
        rm ${log_dir}/_LANDING_TO_RAW_RUNNING
        touch ${log_dir}/_LANDING_TO_RAW_FAIL
        exit 1;
      else
          log "HIVE_INFO: SUCCESSFULLY REMOVED HDFS DIRECTORY ${raw_zone_path}/${source_name}/${table_name_new}/load_type=DELTA/run_date=$run_date"
      fi
fi

#In case of hql generated earliar it will execute existing file
if [ -f "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_raw.hql" ]
then
    echo -e "\n ---------LOG FOR LANDING TO RAW LOAD-------------\n" >> ${log_dir}/${table_name_new}_hive.log
    $cli -hiveconf run_date="$run_date" -f ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_raw.hql &>> ${log_dir}/${table_name_new}_hive.log
    if [ $? -ne 0 ];
    then
       log "HIVE_ERROR: FAIL TO LOAD DATA FROM LANDING ZONE TO RAW ZONE FOR TABLE ${table_name_new}"
       rm ${log_dir}/_LANDING_TO_RAW_RUNNING
       touch ${log_dir}/_LANDING_TO_RAW_FAIL
       exit 1;
    else
       rm ${log_dir}/_LANDING_TO_RAW_RUNNING
       touch ${log_dir}/_LANDING_TO_RAW_SUCCESS
       log "HIVE_INFO: LOAD DATA FROM LANDING TO RAW FOR TABLE ${table_name_new} SUCCESFULL"
    fi
else
    #----HQL creation to load data from landing to raw
    string="SET hive.exec.dynamic.partition=true;\nSET hive.exec.dynamic.partition.mode=nonstrict;\nINSERT INTO TABLE $raw_db_name.$table_name_new partition(load_type,run_date) SELECT * ,current_timestamp as created_on,"\"DELTA"\" as load_type,'\${hiveconf:run_date}' FROM $landing_db_name.$table_name_new;"
    echo -e "$string" > ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_raw.hql
    echo -e "\n ---------LOG FOR LANDING TO RAW LOAD-------------\n" >> ${log_dir}/${table_name_new}_hive.log
    $cli -hiveconf run_date="$run_date" -f ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_raw.hql &>> ${log_dir}/${table_name_new}_hive.log
    if [ $? -ne 0 ];
    then
       echo "HIVE_ERROR: FAIL TO LOAD DATA FROM LANDING TO RAW FOR TABLE ${table_name_new}"
       rm ${log_dir}/_LANDING_TO_RAW_RUNNING
       touch ${log_dir}/_LANDING_TO_RAW_FAIL
       exit 1;
    else
       rm ${log_dir}/_LANDING_TO_RAW_RUNNING
       touch ${log_dir}/_LANDING_TO_RAW_SUCCESS
       log "HIVE_INFO: LOAD DATA FROM LANDING TO RAW FOR TABLE ${table_name_new} SUCCESSFULL"
    fi
fi