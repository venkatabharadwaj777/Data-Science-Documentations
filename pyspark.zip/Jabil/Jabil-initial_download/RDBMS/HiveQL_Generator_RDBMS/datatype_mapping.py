#!/usr/bin/python
import sys
import MySQLdb
import json
import ConfigParser
import re
#load datatype mapping json file
config = json.loads(open(str(sys.argv[8])).read())
config_precision = json.loads(open(str(sys.argv[9])).read())
#configparser obect to read mysql credential- username and password
con1= ConfigParser.ConfigParser()
mysql_credential_file1=str(sys.argv[10])
con1.readfp(open(mysql_credential_file1))
#MYSQL username,password,database name,connection string
MYUSER = con1.get('client', 'user')
MYPASS = con1.get('client', 'password')
#configparser obect to read mysql credential
con = ConfigParser.ConfigParser()
mysql_credential_file=str(sys.argv[11])
con.readfp(open(mysql_credential_file))
#MYSQL username,password,database name,connection string
connection_string= con.get('mysql_credential', 'connection_string')
MYDB = con.get('mysql_credential', 'MYDB')

#if MYUSER == "" or MYPASS == "" or MYDB == "" or connection_string == "":
if MYDB == "" or connection_string == "":
             print "Some variable is missing in mysql_credential.conf file"
             exit(1)
#Open MySQL connection 
db = MySQLdb.connect(connection_string,MYUSER,MYPASS,MYDB)
# prepare a cursor object using cursor() method
cursor = db.cursor()
# Argument list for sp_GetColumnInfo_Hive MySQL procedure 
args=[str(sys.argv[1]),str(sys.argv[2]),str(sys.argv[3]),str(sys.argv[4]),str(sys.argv[5]),str(sys.argv[6]),str(sys.argv[7])]
#print args
try:
   # Execute the MySQL procedure
   #cursor.execute(mysql)
   cursor.callproc('sp_GetColumnInfo_Hive',args)
   string=''
   # Fetch all the rows in a list of lists. 
   result = cursor.fetchall()
   if result == "":
        print "Data is not present in source_column_details for table %s , verify with source_colum_details" %(str(sys.argv[4]))
	exit(1)
   #print result 
   for row in result:
       column_name = row[0]
       data_type = row[1]
       precision_scale = row[2]
       #Removing special character from column name
       column_name = re.sub(r'[?|$|.|!|/|\\|&|%|@|-|+|*|^|#|<|>]',r' ',column_name)
       column_name = " ".join(column_name.split())
       column_name = column_name.replace(' ','_')
       data_type = data_type.lower().strip()
       if data_type in config[0]:
            string = string+'`'+column_name+'`'+' '+ config[0][data_type]+','
       elif data_type in config_precision[0]:
            string = string+'`'+column_name+'`'+' '+  config_precision[0][data_type]+'('+precision_scale+')'+','
       else:
            print "Datatype Mapping not defined for %s data_type" %(data_type)
	    exit(1)
except:
     print "Error: unable to fetch data"
     exit(1)
   
print string
# disconnect from server
cursor.close()
db.close()
