#!/bin/bash
# +===================================================================================================================================================+|
# |                                                                                                                                                    |
# | FileName    : landing_to_persistent.sh                                                                                                             |
# |                                                                                                                                                    |
# | Language    : Shell script                                                                                                                         |
# |                                                                                                                                                    |
# | Description : This script generate hql to load data from landing to persistent layer                                                               |
# +===================================================================================================================================================+|
function log() {
  log_time=$(date "+%m-%d-%Y:%H:%M:%S")
  echo -e "${log_time}" "$@">> "${log_dir}/${table_name_new}_hive.log"
}
ip_hostname=${1}
database_name=${2}
table_schema=${3}
table_name=${4}
#cdc_column_temp=${5}
table_name_new=${6}
config_filepath=${7}
log_dir=${8}
source_name=${9}
run_date=${10}
port=${11}
server_name=${12}
instance_name=${13}
logical_name=${14}
filepath=$(dirname "$config_filepath")
logged_user=$(whoami)


#--------------------------Restartability Block-------------------------------------------------------|
# check if script already succeeded for this date and for mentioned table , if it is do not run again
# if script is already running, do not start it
# if script is failed for earlier run, change the status to running and re-start the process
if [ -f "${log_dir}/_LANDING_TO_PERSISTENT_SUCCESS" ]; then
  log "HIVE_INFO: LANDING TO PERSISTENT ZONE LOAD FOR TABLE ${table_name_new} IS ALREADY COMPLETED"
  log "HIVE_INFO: SKIPPING RUN FOR TABLE: ${table_name_new}"
  exit 0
fi

if [ -f "${log_dir}/_LANDING_TO_PERSISTENT_FAIL" ]; then
  log "HIVE_WARNING: AS THIS IS RE-RUN FOR FAILED SCRIPT FOR TABLE: ${table_name_new} ,CHANGING STATUS TO RUNNING "
  rm "${log_dir}/_LANDING_TO_PERSISTENT_FAIL"
  state_change_status=$?
  if [ $state_change_status == 0 ]; then
  log "HIVE_INFO:STATUS IS CHANGED TO RUNNING"
  touch "${log_dir}/_LANDING_TO_PERSISTENT_RUNNING"
else
  log "HIVE_ERROR: FAILED TO CHANGE THE STAUS FROM FAIL TO RUNNING FOR TABLE: ${table_name_new}"
  log "HIVE_ERROR: Exiting "
  exit 1
fi
elif [ -f "${log_dir}/_LANDING_TO_PERSISTENT_RUNNING" ]; then
  log "HIVE_WARNING: AS SCRIPT IS RUNNING FOR TABLE: ${table_name_new} ,SKIPPING THE RE-RUN"
  exit 0
else
  log "HIVE_INFO: IT SEEMS IT IS FRESH RUN, MARKING STATUS AS RUNNING FOR TABLE: ${table_name_new}"
  touch "${log_dir}/_LANDING_TO_PERSISTENT_RUNNING"
  state_change_status=$?
  if [ "$state_change_status" == 0 ]; then
    log "HIVE_INFO: STATUS IS CHANGED TO RUNNING FOR TABLE: ${table_name_new}"
  fi
fi

#--------------------------------------End of Restartability Block---------------------------------------------|
#sourcing hive_config.conf file
source "${config_filepath}"
#checking does the HDFS directory exists or not if exists then we remove the files from there
#shellcheck disable=SC2091
if $(hadoop fs -test -d "${persistent_zone_path}/${source_name}/${table_name_new}/load_type=DELTA/run_date=$run_date")
then
  log "HIVE_INFO: IT IS RE-RUN FOR DATA LOAD FROM LANDING TO PERSISTENT ZONE FOR TABLE ${table_name_new}"
  hadoop fs -rm -r "${persistent_zone_path}/${source_name}/${table_name_new}/load_type=DELTA/run_date=$run_date" &>> "${log_dir}/${table_name_new}_hive.log"
  if [ $? -ne 0 ];
  then
    log "HIVE_ERROR: FAIL TO REMOVE HDFS DIRECTORY ${persistent_zone_path}/${source_name}/${table_name_new}/load_type=DELTA/run_date=$run_date"
    rm "${log_dir}/_LANDING_TO_PERSISTENT_RUNNING"
    touch "{log_dir}/_LANDING_TO_PERSISTENT_FAIL"
    exit 1;
  else
    log "HIVE_ERROR: SUCCESSFULLY REMOVED HDFS DIRECTORY ${persistent_zone_path}/${source_name}/${table_name_new}/load_type=DELTA/run_date=$run_date"
  fi
fi

if [ -f "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent.hql" ]
then
  echo -e "\n ---------LOG FOR LANDING TO PERSISTENT LOAD-------------\n" >> "${log_dir}/${table_name_new}_hive.log"
  $cli -hiveconf run_date="$run_date" -f "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent.hql" &>> "${log_dir}/${table_name_new}_hive.log"
  if [ $? -ne 0 ];
  then
    log "HIVE_ERROR: FAIL TO LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new}"
    rm "${log_dir}/_LANDING_TO_PERSISTENT_RUNNING"
    touch "${log_dir}/_LANDING_TO_PERSISTENT_FAIL"
    exit 1;
  else
    rm "${log_dir}/_LANDING_TO_PERSISTENT_RUNNING"
    touch "${log_dir}/_LANDING_TO_PERSISTENT_SUCCESS"
    log "HIVE_INFO: LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new} SUCCESSFULL"
  fi
else
  connection_string=$(grep "connection_string=" "${filepath}/${mysql_credential_file}" | cut -d'=' -f2)
  MYDB=$(grep "MYDB=" "${filepath}/${mysql_credential_file}" | cut -d'=' -f2)
  if [ ! "$MYDB" ]
  then
    log "HIVE_ERROR:SOME ARGUMNET IS MISSING IN mysql_credential.conf FILE"
    rm "${log_dir}/_LANDING_TO_PERSISTENT_RUNNING"
    touch "${log_dir}/_LANDING_TO_PERSISTENT_FAIL"
  exit 1
  fi
  #Fetching column name which are primary key
  key_old=$(mysql --defaults-file="/home/$logged_user/.mysql.cnf" -N -D "$MYDB" -h "$connection_string" -e "call sp_PrimaryKey_Hive('$ip_hostname','$port','$database_name','$table_schema','$table_name','$server_name','$instance_name')" | tr '\n' ',')
  #Removing special character in column name
  #key=$(echo "$key_old" | sed 's/[^a-zA-Z*0-9,_]/ /g;s/  */ /g;s/ *, */,/g;s/.$//')
  key_tmp=${key_old//[^a-zA-Z*0-9,_]/}
  #key_tmp1=${key_tmp// /}
  key=${key_tmp%?}
  key=(${key//,/ })
  key_length=${#key[@]}
  counter=0
  if [ $key_length == 0 ]
  then
    log "HIVE_ERROR: Primary Key Required For Incremental Load"
    rm "${log_dir}/_LANDING_TO_PERSISTENT_RUNNING"
    touch "${log_dir}/_LANDING_TO_PERSISTENT_FAIL"
    exit 1;
  else
    str1=''
    str2=''
    str3=''
    while [ $counter -lt $key_length ]
    do
      str1="$str1${key[$counter]},"
      str2="$str2 a.${key[$counter]} = b.${key[$counter]} AND"
      #str2=`echo $str2| awk '{print substr($0,1)}'`
      #echo "str2=$str2"
      str3="$str3 b.${key[$counter]} is null AND"
      #echo "str3=$str3"
      counter=$((counter+1))
    done
    str2=$(echo "$str2" | gawk '{print substr($0,1,length()-3)}')
    echo "str2=$str2"
  fi
  #str11=$(echo "$str1" | sed 's/.$//')
  temp_load_type=''
  temp_run_date=''
  #query="Select distinct b.load_type, b.run_date from $persistent_db_name.$table_name_new b, (Select distinct a.load_type as load_type, a.run_date as run_date  from $persistent_db_name.$table_name_new a inner join $landing_db_name.$table_name_new b on  $str2) a where b.load_type=a.load_type and b.run_date=a.run_date"
#echo -e "$query" > /eip_interfaces/logs/sap/${table_name_new}_delta_persistent_sal.hql
  $cli --showHeader=false --silent=true --outputformat=csv2 -e "Select distinct b.load_type, b.run_date from $persistent_db_name.$table_name_new b, (Select distinct a.load_type as load_type, a.run_date as run_date  from $persistent_db_name.$table_name_new a inner join $landing_db_name.$table_name_new b on  $str2) a where b.load_type=a.load_type and b.run_date=a.run_date" > "$log_dir/${table_name_new}_impacted_partition.txt"

  while IFS= read -r ROW
  do
    part_arr=(${ROW//,/ })
    temp_load_type="$temp_load_type\"${part_arr[0]}\"," 
    temp_run_date="$temp_run_date\"${part_arr[1]}\","
  done < "$log_dir/${table_name_new}_impacted_partition.txt"

  echo "temp_lt=$temp_load_type" 
  echo "temp_rt=$temp_run_date" 
  #load_type_str=$(echo "$temp_load_type" | sed 's/.$//')
  load_type_str=${temp_load_type%?}
  echo "1load_type_str=$load_type_str"
  
  if [[ $load_type_str == '' ]]
  then
    load_type_str='" "'
  fi
  echo "load_type_str=$load_type_str"
  #run_date_str=$(echo "$temp_run_date" | sed 's/.$//')
  run_date_str=${temp_run_date%?}
  if [[ $run_date_str == '' ]]
  then
    run_date_str='" "'
  fi
  echo "run_date=$run_date_str" 
  #creating hive query which needs to be in the double quotes
  #shellcheck disable=SC2140
  query1="CREATE TABLE IF NOT EXISTS $persistent_db_name.${table_name_new}_RT AS select i.*,current_timestamp as updated_on,"\"DELTA"\" as load_type,'\${hiveconf:run_date}' as run_date from $landing_db_name.$table_name_new i union all Select a.* from $persistent_db_name.$table_name_new a left outer join $landing_db_name.$table_name_new b on $str2 where $str3 a.load_type in (${load_type_str}) and a.run_date in (${run_date_str});"
  echo -e "$query1" > "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent_create_RT_Table.hql"

  echo -e " \n---------LOG FOR LANDING TO PERSISTENT LOAD-------------\n" >> "${log_dir}/${table_name_new}_hive.log"
  $cli -hiveconf run_date="$run_date" -f "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent_create_RT_Table.hql" &>> "${log_dir}/${table_name_new}_hive.log"
  if [ $? -ne 0 ];
  then
    log "HIVE_ERROR: FAIL TO LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new}"
    rm "${log_dir}/_LANDING_TO_PERSISTENT_RUNNING"
    touch "${log_dir}/_LANDING_TO_PERSISTENT_FAIL"
    exit 1;
  fi
  echo -e " \n----------Dropping the Impacted Partitions------------\n" >> "${log_dir}/${table_name_new}_hive.log"
  while IFS= read -r ROW
  do
    part_arr=(${ROW//,/ })
    echo ${part_arr[0]}
    echo ${part_arr[1]}
    $cli -e "alter table $persistent_db_name.$table_name_new drop partition(load_type='${part_arr[0]}',run_date='${part_arr[1]}')" &>> "${log_dir}/${table_name_new}_hive.log"
    if [ $? -ne 0 ];
    then
      log "BEELINE_ERROR: FAILED TO DROP PARTITION load_type='${part_arr[0]}' AND run_date='${part_arr[1]}'"
      rm "$log_dir/_${table_name}_RUNNING"
      touch "$log_dir/_${table_name}_FAIL"
      exit 1;
    fi
    hadoop fs -rm -r "${persistent_zone_path}/${source_name}/${table_name_new}/load_type=${part_arr[0]}/run_date=${part_arr[1]}/" &>> "${log_dir}/${table_name_new}_hive.log"
    if [ $? -ne 0 ];
    then
      log "HDFS_ERROR: FAILED TO REMOVE FILES /data/$persistent_db_name/$table_name_new/load_type={part_arr[0]}/run_date=${part_arr[1]}/ "
      rm "$log_dir/_${table_name}_RUNNING"
      touch "$log_dir/_${table_name}_FAIL"
      exit 1;
    fi
  done < "$log_dir/${table_name_new}_impacted_partition.txt"
  #making a log when there is no impacted partitions
  if [ "$(wc -l <"$log_dir/${table_name_new}_impacted_partition.txt")" -eq 0 ];then
    log "No impacted partitions to delete"
  fi
  #rm /eip_interfaces/logs/sap/${table_name_new}_unique_partition.txt

  query2="set hive.msck.path.validation=ignore;\n set hive.optimize.sort.dynamic.partition=true;\n SET hive.exec.max.dynamic.partitions.pernode=512;\n SET hive.exec.dynamic.partition=true;\nSET hive.exec.dynamic.partition.mode=nonstrict;\n set hive.optimize.skewjoin=true;\n set hive.skewjoin.key=100000;\n set hive.skewjoin.mapjoin.map.tasks=10000;\n set hive.skewjoin.mapjoin.min.split=33554432;\n set hive.exec.parallel=true;\n set hive.exec.parallel.thread.number=8;\n set hive.vectorized.execution.enabled=true;\n set hive.vectorized.execution.reduce.enabled=true;\n set hive.vectorized.execution.reduce.groupby.enabled=true;\n set hive.cbo.enable=true;\n set hive.compute.query.using.stats=true;\n set hive.stats.fetch.partition.stats=true;\n set hive.stats.fetch.column.stats=true;\n set hive.stats.autogather=true;\n set mapred.output.compress=true;\n set hive.exec.compress.output=true;\n set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;\n INSERT OVERWRITE table $persistent_db_name.$table_name_new partition(load_type,run_date) select * from $persistent_db_name.${table_name_new}_RT;\nMSCK REPAIR TABLE $persistent_db_name.$table_name_new;\n DROP TABLE IF EXISTS $persistent_db_name.${table_name_new}_RT purge;"

  echo -e "$query2" > "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent_recreate_basetable.hql"
  echo -e " \n---------LOG FOR LANDING TO PERSISTENT LOAD-------------\n" >> "${log_dir}/${table_name_new}_hive.log"
  $cli -hiveconf run_date="$run_date" -f "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent_recreate_basetable.hql" &>> "${log_dir}/${table_name_new}_hive.log"
  if [ $? -ne 0 ];
  then
    log "HIVE_ERROR: FAIL TO LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new}"
    rm "${log_dir}/_LANDING_TO_PERSISTENT_RUNNING"
    touch "${log_dir}/_LANDING_TO_PERSISTENT_FAIL"
    exit 1;
  else
    rm "${log_dir}/_LANDING_TO_PERSISTENT_RUNNING"
    touch "${log_dir}/_LANDING_TO_PERSISTENT_SUCCESS"
    log "HIVE_INFO: LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new} SUCCESSFULL"
  fi
fi

