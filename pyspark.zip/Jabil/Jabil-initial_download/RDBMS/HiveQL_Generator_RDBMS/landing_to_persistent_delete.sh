#!/bin/bash
# +===================================================================================================================================================+|
# |                                                                                                                                                    |
# | FileName    : landing_to_persistent_delete.sh                                                                                                      |
# |                                                                                                                                                    |
# | Language    : Shell script                                                                                                                         |
# |                                                                                                                                                    |
# | Description : This script generate hql to remove the harddeletes from persistent layer
# |                                                                                                                                                    |
# | Usage(example): sh /eip_interfaces/code/DIF/RDBMS/HiveQL_Generator_RDBMS/landing_to_persistent_delete.sh 172.31.233.109 HAP _SYS_BIC vbep "ZZDATE" sap_hana_ecc_ha_vbep /eip_interfaces/code/DIF/RDBMS/HiveQL_Generator_RDBMS/hive_config.conf /eip_interfaces/logs/sap/2018-05-11/sap_hana_ecc_ha/VBEP sap "2018-05-11" 33015 saphaddb 30 sap_hana_ecc_ha                                                         |
# +===================================================================================================================================================+|

function log() {
  log_time=`date "+%m-%d-%Y:%H:%M:%S"`
  echo -e "${log_time} $@" >> ${log_dir}/${table_name_new}_hive.log
}
ip_hostname=${1}
database_name=${2}
table_schema=${3}
table_name=${4}
cdc_column_temp=${5}
table_name_new=${6}
config_filepath=${7}
log_dir=${8}
source_name=${9}
run_date=${10}
port=${11}
server_name=${12}
instance_name=${13}
logical_name=${14}
filepath=$(dirname $config_filepath)
logged_user=$(whoami)

# Get the directory we're executing from
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" 
  # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"

source "${DIR}/skip_harddeletes.sh" 

#------------------------Filter The Tables For Processing-------------------------------------------|
# Below condition will exit the script when it find table in the HD_skip_list(hard delete skip table list) variable
if [[ ${HD_skip_list[*]} =~ "$table_name" ]]; then
  log "Skipping Hard deletion script for $table_name table"
  exit 0;
fi

#--------------------------Restartability Block-------------------------------------------------------|
# check if script already succeeded for this date and for mentioned table , if it is do not run again
# if script is already running, do not start it
# if script is failed for earlier run, change the status to running and re-start the process
if [ -f ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_SUCCESS ]; then
  log "HIVE_INFO: LANDING TO PERSISTENT ZONE DELETE FOR TABLE "${table_name_new}" IS ALREADY COMPLETED"
  log "HIVE_INFO: SKIPPING RUN FOR TABLE: "${table_name_new}
  exit 0
fi

if [ -f ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_FAIL ]; then
  log "HIVE_WARNING: AS THIS IS RE-RUN FOR FAILED SCRIPT FOR TABLE: "${table_name_new} ",CHANGING STATUS TO RUNNING "
  rm ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_FAIL
  state_change_status=`echo $?`
  if [ $state_change_status == 0 ]; then
    log "HIVE_INFO:STATUS IS CHANGED TO RUNNING"
    touch ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_RUNNING
  else
    log "HIVE_ERROR: FAILED TO CHANGE THE STAUS FROM FAIL TO RUNNING FOR TABLE: "${table_name_new}
    log "HIVE_ERROR: Exiting "
    exit 1
  fi
elif [ -f ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_RUNNING ]; then
  log "HIVE_WARNING: AS SCRIPT IS RUNNING FOR TABLE: "${table_name_new}" ,SKIPPING THE RE-RUN"
  exit 0
else
  log "HIVE_INFO: IT SEEMS IT IS FRESH RUN, MARKING STATUS AS RUNNING FOR TABLE: "${table_name_new}
  touch ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_RUNNING
  state_change_status=`echo $?`
  if [ $state_change_status == 0 ]; then
    log "HIVE_INFO: STATUS IS CHANGED TO RUNNING FOR TABLE: "${table_name_new}
  fi
fi

#--------------------------------------End of Restartability Block---------------------------------------------|
#sourcing hive_config.conf file
source ${config_filepath}
connection_string=`grep "connection_string=" ${filepath}/${mysql_credential_file} | cut -d'=' -f2`;
MYDB=`grep "MYDB=" ${filepath}/${mysql_credential_file} | cut -d'=' -f2`;

if [ ! "$MYDB" ]; then
  log "HIVE_ERROR:SOME ARGUMNET IS MISSING IN mysql_credential.conf FILE"
  rm ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_RUNNING
  touch ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_FAIL
  exit 1
fi

#Fetching column name which are primary key
key_old=$(mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -D$MYDB -h$connection_string -e "call sp_PrimaryKey_Hive('$ip_hostname','$port','$database_name','$table_schema','$table_name','$server_name','$instance_name')" | tr '\n' ',')
#Removing special character in column name
key=$(echo $key_old | sed 's/[^a-zA-Z*0-9,_]/ /g;s/  */ /g;s/ *, */,/g;s/.$//')
key=(${key//,/ })
echo ${key[@]}
egrep -i $table_name /eip_interfaces/code/DIF/RDBMS/Metadata_Extractor/CONTRAINT_TABLE.csv | egrep -v "FALSE" | awk '{print $3,$4}' | sort -nk2 >${log_dir}/$table_name'_Fields_order.csv'
sortkey=()
index=0
while read line; do
  field1=`echo $line | awk '{print $1}'`
  for item in "${key[@]}"; do
    [[ $field1 == "$item" ]]
  done
sortkey[index]=$field1
index=$((index+1))
done < ${log_dir}/$table_name'_Fields_order.csv'
key_length=${#sortkey[@]}
echo $key_length
counter=0
if [ $key_length == 0 ]; then
  log "HIVE_ERROR: Primary Key Required For Incremental Load"
  rm ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_RUNNING
  touch ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_FAIL
  exit 1;
else
  str1=''
  str2=''
  str3=''
  while [ $counter -lt $key_length ]
  do
  if [ ${sortkey[$counter]} != 'MANDT' ];then
    str1="$str1, b.${sortkey[$counter]}"
    str2="a.value = concat($str1) "
  fi
  counter=$((counter+1))
  done
fi
str2=$(echo "$str2" | sed 's/(,/(/')
echo $str2
str3=$(echo "$str2" | cut -d= -f2 | sed 's/b\./p\./g')
echo $str3
temp_load_type=''
temp_run_date=''
echo "$table_name_new"
echo "Query to get Impacted Partitions"
echo "select distinct b.load_type, b.run_date from landing.sap_hana_ecc_ha_zca_deletion a inner join persistent.$table_name_new b where a.ztable=UPPER('$table_name') and $str2 and a.timestamp > concat(b.zzdate,b.zztime)"

$cli --showHeader=false --silent=true --outputformat=csv2 -e "select distinct b.load_type, b.run_date from landing.sap_hana_ecc_ha_zca_deletion a inner join persistent.$table_name_new b where a.ztable=UPPER('$table_name') and $str2 and a.timestamp > concat(b.zzdate,b.zztime)" > $log_dir/${table_name_new}_impacted_partition_harddeletes.txt
if [ $? -ne 0 ]; then
  log "HIVE_ERROR: HARD DELETES - IMPACTED QUERY FAILED WITH ERROR FOR TABLE ${table_name_new}"
  rm ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_RUNNING
  touch ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_FAIL
  exit 1;
fi

log "HARD DELETES - DONE WITH FINDING IMPACTED PARTITIONS"
impacted_partition_count=`wc -l $log_dir/${table_name_new}_impacted_partition_harddeletes.txt | cut -d' ' -f1`
echo $impacted_partition_count
if [ $impacted_partition_count == 0 ];then
  log "HARD DELETES - EXITING AS THERE ARE NO IMPACTED PARTITIONS TO PROCESS FURTHER.."
  rm ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_RUNNING
  touch ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_SUCCESS
  exit 0;
fi
while IFS= read -r ROW
do
  part_arr=(${ROW//,/ })
  temp_load_type="$temp_load_type\"${part_arr[0]}\","
  temp_run_date="$temp_run_date\"${part_arr[1]}\","
done < $log_dir/${table_name_new}_impacted_partition_harddeletes.txt
echo "temp_lt=$temp_load_type"
echo "temp_rt=$temp_run_date"
load_type_str=`echo $temp_load_type | sed 's/.$//'`
echo "1load_type_str=$load_type_str"
if [[ $load_type_str == '' ]]
then
  load_type_str='" "'
fi
echo "load_type_str=$load_type_str"
run_date_str=`echo $temp_run_date | sed 's/.$//'`
if [[ $run_date_str == '' ]]
then
  run_date_str='" "'
fi
echo "run_date=$run_date_str"

echo "RT Table Query : "
echo "CREATE TABLE IF NOT EXISTS $persistent_db_name.${table_name_new}_RT AS select distinct p.* from persistent.$table_name_new p where $str3  not in (select distinct a.value  from landing.sap_hana_ecc_ha_zca_deletion a inner join $persistent_db_name.${table_name_new} b where a.ztable=UPPER('$table_name') and a.timestamp > concat(b.zzdate,b.zztime) and $str2) and p.load_type in (${load_type_str}) and p.run_date in (${run_date_str})"

query1="CREATE TABLE IF NOT EXISTS $persistent_db_name.${table_name_new}_RT AS select distinct p.* from persistent.$table_name_new p where $str3  not in (select distinct a.value  from landing.sap_hana_ecc_ha_zca_deletion a inner join $persistent_db_name.${table_name_new} b where a.ztable=UPPER('$table_name') and a.timestamp > concat(b.zzdate,b.zztime) and $str2 ) and p.load_type in (${load_type_str}) and p.run_date in (${run_date_str})";

echo -e "$query1" > ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent_create_RT_Table.hql

echo -e " \n--------- HARD DELETES - LOG FOR LANDING TO PERSISTENT LOAD-------------\n" >> ${log_dir}/${table_name_new}_hive.log
$cli -hiveconf run_date="$run_date" -f ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent_create_RT_Table.hql &>> ${log_dir}/${table_name_new}_hive.log
if [ $? -ne 0 ];
then
  log "HIVE_ERROR: HARD DELETES - FAIL TO LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new}"
  rm ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_RUNNING
  touch ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_FAIL
  exit 1;
fi
while IFS= read -r ROW
do
  part_arr=(${ROW//,/ })
  echo ${part_arr[0]}
  echo ${part_arr[1]}

  $cli -e "alter table $persistent_db_name.$table_name_new drop partition(load_type='${part_arr[0]}',run_date='${part_arr[1]}')">>${log_dir}/${table_name_new}_hive.log
  if [ $? -ne 0 ];
  then 
    log "BEELINE_ERROR: HARD DELETES - FAILED TO DROP PARTITION load_type='${part_arr[0]}' AND run_date='${part_arr[1]}'"
    rm $log_dir/_${table_name}_RUNNING
    rm ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_RUNNING
    touch ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_FAIL
    touch $log_dir/_${table_name}_FAIL
    exit 1;
  fi
  hadoop fs -rm -r ${persistent_zone_path}/${source_name}/${table_name_new}/load_type=${part_arr[0]}/run_date=${part_arr[1]}/ >>${log_dir}/${table_name_new}_hive.log
  if [ $? -ne 0 ];
  then
    log "HDFS_ERROR: HARD DELETES - FAILED TO REMOVE FILES /data/$persistent_db_name/$table_name_new/load_type={part_arr[0]}/run_date=${part_arr[1]}/ "
    rm $log_dir/_${table_name}_RUNNING
    touch $log_dir/_${table_name}_FAIL
    rm ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_RUNNING
    touch ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_FAIL
    exit 1;
  fi
done < $log_dir/${table_name_new}_impacted_partition_harddeletes.txt
#rm /eip_interfaces/logs/sap/${table_name_new}_unique_partition.txt

query2="set hive.msck.path.validation=ignore;\n set hive.optimize.sort.dynamic.partition=true;\n SET hive.exec.max.dynamic.partitions.pernode=512;\n SET hive.exec.dynamic.partition=true;\nSET hive.exec.dynamic.partition.mode=nonstrict;\n set hive.optimize.skewjoin=true;\n set hive.skewjoin.key=100000;\n set hive.skewjoin.mapjoin.map.tasks=10000;\n set hive.skewjoin.mapjoin.min.split=33554432;\n set hive.exec.parallel=true;\n set hive.exec.parallel.thread.number=8;\n set hive.vectorized.execution.enabled=true;\n set hive.vectorized.execution.reduce.enabled=true;\n set hive.vectorized.execution.reduce.groupby.enabled=true;\n set hive.cbo.enable=true;\n set hive.compute.query.using.stats=true;\n set hive.stats.fetch.partition.stats=true;\n set hive.stats.fetch.column.stats=true;\n set hive.stats.autogather=true;\n set mapred.output.compress=true;\n set hive.exec.compress.output=true;\n set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;\n INSERT OVERWRITE table $persistent_db_name.$table_name_new partition(load_type,run_date) select * from $persistent_db_name.${table_name_new}_RT;\
\nMSCK REPAIR TABLE $persistent_db_name.$table_name_new;\n DROP TABLE IF EXISTS $persistent_db_name.${table_name_new}_RT purge;"


echo -e "$query2" > ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent_recreate_basetable.hql

echo -e " \n--------- HARD DELETES - LOG FOR LANDING TO PERSISTENT LOAD-------------\n" >> ${log_dir}/${table_name_new}_hive.log
$cli -hiveconf run_date="$run_date" -f ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent_recreate_basetable.hql &>> ${log_dir}/${table_name_new}_hive.log
if [ $? -ne 0 ];
then
  log "HIVE_ERROR: HARD DELETES - FAIL TO LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new}"
  rm ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_RUNNING
  touch ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_FAIL
  exit 1;
else
  rm ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_RUNNING
  touch ${log_dir}/_LANDING_TO_PERSISTENT_DELETE_SUCCESS
  log "HIVE_INFO: HARD DELETES - LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new} SUCCESSFULL"
fi
rm ${log_dir}/$table_name'_Fields_order.csv'

