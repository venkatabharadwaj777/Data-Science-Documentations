#!/bin/bash
#################################################################################################
#											        #
#  Below is the list of tables which will be skipped from harddeletes                           #
#											        #
#################################################################################################

#Note:
#table name should be in lowercase
declare -a HD_skip_list
export HD_skip_list=( "anlz" "ekko" "ekpo" "ekbe" "likp" "link" "linp" "mard" "mkpf" "mseg" "mvke" "vbrp" "zca_deletion" "zsd_changes" "zsd_likp_change" )
