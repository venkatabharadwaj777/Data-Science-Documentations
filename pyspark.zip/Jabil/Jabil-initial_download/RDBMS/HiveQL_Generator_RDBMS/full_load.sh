#!/bin/bash
# +===================================================================================================================================================+|
# |                                                                                                                                                    |
# | FileName    : full_load.sh                                                                                                                         |
# |                                                                                                                                                    |
# | Language    : Shell script                                                                                                                         |
# |                                                                                                                                                    |
# | Description : This script generate hql for loading data from landing layer to raw and persistent layers fro FULL REFRESH tables                    |
#+====================================================================================================================================================+ |
function log() {
        log_time=`date "+%m-%d-%Y:%H:%M:%S"`
        #echo -e "${log_time} $@"
        echo -e "${log_time} $@" >> ${log_dir}/${table_name_new}_hive.log
}
table_name=${1}
table_name_new=${2}
config_filepath=${3}
log_dir=${4}
source_name=${5}
filepath=$(dirname $3)
source ${config_filepath}
run_date=${6}
server_name=${7}
instance_name=${8}
logical_name=${9}
#Condition to check all parameters
if [ $# -ne 9 ]
then
     log "Usage : sh <script name> <table_name> table_name_new> <config_filepath> <log_dir> <source_name> <run_date><server_name><instance_name> <logical_name>"
     log "For example : sh HiveDDL.sh $table_name $table_name_new $config_filepath $log_dir $source_name $run_date $server_name $instance_name ${logical_name}"
     log "HIVE_ERROR:EXITING ....."
     exit 1;
fi


#---------------INITIAL LOAD MUST PERFORM FIRST--------------------------------------------------------------------------------|
if [ ! -d "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}" ]
then
    log "HIVE_ERROR: INITIAL LOAD FOR ${table_name_new} NOT COMPLETED,FIRST LOAD INITIAL DATA" >> ${log_dir}/${table_name_new}_hive.log
    exit 1;
fi

#------------------------------------RESTARTABILITY BLOCK----------------------------------------------
# check if script already succeeded for this date and for mentioned table , if it is do not run again
# if script is already running, do not start it
# if script is failed for earlier run, change the status to running and re-start the process
if [ -f ${log_dir}/_FULL_REFRESH_SUCCESS ]; then
   log "HIVE_INFO: DELTA LOAD FROM LANDING TO RAW AND PERSISTENT ZONES FOR TABLE "${table_name_new}" IS ALREADY COMPLETED"
   log "HIVE_INFO: SKIPPING RUN FOR TABLE: "${table_name_new}
   exit 0
fi

if [ -f ${log_dir}/_FULL_REFRESH_FAIL ]; then
    log "HIVE_WARNING: AS THIS IS RE-RUN FOR FAILED SCRIPT FOR TABLE: "${table_name_new} ", CHANGING STATUS TO RUNNING "
    rm ${log_dir}/_FULL_REFRESH_FAIL
    state_change_status=`echo $?`
    if [ $state_change_status == 0 ]; then
        log "HIVE_INFO: Status is changed to running"
        touch ${log_dir}/_FULL_REFRESH_RUNNING
    else
        log "HIVE_ERROR: FAILED TO CHANGE THE STAUS FROM FAIL TO RUNNING FOR TABLE: "${table_name_new}
        log "HIVE_ERROR: EXITING "
        exit 1
    fi
elif [ -f ${log_dir}/_FULL_REFRESH_RUNNING ]; then
     log "HIVE_WARNING: AS SCRIPT IS RUNNING FOR TABLE: "${table_name_new}" ,SKIPPING THE RE-RUN"
     exit 0
else
    log "HIVE_INFO: IT SEEMS IT IS FRESH RUN, MARKING STATUS AS RUNNING FOR TABLE: "${table_name_new}
    touch ${log_dir}/_FULL_REFRESH_RUNNING
    state_change_status=`echo $?`
    if [ $state_change_status == 0 ]; then
        log "HIVE_INFO: STATUS IS CHANGED TO RUNNING FOR TABLE: "${table_name_new}
    fi
fi
#----------------------------------------------END RESTARTABILITY BLOCK---------------------------------|
#---------------------BLOCK FOR MOVING DATA FROM RAW ZONE TO RAW ARCHIVE ZONE --------------------------|
if [ -f "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_full.hql" ]
then
    if  $(hadoop fs -test -d ${raw_archive_path}/${source_name}/${table_name_new}/${run_date})
	then
	    log "HIVE_INFO: HDFS DIRECTORY ${raw_archive_path}/${source_name}/${table_name_new}/${run_date} ALREADY EXIST,SKIPPING THIS STEP......."
	    #hadoop fs -rm -r ${raw_archive_path}/${source_name}/${table_name_new}/${run_date} &>>${log_dir}/${table_name_new}_hive.log
	#if [ $? -ne 0 ];
        #then
        #   log "HIVE_ERROR: NOT ABLE TO REMOVE ${raw_archive_path}/${source_name}/${table_name_new}/${run_date}"
        #   rm ${log_dir}/_FULL_REFRESH_RUNNING
         #  touch ${log_dir}/_FULL_REFRESH_FAIL
          # exit 1;
        #else
       #    log "HIVE_INFO: SUCCESFULLY REMOVED ${raw_archive_path}/${source_name}/${table_name_new}/${run_date}"
	#fi
      else
          hadoop fs -mv ${raw_zone_path}/${source_name}/${table_name_new} ${raw_archive_path}/${source_name}/${table_name_new}/${run_date}
          if [ $? -ne 0 ];
          then
             log "HIVE_ERROR: NOT ABLE TO MOVE DATA IN ARCHIVE DIRECTORY ${raw_archive_path}/${source_name}/${table_name_new}/${run_date}"
             rm ${log_dir}/_FULL_REFRESH_RUNNING
             touch ${log_dir}/_FULL_REFRESH_FAIL
             exit 1;
          else
             log "HIVE_INFO: DATA MOVED IN ARCHIVE DIRECTORY ${raw_archive_path}/${source_name}/${table_name_new}/${run_date}"
             hadoop fs -mkdir -p ${raw_zone_path}/${source_name}/${table_name_new}
	  fi
       fi	
    
    echo -e "\n ---------LOG FOR FULL REFRESH LOAD-------------\n" >> ${log_dir}/${table_name_new}_hive.log
    $cli -f "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_full.hql" &>> ${log_dir}/${table_name_new}_hive.log
    if [ $? -ne 0 ];
    then
        log "HIVE_ERROR: FAIL TO LOAD DATA FROM LANDING TO RAW AND PERSISTENT FOR TABLE ${table_name_new}"
        rm ${log_dir}/_FULL_REFRESH_RUNNING
        touch ${log_dir}/_FULL_REFRESH_FAIL
        exit 1;
    else
        rm ${log_dir}/_FULL_REFRESH_RUNNING
        touch ${log_dir}/_FULL_REFRESH_SUCCESS
        log "HIVE_INFO: LOAD DATA FROM LANDING TO RAW AND PERSISTENT FOR TABLE ${table_name_new} SUCCESSFULL"
    fi

#-----------------------------------BLOCK FOR GENERATING HQL FOR LOADING DATA FROM LANDING TO RAW AND PERSISTENT--------------------|
else
     if ! $(hadoop fs -test -d ${raw_archive_path}/${source_name}/${table_name_new})
     then
          #----------------------RAW ARCHIVE DIRECTORY CREATION FOR TABLE
         hadoop fs -mkdir -p ${raw_archive_path}/${source_name}/${table_name_new}
         if [ $? -ne 0 ];
         then
	     log "HIVE_ERROR: NOT ABLE TO CREATE ARCHIVE DIRECTORY ${raw_archive_path}/${source_name}/${table_name_new}"
	     rm ${log_dir}/_FULL_REFRESH_RUNNING
             touch ${log_dir}/_FULL_REFRESH_FAIL
	     exit 1;
	     fi
     fi
         #----------------------MOVE DATA FROM RAW ZONE TO RAW ARCHIVE ZONE
	 hadoop fs -mv ${raw_zone_path}/${source_name}/${table_name_new} ${raw_archive_path}/${source_name}/${table_name_new}/${run_date}
	 if [ $? -ne 0 ];
         then
	     log "HIVE_ERROR: NOT ABLE TO MOVE DATA IN ARCHIVE DIRECTORY ${raw_archive_path}/${source_name}/${table_name_new}/${run_date}"
	     rm ${log_dir}/_FULL_REFRESH_RUNNING
             touch ${log_dir}/_FULL_REFRESH_FAIL
	     exit 1;
    else
         log "HIVE_INFO: DATA MOVED IN ARCHIVE DIRECTORY ${raw_archive_path}/${source_name}/${table_name_new}/${run_date}"
    fi
     #----------------------------------FULL LOAD QUERY GENERATION
     string="FROM $landing_db_name.$table_name_new\nINSERT OVERWRITE TABLE $raw_db_name.$table_name_new SELECT * ,current_timestamp as created_on\nINSERT OVERWRITE TABLE $persistent_db_name.$table_name_new  SELECT * , current_timestamp as updated_on;"
     echo -e "$string" > ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_full.hql
     echo -e "\n ---------LOG FOR FULL REFRESH LOAD-------------\n" >> ${log_dir}/${table_name_new}_hive.log
     $cli -f "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_full.hql" &>> ${log_dir}/${table_name_new}_hive.log
     if [ $? -ne 0 ];
     then
        log "HIVE_ERROR: FAIL TO LOAD DATA FROM LANDING TO RAW AND PERSISTENT FOR TABLE ${table_name_new}"
        rm ${log_dir}/_FULL_REFRESH_RUNNING
        touch ${log_dir}/_FULL_REFRESH_FAIL
        exit 1;
     else
         rm ${log_dir}/_FULL_REFRESH_RUNNING
         touch ${log_dir}/_FULL_REFRESH_SUCCESS
         log "HIVE_INFO: LOAD DATA FROM LANDING TO RAW AND PERSISTENT FOR TABLE ${table_name_new} SUCCESSFULL"
     fi
fi