#!/bin/bash
# +===================================================================================================================================================+|
# |                                                                                                                                                    |
# | FileName    : initial_load.sh                                                                                                                      |
# |                                                                                                                                                    |
# | Language    : Shell script                                                                                                                         |
# |                                                                                                                                                    |
# | Description : This script generate script for initial load                                                                                         |
# |                                                                                                                                                    |
# +====================================================================================================================================================+
#----------------------------------Log Function----------------------------------
function log() {
        log_time=`date "+%m-%d-%Y:%H:%M:%S"`
        #echo -e "${log_time} $@"
        echo -e "${log_time} $@" >> ${log_dir}/${table_name_new}_hive.log
}
table_name=${1}
config_filepath=${2}
filepath=$(dirname $config_filepath)
table_name_new=${3}
load_type=${4}
create_DDL=${5}
log_dir=${6}
source_name=${7}
run_date=${8}
server_name=${9}
instance_name=${10}
logical_name=${11}
source $config_filepath

if [ $# -ne 11 ];then
        log "Usage : sh <script name> <table_name> <config_file> <table_name_new> <load_type> <create_DDL> <log_dir> <source_name> <run_date> <server_name> <instance_name> <logical_name>"
        log "For example : sh initial_load.sh $table_name $config_file $table_name_new $load_type $create_DDL $log_dir $source_name $run_date $server_name $instance_name $logical_name"
	exit 1;
fi
#-----------------------------RESTARTABILITY BLOCK-----------------------------------------------------------|
# check if script already succeeded for this date and for mentioned table , if it is do not run again
# if script is already running, do not start it
# if script is failed for earlier run, change the status to running and re-start the process
if [ -f ${log_dir}/_INITIAL_SUCCESS ]; then
   log "HIVE_INFO: INITIAL LOAD FOR TABLE "${table_name_new}" IS ALREADY COMPLETED"
   log "HIVE_INFO: SKIPPING RUN FOR TABLE: "${table_name_new}
   exit 0
fi

if [ -f ${log_dir}/_INITIAL_FAIL ]; then
    log "HIVE_WARNING: AS THIS IS RE-RUN FOR FAILED SCRIPT FOR TABLE: "${table_name_new} ",CHANGING STATUS TO RUNNING "
    rm ${log_dir}/_INITIAL_FAIL
    state_change_status=`echo $?`
    if [ $state_change_status == 0 ]; then
        log "HIVE_INFO: STATUS IS CHANGED TO RUNNING"
        touch ${log_dir}/_INITIAL_RUNNING
    else
        log "HIVE_ERROR: FAILED TO CHANGE THE STAUS FROM FAIL TO RUNNING FOR TABLE: "${table_name_new}
        log "HIVE_ERROR: EXITING ....."
        exit 1
    fi
elif [ -f ${log_dir}/_INITIAL_RUNNING ]; then
     log "HIVE_WARNING: AS SCRIPT IS RUNNING FOR TABLE: "${table_name_new}" ,SKIPPING THE RE-RUN"
     exit 0
else
    log "HIVE_INFO: IT SEEMS IT IS FRESH RUN, MARKING STATUS AS RUNNING FOR TABLE: "${table_name_new}
    touch ${log_dir}/_INITIAL_RUNNING
    state_change_status=`echo $?`
    if [ $state_change_status == 0 ]; then
        log "HIVE_INFO:STATUS IS CHANGED TO RUNNING FOR TABLE: "${table_name_new}
    fi
fi

#-----------------END OF RESTARTABILTY BLOCK-----------------------------------------------------------|

if [ "${create_DDL}" == "Y" ]
then
    if [ "${load_type}" == "FR" ]
    then
        if $(hadoop fs -test -d ${raw_zone_path}/${source_name}/${table_name_new})
        then 
             log "HIVE_INFO: IT IS RE-RUN FOR INITIAL LOAD FROM LANDING TO RAW ZONE FOR TABLE ${table_name_new}"
             hadoop fs -rm -r ${raw_zone_path}/${source_name}/${table_name_new} &>>${log_dir}/${table_name_new}_hive.log
	     if [ $? -ne 0 ];
             then
                log "HIVE_ERROR: FAIL TO REMOVE HDFS DIRECTORY ${raw_zone_path}/${source_name}/${table_name_new}"
                rm ${log_dir}/_INITIAL_RUNNING
                touch ${log_dir}/_INITIAL_FAIL
                exit 1;
	      else
                 log "HIVE_INFO:SUCCESSFULLY REMOVED HDFS DIRECTORY ${raw_zone_path}/${source_name}/${table_name_new}"
              fi
    	fi
        if $(hadoop fs -test -d ${persistent_zone_path}/${source_name}/${table_name_new})
        then
	     log "HIVE_INFO: IT IS RE-RUN FOR INITIAL LOAD FROM LANDING TO PERSISTENT ZONE FOR TABLE ${table_name_new}"
             hadoop fs -rm -r ${persistent_zone_path}/${source_name}/${table_name_new} &>>${log_dir}/${table_name_new}_hive.log
	     if [ $? -ne 0 ];
             then
                log "HIVE_ERROR: FAIL TO REMOVE HDFS DIRECTORY ${persistent_zone_path}/${source_name}/${table_name_new}"
                rm ${log_dir}/_INITIAL_RUNNING
                touch ${log_dir}/_INITIAL_FAIL
                exit 1;
	     else
                 log "HIVE_INFO:SUCCESSFULLY REMOVED HDFS DIRECTORY ${persistent_zone_path}/${source_name}/${table_name_new}"
             fi
    	fi
		#------------Writing hql statement in file for full refresh tables-----------------------------------------------------|
        string="FROM $landing_db_name.$table_name_new\nINSERT OVERWRITE TABLE $raw_db_name.$table_name_new SELECT * ,current_timestamp as created_on\nINSERT OVERWRITE table $persistent_db_name.$table_name_new  SELECT * , current_timestamp as updated_on;"
	echo -e "$string" > ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_initial.hql
    	
    elif [ "${load_type}" == "D" ]
    then
        
        if $(hadoop fs -test -d ${raw_zone_path}/${source_name}/${table_name_new})
        then 
             log "HIVE_INFO: IT IS RE-RUN FOR INCOMPLETE INITIAL LOAD FROM LANDING TO RAW ZONE FOR TABLE ${table_name_new}"
             hadoop fs -rm -r ${raw_zone_path}/${source_name}/${table_name_new} &>>${log_dir}/${table_name_new}_hive.log
	     if [ $? -ne 0 ];
             then
                log "HIVE_ERROR: FAIL TO REMOVE HDFS DIRECTORY ${raw_zone_path}/${source_name}/${table_name_new}"
                rm ${log_dir}/_INITIAL_RUNNING
                touch ${log_dir}/_INITIAL_FAIL
                exit 1;
	     else
                 log "HIVE_INFO:SUCCESSFULLY REMOVED HDFS DIRECTORY ${raw_zone_path}/${source_name}/${table_name_new}"    
             fi
    	fi
        if $(hadoop fs -test -d ${persistent_zone_path}/${source_name}/${table_name_new})
        then
            log "HIVE_INFO: IT IS RE-RUN FOR INCOMPLETE INITIAL LOAD FROM LANDING TO PERSISTENT ZONE FOR TABLE ${table_name_new}"
            hadoop fs -rm -r ${persistent_zone_path}/${source_name}/${table_name_new} &>>${log_dir}/${table_name_new}_hive.log
	    if [ $? -ne 0 ];
            then
                log "HIVE_ERROR: FAIL TO REMOVE HDFS DIRECTORY ${persistent_zone_path}/${source_name}/${table_name_new}"
                rm ${log_dir}/_INITIAL_RUNNING
                touch ${log_dir}/_INITIAL_FAIL
                exit 1;
	    else
                 log "HIVE_INFO:SUCCESSFULLY REMOVED HDFS DIRECTORY ${persistent_zone_path}/${source_name}/${table_name_new}"     
            fi
    	fi
    #------------Writing hql statement in file for partition tables-----------------------------------------------------|
    string="SET hive.exec.dynamic.partition=true;\nSET hive.exec.dynamic.partition.mode=nonstrict;\nFROM $landing_db_name.$table_name_new\nINSERT OVERWRITE table $raw_db_name.$table_name_new partition(load_type,run_date) SELECT * ,current_timestamp as created_on,"\"INITIAL"\" as load_type,'\${hiveconf:run_date}'\nINSERT OVERWRITE table $persistent_db_name.$table_name_new partition(load_type,run_date) SELECT * , current_timestamp as updated_on,"\"INITIAL"\"  as load_type,'\${hiveconf:run_date}';"
    echo -e "$string" > ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_initial.hql
    elif [ "${load_type}" == "F-D" ]
    then
         #Renaming RAW directory structure corresponding to partition directories structure 
         if $(hadoop fs -test -d ${raw_zone_path}/${source_name}/${table_name_new})
         then
             hadoop fs -mv ${raw_zone_path}/${source_name}/${table_name_new} ${raw_zone_path}/${source_name}/${table_name_new}_temp
    	     hadoop fs -mkdir -p ${raw_zone_path}/${source_name}/${table_name_new}/load_type=INITIAL
    	     hadoop fs -mv ${raw_zone_path}/${source_name}/${table_name_new}_temp ${raw_zone_path}/${source_name}/${table_name_new}/load_type=INITIAL/run_date=${run_date}
    	 else
             log "HIVE_ERROR:${raw_zone_path}/${source_name}/${table_name_new} NOT PRESENT,CHECK HDFS DIRECTORY "
             rm ${log_dir}/_INITIAL_RUNNING
             touch ${log_dir}/_INITIAL_FAIL
             exit 1;
         fi
          #Renaming PERSISTENT directory structure corresponding to partition directories structure
         if $(hadoop fs -test -d ${persistent_zone_path}/${table_name_new})
         then
    	     hadoop fs -mv ${persistent_zone_path}/${source_name}/${table_name_new} ${persistent_zone_path}/${source_name}/${table_name_new}_temp
    	     hadoop fs -mkdir -p ${persistent_zone_path}/${source_name}/${table_name_new}/load_type=INITIAL
    	     hadoop fs -mv ${persistent_zone_path}/${source_name}/${table_name_new}_temp ${persistent_zone_path}/${source_name}/${table_name_new}/load_type=INITIAL/run_date=${run_date}
         else
             log "HIVE_ERROR:${persistent_zone_path}/${source_name}/${table_name_new} NOT PRESENT,CHECK HDFS DIRECTORY "
             rm ${log_dir}/_INITIAL_RUNNING
             touch ${log_dir}/_INITIAL_FAIL
             exit 1;
         fi
          # Repair hive metadata 
		  echo "MSCK REPAIR TABLE ${raw_db_name}.${table_name_new};MSCK REPAIR TABLE ${persistent_db_name}.${table_name_new}; " > ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_initial.hql
    else
         log "HIVE_ERROR: LOAD TYPE IS NOT CORRECTLY POPULATED FROM METADATA TABLE"
         rm ${log_dir}/_INITIAL_RUNNING
         touch ${log_dir}/_INITIAL_FAIL
         exit 1;	  
    fi
elif [ "${create_DDL}" == "YC" ] || [ "${create_DDL}" == "YR" ]
then
    echo "MSCK REPAIR TABLE ${raw_db_name}.${table_name_new};MSCK REPAIR TABLE ${persistent_db_name}.${table_name_new}" > ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_initial.hql
else 
    log "HIVE_ERROR: CREATE_DDL VALUE IS NOT CORRECT,CHECK METADATA TABLE SOURCE_COLUMN_DETAILS FOR TABLE ${table_name_new}"
    rm ${log_dir}/_INITIAL_RUNNING
    touch ${log_dir}/_INITIAL_FAIL
    exit 1;
fi
echo -e "\n ---------LOG FOR INITIAL LOAD-------------\n" >> ${log_dir}/${table_name_new}_hive.log

if [ "${load_type}" == "FR" ]
then
    $cli -f ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_initial.hql &>>  ${log_dir}/${table_name_new}_hive.log
else
    $cli -hiveconf run_date="$run_date" -f ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_initial.hql &>>  ${log_dir}/${table_name_new}_hive.log
fi
echo $?
if [ $? -ne 0 ];
then
     log "HIVE_ERROR: FAIL TO INITIAL LOAD FOR TABLE ${table_name_new}"
     rm ${log_dir}/_INITIAL_RUNNING
     touch ${log_dir}/_INITIAL_FAIL
     exit 1;
else
    rm ${log_dir}/_INITIAL_RUNNING
    touch ${log_dir}/_INITIAL_SUCCESS
    log "HIVE_INFO: INITIAL LOAD SUCCESSFULL FOR TABLE ${table_name_new}"
fi