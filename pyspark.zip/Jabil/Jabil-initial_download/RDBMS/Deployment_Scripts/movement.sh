#!/bin/bash
# movement.sh
# Copyright (c) 2019 Jabil Inc
# Create tables in Spend_Analytics database

if [[ ${USER} == 'root' ]]; then
  echo "This program must be executed by the service account."
fi

# Get the directory we're executing from
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
DIR2="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"

# Run the common code across all install files.
. "${DIR2}/../Operational_RDBMS/common.sh"

# Diplay the internal parameters.
echo "Use Case:        ${USECASE}"
echo "Cluster:         ${CLUSTER}"
echo "Account:         ${ACCOUNT}"
echo "Administrator:   ${ADMIN}"
echo "Admins:          ${ADM_GROUP}"
echo "Read-Only:       ${READ_GROUP}"
echo "Support:         ${SUPPORT_GROUP}"
echo "DB Type:         ${DB_TYPE}"
echo "Directory:       ${DIR2}"

if [[ ${DISPLAYHELP} == "X" ]]; then
  echo "This install.sh program must be executed by the DIF service accont."
  exit 0
fi

# Turn on echo
set -x

if [[ ${DISPLAYHELP} == "" ]]; then
  # Establish a Kerberos ticket.
  kinit "${ADMIN}@CORP.JABIL.ORG" -k -t "/eip_interfaces/${ACCOUNT}/.misc/${ACCOUNT}.keytab" -V

  # Create movement Tables in Spend_analytics Database
  impala-shell -k --ssl -i "hadoop${CLUSTER}.corp.jabil.org" -f "${DIR2}/spend_analytics_movement.hql"
  impala-shell -k --ssl -i "hadoop${CLUSTER}.corp.jabil.org" -f "${DIR2}/spend_analytics_stg_rep_upsert_movement.hql"
  impala-shell -k --ssl -i "hadoop${CLUSTER}.corp.jabil.org" -f "${DIR2}/spend_analytics_temp_delta_table_movement.hql"
fi

# Turn off echo
set +x
