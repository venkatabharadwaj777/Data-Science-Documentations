#!\bin\bash
# DataExtraction.sh
# Copyright (c) 2019 Jabil Inc.
#
# Script to extract data from the database and create csv files
# To run the script we need to pass 7 parameters mentioned below

#Type of database system you are using
Server_Name=$1
#Instance_Name of the SQL Database
Instance_Name=$2
#IP/Hostname of the SQL Database
IP_Hostname=$3
#Port Number of the SQL Database
PORT_Name=$4
#Database Name of the SQL Database
DB_Name=$5
#Schema Name of the SQL Database
Schema_Name=$6
#Type of database 
DB_Type=$7
Logical_Name=$8
Table_Name=$9

logged_user=$(whoami)

echo "Parameters for DataExtration.sh"
echo "Parameter 1 - Server Name:   $Server_Name" 
echo "Parameter 2 - Instance Name: $Instance_Name" 
echo "Parameter 3 - IP Hostname:   $IP_Hostname" 
echo "Parameter 4 - Port Name:     $PORT_Name"  
echo "Parameter 5 - DB Name:       $DB_Name" 
echo "Parameter 6 - Schema Name:   $Schema_Name" 
echo "Parameter 7 - DB Type:       $DB_Type"
echo "Parameter 8 - Logical Name:  $Logical_Name"
echo "Parameter 9 - Table Name:    $Table_Name"

# Check whether number of parameters passed to DataExtraction.sh are 8 or 9
echo "Check whether number of parameters passed are 8 or 9"
if [[ "$#" -ne 8 ]];
  then if [[ "$#" -ne 9 ]];
    then echo "Incorrect number of parameters Passed: $#"
    exit 1; 
  fi
fi

if [[ "${Table_Name}" != "" ]]; then 
  Table_File_Name="${Logical_Name}_${Table_Name}"
else
  Table_File_Name="${Logical_Name}"
fi
echo "Table File Name:             ${Table_File_Name}"
echo "Directory Path:              ${dirpath1}"

# Get the directory we're executing from
export SOURCE="${BASH_SOURCE[0]}"
while [ -h "${SOURCE}" ]; do # resolve $SOURCE until the file is no longer a symlink
  export DIR="$( cd -P $( dirname ${SOURCE} ) > /dev/null 2>&1 && pwd )"
  export SOURCE="$(readlink ${SOURCE})"
  # if $SOURCE was a relative symlink, we need to resolve it relative to the path 
  # where the symlink file was located
  [[ $SOURCE != /* ]] && SOURCE="${DIR}/${SOURCE}" 
done
export DIR="$( cd -P "$( dirname "${SOURCE}" )" >/dev/null 2>&1 && pwd )"

# Get the parameters from a file
source "${DIR}/IP_Parameter_File.txt"

#Details for  MySQL Database Connection
MYSQL_DB_NAME=$databasename
echo "MySQL Database:              ${MYSQL_DB_NAME}"

#check if all the arguments are passed to call stored procedure

if [ "$MYSQL_DB_NAME" == ' ' ]
then 
  echo "please pass proper arguments to call the stored procedure"
	exit 1;	
else 
	
  #Call Stored Procedure to fetch Database details
  echo "mysql --defaults-file=/home/${logged_user}/.mysql.cnf -N -D${MYSQL_DB_NAME} -h${IP_Instance} -e\"call sp_GetDatabaseInfo_Sqoop('${IP_Hostname}','${PORT_Name}','${DB_Name}','${Schema_Name}','${Server_Name}','${Instance_Name}') \""

  DB_Details=$(mysql --defaults-file="/home/${logged_user}/.mysql.cnf" -N -D"${MYSQL_DB_NAME}" -h"${IP_Instance}" -e"call sp_GetDatabaseInfo_Sqoop('${IP_Hostname}','${PORT_Name}','${DB_Name}','${Schema_Name}','${Server_Name}','${Instance_Name}')")

        
  echo "Stored procedure called Successfully"
  #Storing above Details in an Array
  DB_Details_Arr=(${DB_Details// / }) 
  # Just want to output this
  #shellcheck disable=SC2128
  echo "${DB_Details_Arr}"
  #SQL UserName
  DB_USER=${DB_Details_Arr[7]}
  echo "DB User:                     ${DB_USER}"
  #SQL Password
  DB_PWD=${DB_Details_Arr[8]}
  echo $DB_PWD
        
  #check if all the arguments are passed
  if [ "${DB_USER}" == ' ' ] || [ "${DB_PWD}" == ' ' ] 
  then 
	  echo "please pass proper arguments"
    exit 1;		
  fi
fi

# calling the config file depending on the database type
source "${DIR}/${DB_Type}/${Table_File_Name}.conf"

#For CREATING FILE 1 which contains data from sqlserver
hadoop fs -test -d "${dirpath1}"
if [ $? == 0 ]
then 
  hadoop fs -rmr "${dirpath1}"
fi    
if [ -f "${output_file1}" ]
then 
  rm "${output_file1}"
fi
echo "sqoop import --connect \"$connection\" --username $DB_USER --password-file file:///home/$logged_user/$DB_Name.password --query \"$query1\"  -m 1 --target-dir $dirpath1 --fields-terminated-by '$delimiter' --driver $Driver" > "${File_PATH}/file1.sh"
sh "${File_PATH}/file1.sh"
if [ $? == 0 ]
then
  hadoop fs -copyToLocal "${dirpath1}/part*" "${output_file1}"
  echo "Table_Metadata_Output file created in the output folder"
fi

#For CREATING FILE 2 which contains data from sqlserver
hadoop fs -test -d "${dirpath2}"
if [ $? == 0 ]
then 
  hadoop fs -rmr "${dirpath2}"
fi
if [ -f "${output_file2}" ]
then 
  rm "${output_file2}"
fi
echo "sqoop import --connect \"$connection\" --username $DB_USER --password-file file:///home/$logged_user/$DB_Name.password --query \"$query2 \"  -m 1 --target-dir $dirpath2 --fields-terminated-by '$delimiter' --driver $Driver" > "${File_PATH}/file2.sh"
sh "${File_PATH}/file2.sh"
if [ $? == 0 ]
then
  echo "hadoop fs -copyToLocal /data/landing/metadata/file2/part-m-00000 ${output_file2}"
  hadoop fs -copyToLocal "${dirpath2}/part*" "${output_file2}"
  echo "Column_Metadata_output file created in the output folder"
fi

          
#For CREATING FILE 3 which contains data from sqlserver
hadoop fs -test -d "${dirpath3}"
if [ $? == 0 ]
then 
  hadoop fs -rmr "${dirpath3}"
fi
if [ -f "${output_file3}" ]
then 
  rm "${output_file3}"
fi
echo "sqoop import --connect \"$connection\" --username $DB_USER --password-file file:///home/$logged_user/$DB_Name.password --query \"$query3 \"  -m 1 --target-dir $dirpath3 --fields-terminated-by '$delimiter' --driver $Driver" > "${File_PATH}/file3.sh"
sh "${File_PATH}/file3.sh"
if [ $? == 0 ]
then
  echo "hadoop fs -copyToLocal /data/landing/metadata/file3/part-m-00000 ${output_file3}"
  hadoop fs -copyToLocal "${dirpath3}/part*" "${output_file3}"
  echo "staging_Table file created in the output folder" 
fi

#checking for empty files if any
count=$(wc -l < "${output_file1}")
count1=$(wc -l < "${output_file2}")
count2=$(wc -l < "${output_file3}")	
# gt 1 will not work if we extract only one table. Changing it to gt 0 -- RL
# if [ $? == 0 ] && [ $count -gt 1 ] && [ $count1 -gt 1 ] && [ $count2 -gt 1 ]
if [ $? == 0 ] && [ "$count" -gt 0 ] && [ "$count1" -gt 0 ] && [ "$count2" -gt 0 ]
then
  #touch $TouchFile_Location/_METADATA_EXTRACT_SUCCESS
  exit 0
else
  #touch $TouchFile_Location/_METADATA_EXTRACT_FAIL
	echo "Metadata Extractor Failed to extract data from database"
  exit 1
fi
#echo "files extracted successfully"

   
