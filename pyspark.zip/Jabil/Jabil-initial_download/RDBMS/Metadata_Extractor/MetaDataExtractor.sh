#!/bin/bash
#Script to run Java code which is used to query and fetch data from RDBMS and store the output in a CSV file.

# Get the directory we're executing from
export SOURCE="${BASH_SOURCE[0]}"
while [ -h "${SOURCE}" ]; do # resolve $SOURCE until the file is no longer a symlink
  export DIR="$( cd -P $( dirname ${SOURCE} ) > /dev/null 2>&1 && pwd )"
  export SOURCE="$(readlink ${SOURCE})"
  # if $SOURCE was a relative symlink, we need to resolve it relative to the path 
  # where the symlink file was located
  [[ $SOURCE != /* ]] && SOURCE="${DIR}/${SOURCE}" 
done
export DIR="$( cd -P "$( dirname "${SOURCE}" )" >/dev/null 2>&1 && pwd )"

# Get the parameters from a file
source "${DIR}/IP_Parameter_File.txt"

#Name of the SQL Database  
#Server_Name of the SQL Database
#Server_Name=$1
#Instance_Name of the SQL Database
#Instance_Name=$2
#IP/Hostname of the SQL Database
#IP_Hostname=$3
#Port Number of the SQL Database
#PORT_Name=$4
#Database Name of the SQL Database
#DB_Name=$5
#Schema Name of the SQL Database
#Schema_Name=$6
#logican name
Logical_Name=$1
#type of database
DB_Type=$2
Source=$3
DB_Name=$4
Table_Name=$5
logged_user=$(whoami)

echo "Parameters for MetaDataExtractor.sh"
echo "Parameter 1 - Logical Name:    ${Logical_Name}"
echo "Parameter 2 - DB Type:         ${DB_Type}"
echo "Parameter 3 - Source:          ${Source}" 
echo "Parameter 4 - DB Name:         ${DB_Name}" 
echo "Parameter 5 - Table Name:      ${Table_Name}"
echo "."
echo "Parameters read from ${DIR}/IP_Parameter_File.txt:"
echo "Server Name:     ${Server_Name}" 
echo "Instance Name:   ${Instance_Name}" 
echo "IP Hostname:     ${IP_Hostname}" 
echo "Port Name:       ${PORT_Name}"  
echo "Schema Name:     ${Schema_Name}" 
echo "."
echo "Automatically determined parameters:"
echo "Logged-in User:    ${logged_user}"
echo "Runtime Directory: ${DIR}"

#echo "$Server_Name" "$Instance_Name" "$IP_Hostname" "$PORT_Name"  "$DB_Name" "$Schema_Name" "DB_Type"
#echo "$Logical_Name $DB_Type $Source $DB_Name"
if [ "${Logical_Name}" == '' ] || [ "${DB_Type}" == '' ] || [ "${DB_Name}" == '' ] || [ "${Source}" == '' ] 
then
  echo "Please pass all expected arguments to call the Script!!" 
  touch "${TouchFile_Location}/_METADATA_EXTRACT_FAIL"
  exit 1;
else 
  echo "Parameter passed Successfully"
fi 

#Details for  MySQL Database Connection
MySQL Database Name 
MYSQL_DB_NAME=$databasename
	
#Call Stored Procedure to fetch Database details
echo $Logical_Name
DB_Details=$(mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -D$MYSQL_DB_NAME -h$IP_Instance -e"call sp_GetDatabaseInfo_Sqoop1('$Logical_Name')")
echo "DB Details:    ${DB_Details}"
if [ $? == 0 ]
then
  echo "Stored procedure called Successfully"
else
  touch "${TouchFile_Location}/_METADATA_EXTRACT_FAIL"
  exit 1
fi

#Storing above Details in an Array
SQL_DB_Details_Arr=(${DB_Details// / }) 
#SQL UserName
SQL_DB_USER=${SQL_DB_Details_Arr[7]}
#SQL Password
SQL_DB_PWD=${SQL_DB_Details_Arr[8]}
#echo "$SQL_DB_USER"
echo "SQL DB User and Password Retrieved..."
Server_Name=${SQL_DB_Details_Arr[1]}
echo "Server Name:   $Server_Name"
Instance_Name=${SQL_DB_Details_Arr[2]}
echo "Instance Name: $Instance_Name"
IP_Hostname=${SQL_DB_Details_Arr[0]}
echo "IP Hostname:   $IP_Hostname"
PORT_Name=${SQL_DB_Details_Arr[3]}
echo "Port Name:     $PORT_Name"
Schema_Name=${SQL_DB_Details_Arr[5]}
echo "Schema Name:   $Schema_Name"

# calling the script to generate files
echo "sh ${DIR}/DataExtraction.sh ${Server_Name} ${Instance_Name} ${IP_Hostname} ${PORT_Name} ${DB_Name} ${Schema_Name} ${DB_Type} ${Logical_Name} ${Table_Name}"

sh ./DataExtraction.sh $Server_Name $Instance_Name "${IP_Hostname}" "${PORT_Name}" "${DB_Name}" "${Schema_Name}" "${DB_Type}" "${Logical_Name}" "${Table_Name}"
if [ $? != 0 ] ; then
  touch "${TouchFile_Location}/_DATA_EXTRACTION_FAIL"
  touch "${TouchFile_Location}/_METADATA_EXTRACT_FAIL"
  exit 1
else
  touch "${TouchFile_Location}/_DATA_EXTRACTION_SUCCESS"
fi
 
#calling the script to load data from files to mysql 
echo "metdata:sQl"
sh MySQL_Import.sh "${DB_Type}" "${DB_Name}" "${Logical_Name}" "${Table_Name}"
if [ $? == 0 ]
then
  touch "${TouchFile_Location}/_MYSQL_IMPORT_SUCCESS"
  $(mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -D$MYSQL_DB_NAME -h$IP_Instance -e"call sp_updateSourceTableDetails('$Server_Name','$Instance_Name','$DB_Name','$Schema_Name')");
  $(mysql --defaults-file=/home/$logged_user/.mysql.cnf -N -D$MYSQL_DB_NAME -h$IP_Instance -e"update source_table_details set source='$Source' where database_name='$DB_Name';");
  echo "MySQL importing Done"
  touch "${TouchFile_Location}/_METADATA_EXTRACT_SUCCESS"
else
  touch "${TouchFile_Location}/_MYSQL_IMPORT_FAIL"
  echo "MySQL Importing failed to load the data"
  touch "${TouchFile_Location}/_METADATA_EXTRACT_FAIL"
  exit 1
fi
