#!/bin/bash
# +===================================================================================================================================================+|
# |                                                                                                                                                    |
# | FileName    : landing_to_persistent.sh                                                                                                             |
# |                                                                                                                                                    |
# | Language    : Shell script                                                                                                                         |
# |                                                                                                                                                    |
# | Description : This script generate hql to load data from landing to persistent layer                                                               |
# +===================================================================================================================================================+|
function log() {
        log_time=`date "+%m-%d-%Y:%H:%M:%S"`
        #echo -e "${log_time} $@"
        echo -e "${log_time} $@" >> ${log_dir}/${table_name_new}_hive.log
}
ip_hostname=${1}
database_name=${2}
table_schema=${3}
table_name=${4}
cdc_column=${5}
table_name_new=${6}
config_filepath=${7}
log_dir=${8}
source_name=${9}
run_date=${10}
port=${11}
server_name=${12}
instance_name=${13}
logical_name=${14}
filepath=$(dirname $config_filepath)

#--------------------------Restartability Block-------------------------------------------------------|
# check if script already succeeded for this date and for mentioned table , if it is do not run again
# if script is already running, do not start it
# if script is failed for earlier run, change the status to running and re-start the process
if [ -f ${log_dir}/_LANDING_TO_PERSISTENT_SUCCESS ]; then
   log "HIVE_INFO: LANDING TO PERSISTENT ZONE LOAD FOR TABLE "${table_name_new}" IS ALREADY COMPLETED"
   log "HIVE_INFO: SKIPPING RUN FOR TABLE: "${table_name_new}
   exit 0
fi

if [ -f ${log_dir}/_LANDING_TO_PERSISTENT_FAIL ]; then
    log "HIVE_WARNING: AS THIS IS RE-RUN FOR FAILED SCRIPT FOR TABLE: "${table_name_new} ",CHANGING STATUS TO RUNNING "
    rm ${log_dir}/_LANDING_TO_PERSISTENT_FAIL
    state_change_status=`echo $?`
    if [ $state_change_status == 0 ]; then
        log "HIVE_INFO:STATUS IS CHANGED TO RUNNING"
        touch ${log_dir}/_LANDING_TO_PERSISTENT_RUNNING
    else
        log "HIVE_ERROR: FAILED TO CHANGE THE STAUS FROM FAIL TO RUNNING FOR TABLE: "${table_name_new}
        log "HIVE_ERROR: Exiting "
        exit 1
    fi
elif [ -f ${log_dir}/_LANDING_TO_PERSISTENT_RUNNING ]; then
     log "HIVE_WARNING: AS SCRIPT IS RUNNING FOR TABLE: "${table_name_new}" ,SKIPPING THE RE-RUN"
     exit 0
else
    log "HIVE_INFO: IT SEEMS IT IS FRESH RUN, MARKING STATUS AS RUNNING FOR TABLE: "${table_name_new}
    touch ${log_dir}/_LANDING_TO_PERSISTENT_RUNNING
    state_change_status=`echo $?`
    if [ $state_change_status == 0 ]; then
        log "HIVE_INFO: STATUS IS CHANGED TO RUNNING FOR TABLE: "${table_name_new}
    fi
fi

#--------------------------------------End of Restartability Block---------------------------------------------|
#sourcing hive_config.conf file
source ${config_filepath}

if $(hadoop fs -test -d ${persistent_zone_path}/${source_name}/${table_name_new}/load_type=DELTA/run_date=$run_date)
then 
    log "HIVE_INFO: IT IS RE-RUN FOR DATA LOAD FROM LANDING TO PERSISTENT ZONE FOR TABLE ${table_name_new}"
    hadoop fs -rm -r ${persistent_zone_path}/${source_name}/${table_name_new}/load_type=DELTA/run_date=$run_date &>> ${log_dir}/${table_name_new}_hive.log
    if [ $? -ne 0 ];
    then
        log "HIVE_ERROR: FAIL TO REMOVE HDFS DIRECTORY ${persistent_zone_path}/${source_name}/${table_name_new}/load_type=DELTA/run_date=$run_date"
        rm ${log_dir}/_LANDING_TO_PERSISTENT_RUNNING
        touch ${log_dir}/_LANDING_TO_PERSISTENT_FAIL
        exit 1;
    else
        log "HIVE_ERROR: SUCCESSFULLY REMOVED HDFS DIRECTORY ${persistent_zone_path}/${source_name}/${table_name_new}/load_type=DELTA/run_date=$run_date"
    fi
fi

if [ -f "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent.hql" ]
then
    echo -e "\n ---------LOG FOR LANDING TO PERSISTENT LOAD-------------\n" >> ${log_dir}/${table_name_new}_hive.log
    $cli -hiveconf run_date="$run_date" -f ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent.hql &>> ${log_dir}/${table_name_new}_hive.log
    if [ $? -ne 0 ];
    then
       log "HIVE_ERROR: FAIL TO LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new}"
       rm ${log_dir}/_LANDING_TO_PERSISTENT_RUNNING
       touch ${log_dir}/_LANDING_TO_PERSISTENT_FAIL
       exit 1;
    else
       rm ${log_dir}/_LANDING_TO_PERSISTENT_RUNNING
       touch ${log_dir}/_LANDING_TO_PERSISTENT_SUCCESS
       log "HIVE_INFO: LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new} SUCCESSFULL"
    fi
else
       connection_string=`grep "connection_string=" ${filepath}/${mysql_credential_file} | cut -d'=' -f2`;
       MYPASS=`grep "MYPASS=" ${filepath}/${mysql_credential_file} | cut -d'=' -f2`;
       MYDB=`grep "MYDB=" ${filepath}/${mysql_credential_file} | cut -d'=' -f2`;
       MYUSER=`grep "MYUSER=" ${filepath}/${mysql_credential_file} | cut -d'=' -f2`;
       if [ ! "$MYDB" ] 
       then
           log "HIVE_ERROR:SOME ARGUMNET IS MISSING IN mysql_credential.conf FILE"
       	   rm ${log_dir}/_LANDING_TO_PERSISTENT_RUNNING
           touch ${log_dir}/_LANDING_TO_PERSISTENT_FAIL
		   exit 1
       fi
       #Fetching column name which are primary key 
       key_old=$(mysql -N -u$MYUSER -p$MYPASS -D$MYDB -h$connection_string -e "call sp_PrimaryKey_Hive('$ip_hostname','$port','$database_name','$table_schema','$table_name','$server_name','$instance_name')" | tr '\n' ',')
       #Removing special character in column name
       key=$(echo $key_old | sed 's/[^a-zA-Z*0-9,]/ /g;s/  */ /g;s/ *, */,/g;s/.$//')
       key=(${key//,/ })
       key_length=${#key[@]}
       counter=0
       if [ $key_length == 0 ]
       then
           log "HIVE_ERROR: Primary Key Required For Incremental Load"
           rm ${log_dir}/_LANDING_TO_PERSISTENT_RUNNING
           touch ${log_dir}/_LANDING_TO_PERSISTENT_FAIL
           exit 1;
       else
            str1=''
    	    str2=''
            while [ $counter -lt $key_length ]
    	    do
               str1="$str1${key[$counter]},"
    	       str2="$str2 t1.${key[$counter]} = s.${key[$counter]} AND"
    	       counter=$((counter+1))
            done  
        fi
        str11=`echo $str1 | sed 's/.$//'`
       #Query generation for four step strategy to remove duplicates,
#       query="SET hive.exec.dynamic.partition=true;\nSET hive.exec.dynamic.partition.mode=nonstrict;\nCREATE OR REPLACE VIEW $persistent_db_name.reconcile_view_$table_name_new AS\nSELECT t1.* FROM
#(SELECT * FROM $persistent_db_name.$table_name_new UNION ALL SELECT *,current_timestamp as updated_on,"\"DELTA"\" as load_type,'\${hiveconf:run_date}' as run_date FROM $landing_db_name.$table_name_new) t1\n
#JOIN\n
#(SELECT $str1 max($cdc_column) max_modified FROM(SELECT * FROM $persistent_db_name.$table_name_new UNION ALL SELECT *,current_timestamp as updated_on,"\"DELTA"\" as load_type,'\${hiveconf:run_date}' as run_date FROM $landing_db_name.$table_name_new) t2\n
#GROUP BY $str11) s ON $str2 t1.$cdc_column = s.max_modified;\n CREATE TABLE IF NOT EXISTS $persistent_db_name.${table_name_new}_RT AS SELECT * FROM  $persistent_db_name.reconcile_view_$table_name_new;\n
#dfs -rm -r ${persistent_zone_path}/${source_name}/${table_name_new}/*;\nINSERT OVERWRITE table $persistent_db_name.$table_name_new partition(load_type,run_date) select * from $persistent_db_name.${table_name_new}_RT;\
#\nMSCK REPAIR TABLE $persistent_db_name.$table_name_new;\nDROP TABLE IF EXISTS $persistent_db_name.${table_name_new}_RT;\nDROP VIEW $persistent_db_name.reconcile_view_$table_name_new"
#       echo -e "$query" > ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent.hql


 query="SET hive.exec.dynamic.partition=true;\nSET hive.exec.dynamic.partition.mode=nonstrict;\nCREATE OR REPLACE VIEW $persistent_db_name.reconcile_view_$table_name_new AS\nSELECT t1.* FROM
(SELECT * FROM $persistent_db_name.$table_name_new UNION ALL SELECT *,current_timestamp as updated_on,"\"DELTA"\" as load_type,'\${hiveconf:run_date}' as run_date FROM $landing_db_name.$table_name_new) t1\n
JOIN\n
(SELECT $str1 max($cdc_column) max_modified FROM(SELECT * FROM $persistent_db_name.$table_name_new UNION ALL SELECT *,current_timestamp as updated_on,"\"DELTA"\" as load_type,'\${hiveconf:run_date}' as run_date FROM $landing_db_name.$table_name_new) t2\n
GROUP BY $str11) s ON $str2 t1.$cdc_column = s.max_modified;\n CREATE TABLE IF NOT EXISTS $persistent_db_name.${table_name_new}_RT AS SELECT * FROM  $persistent_db_name.reconcile_view_$table_name_new;"
echo -e "$query" > ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent_create_view.hql
echo -e " \n---------LOG FOR LANDING TO PERSISTENT LOAD-------------\n" >> ${log_dir}/${table_name_new}_hive.log
$cli -hiveconf run_date="$run_date" -f ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent_create_view.hql &>> ${log_dir}/${table_name_new}_hive.log
  if [ $? -ne 0 ];
   then
      log "HIVE_ERROR: FAIL TO LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new}"
      rm ${log_dir}/_LANDING_TO_PERSISTENT_RUNNING
      touch ${log_dir}/_LANDING_TO_PERSISTENT_FAIL
      exit 1;
  else
      log "HIVE_INFO: CREATE RECONCILE VIEW PERSISTENT FOR TABLE ${table_name_new} SUCCESSFULL"

 fi

hadoop fs -rm -r ${persistent_zone_path}/${source_name}/${table_name_new}/*

query1="SET hive.exec.dynamic.partition=true;\nSET hive.exec.dynamic.partition.mode=nonstrict;INSERT OVERWRITE table $persistent_db_name.$table_name_new partition(load_type,run_date) select * from $persistent_db_name.${table_name_new}_RT;\
\nMSCK REPAIR TABLE $persistent_db_name.$table_name_new;\nDROP TABLE IF EXISTS $persistent_db_name.${table_name_new}_RT;\nDROP VIEW $persistent_db_name.reconcile_view_$table_name_new"
       echo -e "$query1" > ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent_recreate_basetable.hql

    echo -e " \n---------LOG FOR LANDING TO PERSISTENT LOAD-------------\n" >> ${log_dir}/${table_name_new}_hive.log
    $cli -hiveconf run_date="$run_date" -f ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent_recreate_basetable.hql &>> ${log_dir}/${table_name_new}_hive.log
    if [ $? -ne 0 ];
    then
       log "HIVE_ERROR: FAIL TO LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new}"
       rm ${log_dir}/_LANDING_TO_PERSISTENT_RUNNING
       touch ${log_dir}/_LANDING_TO_PERSISTENT_FAIL
       exit 1;
    else
       rm ${log_dir}/_LANDING_TO_PERSISTENT_RUNNING
       touch ${log_dir}/_LANDING_TO_PERSISTENT_SUCCESS
       log "HIVE_INFO: LOAD DATA FROM LANDING TO PERSISTENT FOR TABLE ${table_name_new} SUCCESSFULL"

    fi
fi