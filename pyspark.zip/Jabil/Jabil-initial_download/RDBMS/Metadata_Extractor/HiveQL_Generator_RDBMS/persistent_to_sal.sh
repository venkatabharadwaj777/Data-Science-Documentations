#!/bin/bash
# +===================================================================================================================================================+|
# |                                                                                                                                                    |
# | FileName    : persistent_to_sal.sh                                                                                                             |
# |                                                                                                                                                    |
# | Language    : Shell script                                                                                                                         |
# |                                                                                                                                                    |
# | Description : This script generate hql and load data from persistent to sal layer                                                               |
# +===================================================================================================================================================+|
function log() {
        log_time=`date "+%m-%d-%Y:%H:%M:%S"`
        #echo -e "${log_time} $@"
        echo -e "${log_time} $@" >> ${log_dir}/${table_name}_hive.log
}

        table_name=${1}
        initial_load=${2}
        load_type=${3}
        primary_key=${4}
        cdc_column=${5}
        last_ex_date=${6}
        log_dir=${7}
        config_file=${8}
        run_date=${9}
	run_date=`date -d "$run_date - 1 days" +%Y-%m-%d`
        source_name=${10}
        logical_name=${11}
        generate_hql_flag=${12}
	

#echo "table_name         $table_name"
#echo "initial_load       $initial_load"
#echo "load_type          $load_type"
#echo "primary_key        $primary_key"
#echo "cdc_column         $cdc_column"
#echo "last_ex_date       $last_ex_date"
#echo "log_dir            $log_dir"
#echo "config_file        $config_file"
#echo "run_date           $run_date"
#echo "source_name        $source_name"
#echo "logical_name       $logical_name"
#echo "generate_hql_flag  $generate_hql_flag"

#--------------------------Restartability Block-------------------------------------------------------|
# check if script already succeeded for this date and for mentioned table , if it is do not run again
# if script is already running, do not start it
# if script is failed for earlier run, change the status to running and re-start the process

if [ -f $log_dir/_${table_name}_SUCCESS ]; 
then
	log "SAL-INFO: Process for SAL Table : ${table_name} is already completed" 
	log "SAL-INFO: skipping run for SAL Table : ${table_name}"
	exit 1
fi
if [ -f $log_dir/_${table_name}_FAIL ]; 
then
	log "SAL-WARNING: As this is re-run for failed script for SAL Table : ${table_name} , changing status to Running"
	rm $log_dir/_${table_name}_FAIL
	log "Status for Instance is changed to running"
	touch $log_dir/_${table_name}_RUNNING
	log "SAL-INFO: This is re-run, setting up the skipping flags"
elif [ -f $log_dir/_${table_name}_RUNNING ]; 
then
	log "SAL-WARNING: As script is running for SAL Table : "${table_name}" ,skipping the re-run"
	exit 1
else
	log "SAL-INFO: It seems it is fresh run, marking status as running for SAL Table: "${table_name}""
	touch $log_dir/_${table_name}_RUNNING
	log "Status is changed to running for SAL Table: "${table_name}""
fi

#--------------------------------------End of Restartability Block---------------------------------------------|
#sourcing hive_config.conf file

source ${config_file}

if [ "${load_type}" == "FR" ]; 
then
	if [ "${generate_hql_flag}" == "Y" ];
	then
		if [ -f $sal_script_path/${load_type}/${table_name}.hql ]
		then
			echo "SAL for table ${table_name} started : 1"
			$cli -f $sal_script_path/${load_type}/${table_name}.hql &>> $log_dir/${table_name}_sal_fr_script.log

			if [ $? -ne 0 ];
			then
				log "BEELINE_ERROR: FAIL TO LOAD DATA FROM PERSISTENT TO SAL FOR TABLE ${table_name}"
				rm $log_dir/_${table_name}_RUNNING
				touch $log_dir/_${table_name}_FAIL
				exit 1;
		  	else
  				rm $log_dir/_${table_name}_RUNNING
				touch $log_dir/_${table_name}_SUCCESS
				log "BEELINE_INFO: LOAD DATA FROM PERSISTENT TO SAL FOR TABLE ${table_name} SUCCESSFUL"
  			fi

		else
			string_ql="FROM $persistent_db_name.$table_name INSERT OVERWRITE TABLE $sal_db_name.$table_name SELECT *;"
			echo -e "$string_ql" > $sal_script_path/${load_type}/${table_name}.hql

			echo "SAL for table ${table_name} started : 2"
			$cli -f $sal_script_path/${load_type}/${table_name}.hql &>> $log_dir/${table_name}_sal_fr_script.log

			if [ $? -ne 0 ];
			then
				log "BEELINE_ERROR: FAIL TO LOAD DATA FROM PERSISTENT TO SAL FOR TABLE ${table_name}"
				rm $log_dir/_${table_name}_RUNNING
				touch $log_dir/_${table_name}_FAIL
				exit 1;
		  	else
  				rm $log_dir/_${table_name}_RUNNING
				touch $log_dir/_${table_name}_SUCCESS
				log "BEELINE_INFO: LOAD DATA FROM PERSISTENT TO SAL FOR TABLE ${table_name} SUCCESSFUL"
  			fi

		fi
	else
		if [ -f $sal_script_path/${load_type}/${table_name}.hql ]
		then
			echo "SAL for table ${table_name} started : 3"
			$cli -f $sal_script_path/${load_type}/${table_name}.hql &>> $log_dir/${table_name}_sal_fr_script.log

			if [ $? -ne 0 ];
			then
				log "BEELINE_ERROR: FAIL TO LOAD DATA FROM PERSISTENT TO SAL FOR TABLE ${table_name}"
				rm $log_dir/_${table_name}_RUNNING
				touch $log_dir/_${table_name}_FAIL
				exit 1;
		  	else
  				rm $log_dir/_${table_name}_RUNNING
				touch $log_dir/_${table_name}_SUCCESS
				log "BEELINE_INFO: LOAD DATA FROM PERSISTENT TO SAL FOR TABLE ${table_name} SUCCESSFUL"
  			fi

		else
			log "HIVEQL_ERROR: FILE $sal_script_path/${load_type}/${table_name}.hql FOR TABLE ${table_name} not found"
		fi
	fi

elif [ "${load_type}" == "D" ];
then      
	if [ "${initial_load}" == "Y" ];
	then
		echo "Initial SAL for table ${table_name} started 4"

		$cli -f $sal_script_path/${load_type}/${table_name}.hql &> $log_dir/${table_name}_sal_initial_script.log                         
		if [ $? -ne 0 ];
  		then
  	   	    log "BEELINE_ERROR: FAIL TO LOAD DATA FROM PERSISTENT TO SAL FOR TABLE ${table_name}"
  	   	    rm $log_dir/_${table_name}_RUNNING
  	   	    touch $log_dir/_${table_name}_FAIL
  	   	    exit 1;
  		else
  	   	    rm $log_dir/_${table_name}_RUNNING
  	   	    touch $log_dir/_${table_name}_SUCCESS
  	   	    log "BEELINE_INFO: LOAD DATA FROM PERSISTENT TO SAL FOR TABLE ${table_name} SUCCESSFUL"
  	 	fi
	else
		echo "Delta SAL for table ${table_name} started 5"
		$cli -f $sal_script_path/${load_type}/1_temp_delta_table_movement.hql &> $log_dir/${table_name}_1_temp_delta_table_movement.log                         
		if [ $? -ne 0 ];
  		then
  	   	    log "BEELINE_ERROR: FAIL TO LOAD DATA FROM PERSISTENT TO SAL FOR TABLE ${table_name}"
  	   	    rm $log_dir/_${table_name}_RUNNING
  	   	    touch $log_dir/_${table_name}_FAIL
  	   	    exit 1;
  	 	fi

		temp_load_type=''
		temp_run_date=''

		$cli --showHeader=false --silent=true --outputformat=csv2 -e 'Select distinct mvmnt.load_type, mvmnt.run_date from spend_analytics.movement mvmnt, (Select distinct a.load_type as load_type, a.run_date as run_date  from spend_analytics.movement a inner join spend_analytics.temp_delta_table_movement b on a.movementdocumentnumber=b.movementdocumentnumber and a.movementyear=b.movementyear and a.movementdocumentitem=b.movementdocumentitem) a where mvmnt.load_type=a.load_type and mvmnt.run_date=a.run_date' > unique_partition.txt

 		while IFS= read -r ROW
        	do
                	part_arr=(${ROW//,/ })
                	temp_load_type="\"$temp_load_type${part_arr[0]}\","
                	temp_run_date="\"$temp_run_date${part_arr[1]}\","

        	done <unique_partition.txt

        	load_type_str=`echo $temp_load_type | sed 's/.$//'`
        	if [[ $load_type_str == '' ]]
        	then
                	load_type_str =\" \"
        	fi
        	run_date_str=`echo $temp_run_date | sed 's/.$//'`
        	if [[ $run_date_str == '' ]]
        	then
                	run_date_str =\" \"
        	fi

		$cli --silent=true -e 'INSERT OVERWRITE TABLE spend_analytics.stg_rep_upsert_movement select movementdocumenttype,movementyear,movementdocumentnumber,movementdocumentitem,sitecode,sitepartcode,posteddts,referencedocumentnumber,movementtypecode,billoflading,movementcomments,location,batchnumber,inventorytypecode,quantity,materialcost,companyorganizationcode,salesdocumentnumber,salesdocumentitem,purchasedocumentnumber,purchasedocumentitem,dscreateuser,debitcreditindicator,ownercorporationdscode,currencycode,specialstockscode,unitofmeasuredscode,amlreferencenumber,transactiondts,reasontypecode,movementitemcomments,movementindicator,corporationdstypecode,corporationdstypestdcode,updated_on,load_type,run_date from spend_analytics.temp_delta_table_movement union all Select a.movementdocumenttype,a.movementyear,a.movementdocumentnumber,a.movementdocumentitem,a.sitecode,a.sitepartcode,a.posteddts,a.referencedocumentnumber,a.movementtypecode,a.billoflading,a.movementcomments,a.location,a.batchnumber,a.inventorytypecode,a.quantity,a.materialcost,a.companyorganizationcode,a.salesdocumentnumber,a.salesdocumentitem,a.purchasedocumentnumber,a.purchasedocumentitem,a.dscreateuser,a.debitcreditindicator,a.ownercorporationdscode,a.currencycode,a.specialstockscode,a.unitofmeasuredscode,a.amlreferencenumber,a.transactiondts,a.reasontypecode,a.movementitemcomments,a.movementindicator,a.corporationdstypecode,a.corporationdstypestdcode,a.updated_on,a.load_type,a.run_date from spend_analytics.movement a left outer join spend_analytics.temp_delta_table_movement b on a.movementdocumentnumber=b.movementdocumentnumber and a.movementyear=b.movementyear and a.movementdocumentitem=b.movementdocumentitem where b.movementdocumentnumber is null and b.movementyear is null and b.movementdocumentitem is null and a.load_type in (${load_type_str}) and a.run_date in (${run_date_str})'


		#$cli -f $sal_script_path/${load_type}/2_stg_rep_upsert_movement.hql &> $log_dir/${table_name}_2_stg_rep_upsert_movement.log                         
		if [ $? -ne 0 ];
  		then
  	   	    log "BEELINE_ERROR: FAIL TO LOAD DATA FROM PERSISTENT TO SAL FOR TABLE ${table_name}"
  	   	    rm $log_dir/_${table_name}_RUNNING
  	   	    touch $log_dir/_${table_name}_FAIL
  	   	    exit 1;
  	 	fi
		
		while IFS= read -r ROW
		do
			part_arr=(${ROW//,/ })
			echo ${part_arr[0]}
			echo ${part_arr[1]}
			$cli -e 'alter table spend_analytics.movement drop partition(load_type='${part_arr[0]}',run_date='${part_arr[1]}')'

			if [ $? -ne 0 ];
  			then
				log "BEELINE_ERROR: FAILED TO DROP PARTITION load_type='${part_arr[0]}' AND run_date='${part_arr[1]}' "
  	   	    		rm $log_dir/_${table_name}_RUNNING
  	   	    		touch $log_dir/_${table_name}_FAIL
  	   	    		exit 1;
  	 		fi

			hadoop fs -rmr /data/spend_analytics/sap_hana_ecc/movement/load_type={part_arr[0]}/run_date=${part_arr[1]}/

			if [ $? -ne 0 ];
  			then
				log "HDFS_ERROR: FAILED TO REMOVE FILES /data/spend_analytics/sap_hana_ecc/movement/load_type={part_arr[0]}/run_date=${part_arr[1]}/
 FOR DROPPED PARTITION load_type='${part_arr[0]}' AND run_date='${part_arr[1]}' "
  	   	    		rm $log_dir/_${table_name}_RUNNING
  	   	    		touch $log_dir/_${table_name}_FAIL
  	   	    		exit 1;
  	 		fi

		done <unique_partition.txt
		rm unique_partition.txt
	
		$cli -f $sal_script_path/${load_type}/4_insert _data_from_stg_rep_upsert_to_movement.hql &> $log_dir/${table_name}_4_insert _data_from_stg_rep_upsert_to_movement.log                         
		if [ $? -ne 0 ];
  		then
  	   	    log "BEELINE_ERROR: FAIL TO LOAD DATA FROM PERSISTENT TO SAL FOR TABLE ${table_name}"
  	   	    rm $log_dir/_${table_name}_RUNNING
  	   	    touch $log_dir/_${table_name}_FAIL
  	   	    exit 1;
  		else
  	   	    rm $log_dir/_${table_name}_RUNNING
  	   	    touch $log_dir/_${table_name}_SUCCESS
  	   	    log "BEELINE_INFO: LOAD DATA FROM PERSISTENT TO SAL FOR TABLE ${table_name} SUCCESSFUL"
  	 	fi
	fi
else
        log "MYSQL_ERROR: INCORRECT LOAD_TYPE ${load_type} for TABLE ${table_name}"
        rm $log_dir/_${table_name}_RUNNING
        touch $log_dir/_${table_name}_FAIL
        exit 1;
fi