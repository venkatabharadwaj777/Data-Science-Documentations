#!/bin/bash
# +===================================================================================================================================================+|
# |                                                                                                                                                    |
# | FileName    : HiveQL.sh                                                                                                                            |
# |                                                                                                                                                    |
# | Language    : Shell script                                                                                                                         |
# |                                                                                                                                                    |
# | Description : This is master script to call all hive processes HiveDDL,initial load,delta load (full load,landing to raw,landing to persistent)
# |                                                                                                                                                    |
# +====================================================================================================================================================+
#Log Function
function log() {
        log_time=`date "+%m-%d-%Y:%H:%M:%S"`
        #echo -e "${log_time} $@"
        echo -e "${log_time} $@" >> ${log_dir}/${table_name_new}_hive.log
}
## HiveQL_Genrator configuration file
config_file=$1
## Extract filepath for HiveQL_Genrator
filepath=$(dirname $1)
ip_hostname=${2,,}
database_name=${3,,}
table_schema=${4,,}
table_name=${5,,}
cdc_column=${6}
load_type=${7^^}
create_DDL=${8^^}
log_dir=${9}
server_name=${10,,}
instance_name=${11,,}
run_date=${12}
run_date=`date -d "$run_date - 1 days" +%Y-%m-%d`
port=${14}
source_name=${15,,}
table_name_new=${16,,}
logical_name=${17}
#source hive_config.cong file
source $config_file
echo "Create DDL Flag $create_DDL"
##check that confile.conf and mysql_credential.conf exists
if [ ! -f ${config_file} ];then
   log "HIVE_ERROR: ${config_file} FILE DOES NOT EXIST"
	exit 1
fi

if [ ! -f ${filepath}/${mysql_credential_file} ];then
   log "HIVE_ERROR: ${filepath}/${mysql_credential_file} FILE DOES NOT EXIST"
   exit 1
fi

##Extract mysql credential from mysql_credential.conf
connection_string=`grep "connection_string=" ${filepath}/${mysql_credential_file} | cut -d'=' -f2`;
MYPASS=`grep "MYPASS=" ${filepath}/${mysql_credential_file} | cut -d'=' -f2`;
MYDB=`grep "MYDB=" ${filepath}/${mysql_credential_file} | cut -d'=' -f2`;
MYUSER=`grep "MYUSER=" ${filepath}/${mysql_credential_file} | cut -d'=' -f2`;
#Condition to check that all field are defined in mysql_credential fing 
#if [ ! "$MYPASS" ] || [ ! "$MYDB" ] || [ ! "$MYUSER" ] || [ ! "$connection_string" ]
if [ ! "$MYDB" ] || [ ! "$connection_string" ]
then
    log "HIVE_ERROR:SOME ARGUMNET IS MISSING IN mysql_credential.conf FILE"
	exit 1
fi

##Check that all variables in configuration file defined
if [ ! "$mysql_credential_file" ] || [ ! "$datatype_json" ] || [ ! "$datatype_json_precision" ] || [ ! "$datatype_mapping_file" ] ||\
   [ ! "$landing_db_name" ] || [ ! "$landing_layer_storage" ] ||[ ! "$landing_zone_path" ] || [ ! "$raw_db_name" ] || [ ! "$raw_layer_storage" ] ||\
   [ ! "$raw_zone_path" ] || [ ! "$raw_archive_path" ] || [ ! "$persistent_db_name" ] || [ ! "$persistent_layer_storage" ] || [ ! "$persistent_zone_path" ] ||\
   [ ! "$compression" ] || [ ! "$field_terminated_by" ] || [ ! "$hive_ddl_dir" ] || [ ! "$hive_ql_dir" ]
then
   log "HIVE_ERROR:CHECK CONFIGURATION FILE (.conf),ONE OR MORE VARIABLES MISSING"
   exit 1
fi
##Check for proper number of arguments
if [ $# -ne 17 ]
then
    log "HIVE_ERROR:SOME ARGUMENTS ARE MISSING WHEN PASSING TO HiveQL.sh"
    exit 1
fi
#hive -e "CREATE DATABASE IF NOT EXISTS $landing_db_name;CREATE DATABASE IF NOT EXISTS $raw_db_name;CREATE DATABASE IF NOT EXISTS $persistent_db_name;"

log "HIVE_INFO: HIVE PROOCESS STARTED FOR TABLE ${table_name_new}"
echo "HIVE_INFO: HIVE PROCESS STARTED FOR TABLE ${table_name_new}"
if [ "${create_DDL}" == "Y" ] || [ "${create_DDL}" == "YC" ] || [ "${create_DDL}" == "YR" ]
then 
        log "HIVE_INFO:HIVE DDL CREATION STARTED FOR ${table_name_new}"
	#Executing HiveDDL.sh script to generate Hive DDL statements 
        sh $filepath/HiveDDL.sh $ip_hostname $database_name $table_schema $table_name $config_file $load_type $log_dir $table_name_new $source_name $port $server_name $instance_name $logical_name
    if [ $? -ne 0 ];
    then
        echo "HIVE_ERROR: HIVE DDL CREATION PROCESS FAILED FOR TABLE ${table_name_new}"
	echo "HIVE_INFO: FOR DETAILED LOG REFER ${log_dir}/${table_name_new}_hive.log"
	exit 1;
    fi
    #Executing initial_load.sh script to generate Hive DML statements to load data from landing layer to raw and persistent layer
    log "HIVE_INFO:INITIAL LOAD STARTED FOR ${table_name_new}"
    sh $filepath/initial_load.sh $table_name $config_file $table_name_new $load_type $create_DDL $log_dir $source_name $run_date $server_name $instance_name $logical_name
    if [ $? -ne 0 ];
    then
        echo "HIVE_ERROR: HIVE INITIAL LOAD PROCESS FAILED FOR TABLE ${table_name_new}" 
		echo "HIVE_INFO: FOR DETAILED LOG REFER ${log_dir}/${table_name_new}_hive.log"
		exit 1;
     fi
     
    if [ "${load_type}" == "F-D" ]
    then
         
         log "HIVE_INFO: DATA LOADING STARTED FROM LANDING TO RAW ZONE FOR TABLE ${table_name_new} "
         sh $filepath/landing_to_raw.sh $table_name $table_name_new $config_file $log_dir $source_name $run_date $server_name $instance_name $logical_name
         if [ $? -ne 0 ];
         then
             echo "HIVE_ERROR: HIVE LANDING TO RAW LOAD PROCESS FAILED FOR TABLE ${table_name_new}" 
		     echo "HIVE_INFO: FOR DETAILED LOG REFER ${log_dir}/${table_name_new}_hive.log"
			 exit 1;
         fi
         log "HIVE_INFO: DATA LOADING STARTED FROM LANDING TO PERSISTENT ZONE FOR TABLE ${table_name_new} "
         sh $filepath/landing_to_persistent.sh $ip_hostname $database_name $table_schema $table_name $cdc_column $table_name_new $config_file $log_dir $source_name $run_date $port $server_name $instance_name $logical_name
         if [ $? -ne 0 ];
         then
             echo "HIVE_ERROR: HIVE LANDING TO PERSITENT LOAD PROCESS FAILED FOR TABLE ${table_name_new}" 
		     echo "HIVE_INFO: FOR DETAILED LOG REFER ${log_dir}/${table_name_new}_hive.log"
			 exit 1;
         fi 
         # Update Load type from F-D to D after successfull loading data from landing to raw and persistent layer in case of load type F-D
         mysql -N -u$MYUSER -p$MYPASS -D$MYDB -h$connection_string -e "CALL sp_UpdateLoad_type_Hive('${ip_hostname}','${port}','${database_name}','${table_schema}','${table_name}','D','${server_name}','${instance_name}');" 
       if [ $? -ne 0 ];
       then
            log "HIVE_ERROR: NOT ABLE TO UPDATE LOAD_TYPE IN SOURCE_TABLE_DETAILS METADATA TABLE FROM F-D TO D"
            echo "HIVE_ERROR: HIVE PROCESS FAILED FOR TABLE ${table_name_new}"
	        echo "HIVE_INFO: FOR DETAILED LOG REFER ${log_dir}/${table_name_new}_hive.log"
			exit 1;
       fi
 
   fi
     # Update create_ddl flag Y to N after successfull initial load
     mysql -N -u$MYUSER -p$MYPASS -D$MYDB -h$connection_string -e "CALL sp_UpdateCreateDDL_Hive('${ip_hostname}','${port}','${database_name}','${table_schema}','${table_name}','N','${server_name}','${instance_name}');"
   if [ $? -ne 0 ];
   then
        log "HIVE_ERROR: NOT ABLE TO UPDATE CRETAE_DDL FLAG IN SOURCE_TABLE_DETAILS METADATA TABLE FROM $create_ddl TO D"
		echo "HIVE_ERROR: HIVE PROCESS FAILED FOR TABLE ${table_name_new}"
	    echo "HIVE_INFO: FOR DETAILED LOG REFER ${log_dir}/${table_name_new}_hive.log"
        exit 1;
   fi
   log "HIVE_INFO: HIVE PROCESS SUCCESSFULL FOR TABLE ${table_name_new}"
   echo "HIVE_INFO: HIVE PROCESS SUCCESSFULL FOR TABLE ${table_name_new}"
elif [ "${create_DDL}" == "N" ]
then
    if [ "${load_type}" == "FR" ]
    then
        log "HIVE_INFO: DATA LOADING STARTED FOR TABLE ${table_name_new} FROM LANDING TO RAW ZONE AND PERSISTENT ZONE"
         #Executing full_load.sh script to generate Hive DML statements to load data from landing layer to raw layer and persistent layer (for FULL_REFRESH TABLES)
         sh $filepath/full_load.sh $table_name $table_name_new $config_file $log_dir $source_name $run_date $server_name $instance_name $logical_name
	if [ $? -ne 0 ];
        then
             echo "HIVE_ERROR: HIVE LANDING TO RAW AND PERSISTENT LOAD PROCESS FAILED FOR TABLE ${table_name_new}" 
	    echo "HIVE_INFO: FOR DETAILED LOG REFER ${log_dir}/${table_name_new}_hive.log"
		exit 1;
    fi
    elif [ "${load_type}" == "D" ]
    then
         #Executing full_load.sh script to generate Hive DML statements to load data from landing layer to raw layer (for partition tables)
         log "HIVE_INFO: DATA LOADING STARTED FROM LANDING TO RAW ZONE FOR TABLE ${table_name_new} "
         sh $filepath/landing_to_raw.sh $table_name $table_name_new $config_file $log_dir $source_name $run_date $server_name $instance_name $logical_name
         if [ $? -ne 0 ];
         then
            echo "HIVE_ERROR: HIVE LANDING TO RAW LOAD PROCESS FAILED FOR TABLE ${table_name_new}" 
		    echo "HIVE_INFO: FOR DETAILED LOG REFER ${log_dir}/${table_name_new}_hive.log"
			exit 1;
         fi
         #Executing full_load.sh script to generate Hive DML statements to load data from landing layer to persistent layer (for partition tables)
         log "HIVE_INFO: DATA LOADING STARTED FROM LANDING TO PERSISTENT ZONE FOR TABLE ${table_name_new} "
         sh ${filepath}/landing_to_persistent.sh $ip_hostname $database_name $table_schema $table_name $cdc_column $table_name_new $config_file $log_dir $source_name $run_date $port $server_name $instance_name $logical_name
         if [ $? -ne 0 ];
         then
             echo "HIVE_ERROR: HIVE LANDING TO PERSISTENT LOAD PROCESS FAILED FOR TABLE ${table_name_new}" 
		     echo "HIVE_INFO: FOR DETAILED LOG REFER ${log_dir}/${table_name_new}_hive.log"
			 exit 1;
         fi
        log "HIVE_INFO: HIVE PROCESS SUCCESSFULL FOR TABLE ${table_name_new}"
        echo "HIVE_INFO: HIVE PROCESS SUCCESSFULL FOR TABLE ${table_name_new}"
    else 
        log "HIVE_ERROR:LOAD TYPE IS NOT CORRECTLY POPULATED FROM METADATA TABLE"
		echo "HIVE_ERROR: HIVE PROCESS FAILED FOR TABLE ${table_name_new}"
	    echo "HIVE_INFO: FOR DETAILED LOG REFER ${log_dir}/${table_name_new}_hive.log"
        exit 1;	  
    fi		
else
    log "HIVE_ERROR:CREATE_DDL VALUE IS NOT CORRECT,VERIFY WITH METADATA TABLE"
	echo "HIVE_ERROR: HIVE PROCESS FAILED FOR TABLE ${table_name_new}"
	echo "HIVE_INFO: FOR DETAILED LOG REFER ${log_dir}/${table_name_new}_hive.log"
    exit 1;
fi
