#!/bin/bash

# +===================================================================================================================================================+|
# |                                                                                                                                                    |
# | FileName    : HiveDDL.sh                                                                                                                           |
# |                                                                                                                                                    |
# | Language    : Shell script                                                                                                                        |
# |                                                                                                                                                    |
# | Description :This script generates Hive DDL statements for landing,raw and persistent layers
# |                                                                                                                                                    |
# +====================================================================================================================================================+
#log function
function log() {
        log_time=`date "+%m-%d-%Y:%H:%M:%S"`
        #echo -e "${log_time} $@"
        echo -e "${log_time} $@" >> ${log_dir}/${table_name_new}_hive.log
}
ip_host=${1} 
database_name=${2}
table_schema=${3}
table_name=${4}
config_file=${5}
filepath=$(dirname $5)
source $config_file
load_type=${6}
log_dir=${7}
table_name_new=${8}
source_name=${9}
port=${10}
server_name=${11}
instance_name=${12}
logical_name=${13}
#Condition to check all parameters
if [ $# -ne 13 ]
then
     log "Usage : sh <script name> <ip_hostname> <database_name> <table_schema> <table_name> <config_file> <load_type> <log_dir> <table_name_new> <source_name> <port><server_name><instance_name> <logical_name>"
     log "For example : sh HiveDDL.sh $ip_host $database_name $table_schema $table_name $config_file $load_type $log_dir $table_name_new $source_name $port $server_name $instance_name ${logical_name}"
     log "HIVE_ERROR:EXITING ....."
     exit 1;
fi

#---------------------------------------------------------------------------------------------------------------|
#                        BLOCK FOR RESTARTABILITY                                                               |
#---------------------------------------------------------------------------------------------------------------|

if [ -f ${log_dir}/_HIVEDDL_SUCCESS ]; then
   log "HIVE_INFO: DDL FOR TABLE ${table_name_new} IS ALREADY COMPLETED"
   log "HIVE_INFO: SKIPPING RUN FOR TABLE: "${table_name_new}
   exit 0
fi

if [ -f ${log_dir}/_HIVEDDL_FAIL ]; then
    log "HIVE_WARNING: AS THIS IS RE-RUN FOR FAILED SCRIPT FOR TABLE: "${table_name_new} ",CHANGING STATUS TO RUNNING "
    rm ${log_dir}/_HIVEDDL_FAIL
    state_change_status=`echo $?`
    if [ $state_change_status == 0 ]; then
        log "HIVE_INFO:STATUS IS CHANGED TO RUNNING"
        touch ${log_dir}/_HIVEDDL_RUNNING
    else
        log "HIVE_ERROR: FAILED TO CHANGE THE STAUS FROM FAIL TO RUNNING FOR TABLE: "${table_name_new}
        log "HIVE_ERROR: EXITING ...... "
        exit 1
    fi
elif [ -f ${log_dir}/_HIVEDDL_RUNNING ]; then
     log "HIVE_WARNING: AS SCRIPT IS RUNNING FOR TABLE: "${table_name_new}" ,SKIPPING THE RE-RUN"
     exit 0
else
     log "HIVE_INFO: IT SEEMS IT IS FRESH RUN, MARKING STATUS AS RUNNING FOR TABLE: "${table_name_new}
     touch ${log_dir}/_HIVEDDL_RUNNING
     state_change_status=`echo $?`
     if [ $state_change_status == 0 ]; then
        log "HIVE_INFO:STATUS IS CHANGED TO RUNNING FOR TABLE: "${table_name_new}
     fi
fi
#------------------------END RESTARTABILITY BLOCK---------------------------------------------------------------------------|
#------------------------HiveDDl and HiveQL DIRECTORIES CREATION BLOCK------------------------------------------------------| 

if [ ! -d ${hive_ddl_dir}/${source_name}/${logical_name} ]
then
    
    log "HIVE_WARNING: "${hive_ddl_dir}/${source_name}/${logical_name}" DOES NOT EXIST. TRYING TO CREATE IT..."
    mkdir -p ${hive_ddl_dir}/${source_name}/${logical_name}
     if [ $? -eq 0 ];then
        log "HIVE_INFO:${hive_ddl_dir}/${source_name}/${logical_name} CREATED"
     else
        log "HIVE_ERROR: CAN'T CREATE ${hive_ddl_dir}/${source_name}/${logical_name}"
	rm ${log_dir}/_HIVEDDL_RUNNING
        touch ${log_dir}/_HIVEDDL_FAIL
        exit 1;
     fi
fi
if [ ! -d "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}" ]
then
    
    log "HIVE_WARNING: "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}" DOES NOT EXIST. TRYING TO CREATE IT..."
    mkdir -p ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}
    if [ $? -eq 0 ];then
        log "HIVE_INFO:${hive_ql_dir}/${source_name}/${logical_name}/${table_name} CREATED"
     else
        log "HIVE_ERROR: CAN'T CREATE ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}"
        rm ${log_dir}/_HIVEDDL_RUNNING
        touch ${log_dir}/_HIVEDDL_FAIL
        exit 1;
     fi
fi
#------------------------END OF HiveDDl and HiveQL DIRECTORIES CREATION BLOCK---------------------------------------------------|
#-------------------------DELETE hql files IF EXIST ON INITIAL LOAD-------------------------------------------------------------|
if [ -f "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_full.hql" ]
then
    rm ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_full.hql
fi

if [ -f "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_raw.hql" ]
then
    rm ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_raw.hql
fi

if [ -f "${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent.hql" ]
then
    rm ${hive_ql_dir}/${source_name}/${logical_name}/${table_name}/${table_name_new}_delta_persistent.hql
fi
#--------------Calling python script to map from source datatype to hive datatype-------------------------------------------------|
string1=$(python ${filepath}/$datatype_mapping_file ${ip_host} ${port} ${database_name} ${table_schema} ${table_name} $server_name $instance_name ${filepath}/${datatype_json} ${filepath}/${datatype_json_precision} ${filepath}/${mysql_credential_file})
state_change_status=`echo $?`
if [ ! "$string1" ];then
   log "HIVE_ERROR: COLUMN DETAILS NOT FOUND FOR THE TABLE $table_name IN METADATA TABLE"
   rm ${log_dir}/_HIVEDDL_RUNNING
   touch ${log_dir}/_HIVEDDL_FAIL
   exit 1;
fi
if [ $state_change_status -ne 0 ]; then
   log "$string1"
   log "Datatype Mapping Failed"
   rm ${log_dir}/_HIVEDDL_RUNNING
   touch ${log_dir}/_HIVEDDL_FAIL
   exit 1;
fi
string="DROP TABLE IF EXISTS ${landing_db_name}.${table_name_new};CREATE EXTERNAL TABLE ${landing_db_name}.${table_name_new} ("
string1=`echo $string1 | sed 's/.$//'`
string="$string$string1"
string_raw=`echo $string|sed "s/$landing_db_name/$raw_db_name/g"`
string_persist=`echo $string|sed "s/$landing_db_name/$persistent_db_name/g"`

if [ "${load_type}" == "FR" ]
then
     #--------------DDL CREATION FOR FULL REFRESH TABLES---------------------------------------|
     string="$string)ROW FORMAT DELIMITED FIELDS TERMINATED BY '$field_terminated_by' STORED AS ${landing_layer_storage} \
	 location '${landing_zone_path}/${source_name}/${table_name_new}';"
     string_raw="$string_raw,created_on TIMESTAMP)ROW FORMAT DELIMITED FIELDS TERMINATED BY '$field_terminated_by' STORED AS $raw_layer_storage \
	 location '${raw_zone_path}/${source_name}/${table_name_new}' TBLPROPERTIES ('$raw_layer_storage.COMPRESS'='$compression');"
     string_persist="$string_persist,updated_on TIMESTAMP)ROW FORMAT DELIMITED FIELDS TERMINATED BY '$field_terminated_by' STORED AS $persistent_layer_storage \
	 location '${persistent_zone_path}/${source_name}/${table_name_new}' TBLPROPERTIES ('$persistent_layer_storage.COMPRESS'='$compression');" 
elif [ "${load_type}" == "D" ] || [ "${load_type}" == "F-D" ]
then
     #--------------DDL CREATION FOR DELTA LOAD TABLES-----------------------------------------|

     string="$string)ROW FORMAT DELIMITED FIELDS TERMINATED BY '$field_terminated_by' STORED AS ${landing_layer_storage} \
	 location '${landing_zone_path}/${source_name}/${table_name_new}';"
     string_raw="$string_raw,created_on TIMESTAMP)PARTITIONED BY(load_type STRING,run_date STRING) \
	 ROW FORMAT DELIMITED FIELDS TERMINATED BY '$field_terminated_by' STORED AS $raw_layer_storage \
	 location '${raw_zone_path}/${source_name}/${table_name_new}' TBLPROPERTIES ('$raw_layer_storage.COMPRESS'='$compression');"
     string_persist="$string_persist,updated_on TIMESTAMP)PARTITIONED BY(load_type STRING,run_date STRING) \
	 ROW FORMAT DELIMITED FIELDS TERMINATED BY '$field_terminated_by' STORED AS $persistent_layer_storage \
	 location '${persistent_zone_path}/${source_name}/${table_name_new}' TBLPROPERTIES ('$persistent_layer_storage.COMPRESS'='$compression');"
else
     log "HIVE_ERROR: LOAD TYPE IS NOT CORRECTLY POPULATED FROM METADATA TABLE"
     rm ${log_dir}/_HIVEDDL_RUNNING
     touch ${log_dir}/_HIVEDDL_FAIL
     exit 1;	  
fi
#------------------------WRITE DDL IN FILES-----------------------------------------------------|
echo  $string>${hive_ddl_dir}/${source_name}/${logical_name}/${table_name_new}.sql
echo  $string_raw>>${hive_ddl_dir}/${source_name}/${logical_name}/${table_name_new}.sql
echo  $string_persist>>${hive_ddl_dir}/${source_name}/${logical_name}/${table_name_new}.sql

echo -e "\n ---------LOG FOR DDL CREATION-------------\n" >> ${log_dir}/${table_name_new}_hive.log

$cli -f "${hive_ddl_dir}/${source_name}/${logical_name}/${table_name_new}.sql"  &> ${log_dir}/${table_name_new}_hive.log
if [ $? -ne 0 ];
then
     log "HIVE_ERROR: FAIL TO CREATE HIVE TABLES IN LANDING,RAW AND PERSISTENT ZONE"
     rm ${log_dir}/_HIVEDDL_RUNNING
     touch ${log_dir}/_HIVEDDL_FAIL
     exit 1;
else
    rm ${log_dir}/_HIVEDDL_RUNNING
    touch ${log_dir}/_HIVEDDL_SUCCESS
    log "HIVE_INFO: HIVE TABLES IN LANDING,RAW AND PERSISTENT ZONE SUCCESSFULLY CREATED"
fi
