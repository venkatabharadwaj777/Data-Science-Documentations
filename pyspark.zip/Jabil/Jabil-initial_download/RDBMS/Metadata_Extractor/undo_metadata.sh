#!/bin/bash
# undo_metadata.sh
# Copyright (C) 2019 Jabil Inc 
#
# Purpose : To select the Records for PRPS Table and delete if already exists in Metadata Tables.
#
# Get the hostname to determine the CLUSTER
case "${HOSTNAME:9:1}" in
  "d")
    # DEV only
    export CLUSTER=dev
    export CLUSTER_CODE=d
    export ACCOUNT=svccor_hdp_dev
    export MYSQL=awuea1rmyhdpd03.cewrwkqrhz7g.us-east-1.rds.amazonaws.com
    export DB="'HAD'"
    ;;
  "q")
    # STG only
    export CLUSTER=stg
    export CLUSTER_CODE=s
    export ACCOUNT=svccor_hdp_stg   
    export MYSQL=awuea1rmyhdps03.cviaarmqlyyj.us-east-1.rds.amazonaws.com
    export DB="'HAQ'"
    ;;
  "p")
    # PRD only
    export CLUSTER=prd
    export CLUSTER_CODE=c
    export ACCOUNT=svccor_hdp
    export MYSQL=awuea1rmyhdpp03.c4o2nqevhze2.us-east-1.rds.amazonaws.com
    export DB="'HAP'"
    ;;
  *) # not good
    echo "\$HOSTNAME='${HOSTNAME}' unexpected server hostname"
    exit 1
esac

# Allow environment variable overrides
while getopts "h?d:t:" opt; do
   case "$opt" in
      # Help
      h|\?) DISPLAYHELP="X"
         ;;
      # Get the Database
      d) export DB=$OPTARG
         ;;
      # Get the Table
      t) export TABLE=$OPTARG
         ;;
   esac
done  

# Make sure the table is populated
if [[ "${TABLE}" == "" ]]; then
  DISPLAYHELP="X"
fi

# Echo the outputs
echo "Parameters for undo_metadata.sh"
echo "Table -t:          ${TABLE}"
echo "Database:          ${DB}"
echo "MySQL:             ${MYSQL}"
echo "Execution Account: ${ACCOUNT}"

if [[ ${DISPLAYHELP} == "X" ]]; then
  echo "Required parameters:"
	echo "  -t : Table Name"
  echo "Optional parameters:"
	echo "  -d : Database Name (Defaults to SAP eHANA for cluster)"
	exit 0
fi

mysql -uhadoopFWork --password="$(cat /eip_interfaces/${ACCOUNT}/MySQL.password)" -Dhadoop_job_framework -h"${MYSQL}" --execute="select * from source_table_details where table_name  in (${TABLE}) and database_name in (${DB}) ;delete from source_table_details where table_name  in (${TABLE}) and database_name in (${DB}) ;delete from source_column_details where table_name  in (${TABLE}) and database_name in (${DB}) ;select * from source_table_details where table_name  in (${TABLE}) and database_name in (${DB}) ;"
