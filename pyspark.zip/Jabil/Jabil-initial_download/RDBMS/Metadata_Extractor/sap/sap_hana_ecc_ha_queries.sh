#!/bin/bash
# /DIF/RDBMS/Metadata_Extractor/sap/sap_hana_ecc_ha_queries.sh
# Copyright (c) 2019 Jabil Inc.
# 
# This script contains common code for generating metadata queries

#Location of the csv files created (based on the directory we're executing from)
export Output_File_Path="${DIR}/Output_Files/sap_hana/${DB_Name}"

if [ ! -d "${Output_File_Path}" ]
then
  mkdir -p "${Output_File_Path}"
  echo "directory created"
fi

export file_Name1="Table_Metadata_Output.txt"
export file_Name2="Column_Metadata_output.txt"
export file_Name3="template_table.txt"

export output_file1="${Output_File_Path}/${file_Name1}"
export output_file2="${Output_File_Path}/${file_Name2}"
export output_file3="${Output_File_Path}/${file_Name3}"

#connection
export connection="jdbc:${DB_Type}://${IP_Hostname}:${PORT_Name}/?currentschema=${Schema_Name}"

export Driver="com.sap.db.jdbc.Driver"

#query

#SAP Query for generating file 1
export query1="select 
   '$IP_Hostname' AS ip_hostname
  ,'$Server_Name' AS server_name
  ,'$Instance_Name' AS  instance_name
  ,'$PORT_Name' AS tcp_port
  ,d.DATABASE_NAME as DATABASE_NAME
  ,v.SCHEMA_NAME as TABLE_SCHEMA
  ,substring(v.VIEW_NAME,${SUBSTR_1}) as TABLE_NAME 
from M_DATABASE d,VIEWS v 
where schema_name='_SYS_BIC' 
and v.VIEW_NAME in (${FULL_LOAD_TABLE}) 
and \\\$CONDITIONS
UNION
select 
   '$IP_Hostname' AS ip_hostname
  ,'$Server_Name' AS server_name
  ,'$Instance_Name' AS  instance_name
  ,'$PORT_Name' AS tcp_port
  ,d.DATABASE_NAME as DATABASE_NAME
  ,v.SCHEMA_NAME as TABLE_SCHEMA
  ,substring(v.VIEW_NAME, ${SUBSTR_1},${SUBSTR_2}) as TABLE_NAME
from M_DATABASE d,VIEWS v 
where schema_name='_SYS_BIC' 
and v.VIEW_NAME in (${INCR_LOAD_TABLE}) 
and \\\$CONDITIONS ;"


#SAP Query for generating file 2
export query2="SELECT
   ROW_NUMBER() OVER (ORDER BY TABLE_NAME,COLUMN_NAME ASC) AS SRNO,
  '$IP_Hostname' AS ip_hostname,
  '$Server_Name' AS server_name,
  '$Instance_Name' AS  instance_name,
  '$PORT_Name' AS tcp_port,
  DATABASE_NAME,
  TABLE_SCHEMA,
  TABLE_NAME,
  COLUMN_NAME,
  DATA_TYPE,
  PRECISON_SCALE,
  CONSTRAINT_TYPE,
  VIEW_NAME
from
(
  select DATABASE_NAME,
    TABLE_SCHEMA,
    TABLE_NAME,
    COLUMN_NAME,
    DATA_TYPE,
    PRECISON_SCALE,
    CONSTRAINT_TYPE,
    VIEW_NAME,
    row_number() over ( Partition by TABLE_SCHEMA,table_name,column_name order by CONSTRAINT_TYPE desc)rn
  from
  (
    select  distinct d.DATABASE_NAME  as DATABASE_NAME,
      tc.SCHEMA_NAME as TABLE_SCHEMA,
      substring(tc.VIEW_NAME,${SUBSTR_1}) as  TABLE_NAME,
      tc.COLUMN_NAME as COLUMN_NAME,tc.DATA_TYPE_NAME as DATA_TYPE,
      CASE WHEN tc.DATA_TYPE_NAME IN ('INTEGER','TINYINT','SMALLINT','FLOAT','REAL','DECIMAL','SMALLDECIMAL')
        THEN concat(concat(tc.LENGTH,','),tc.SCALE)
        ELSE cast(tc.LENGTH AS varchar) END  as PRECISON_SCALE,
      'NULL' as CONSTRAINT_TYPE , 
      tc.VIEW_NAME as VIEW_NAME 
    from M_DATABASE d 
    inner join 
      VIEW_COLUMNS tc on 1=1 
    and tc.VIEW_NAME in (${FULL_LOAD_TABLE})
  )A
)B 
where rn=1 
  and TABLE_SCHEMA='_SYS_BIC' 
  and VIEW_NAME in (${FULL_LOAD_TABLE}) 
  and \\\$CONDITIONS
UNION
SELECT
  ROW_NUMBER() OVER (ORDER BY TABLE_NAME,COLUMN_NAME ASC) AS SRNO,
  '$IP_Hostname' AS ip_hostname,
  '$Server_Name' AS server_name,
  '$Instance_Name' AS  instance_name,
  '$PORT_Name' AS tcp_port,
  DATABASE_NAME,
  TABLE_SCHEMA,
  TABLE_NAME,
  COLUMN_NAME,
  DATA_TYPE,
  PRECISON_SCALE,
  CONSTRAINT_TYPE,
  VIEW_NAME
from
(
  select DATABASE_NAME,
    TABLE_SCHEMA,
    TABLE_NAME,
    COLUMN_NAME,
    DATA_TYPE,
    PRECISON_SCALE,
    CONSTRAINT_TYPE,
    VIEW_NAME,
    row_number() over ( Partition by TABLE_SCHEMA,table_name,column_name order by CONSTRAINT_TYPE desc)rn
  from
  (
    select
      distinct d.DATABASE_NAME  as DATABASE_NAME,
      tc.SCHEMA_NAME as TABLE_SCHEMA,
      substring(tc.VIEW_NAME,${SUBSTR_1},${SUBSTR_2}) as  TABLE_NAME,
      tc.COLUMN_NAME as COLUMN_NAME,tc.DATA_TYPE_NAME as DATA_TYPE,
      CASE 
        WHEN tc.DATA_TYPE_NAME IN ('INTEGER','TINYINT','SMALLINT','FLOAT','REAL','DECIMAL','SMALLDECIMAL') 
        THEN concat(concat(tc.LENGTH,','),tc.SCALE)  
        ELSE cast(tc.LENGTH AS varchar) 
        END  as PRECISON_SCALE,
      CASE 
        WHEN c.IS_PRIMARY_KEY='TRUE' 
          and substring(tc.VIEW_NAME, ${SUBSTR_1},${SUBSTR_2})=c.TABLE_NAME 
          and tc.COLUMN_NAME=c.COLUMN_NAME 
        THEN 'PRIMARY KEY' 
        ELSE 'NULL' 
        END as CONSTRAINT_TYPE, 
      tc.VIEW_NAME as VIEW_NAME 
    from M_DATABASE d 
    inner join VIEW_COLUMNS tc 
      on 1=1 
    inner join CONSTRAINTS c
      on substring(tc.VIEW_NAME, ${SUBSTR_1},${SUBSTR_2}) =c.TABLE_NAME 
      and c.schema_name ='ECC' 
      and tc.VIEW_NAME in (${INCR_LOAD_TABLE})
  )A
)B  
where rn=1 
  and TABLE_SCHEMA='_SYS_BIC' 
  and VIEW_NAME in (${INCR_LOAD_TABLE}) 
  and \\\$CONDITIONS;"

#SAP Query for generating file 3
export query3="select 
   '$IP_Hostname' AS ip_hostname
  ,'$Server_Name' AS server_name
  ,'$Instance_Name' AS  instance_name
  ,'$PORT_Name' AS tcp_port
  ,DATABASE_NAME
  ,TABLE_SCHEMA
  ,TABLE_NAME
  ,CDC_COLUMN
  ,LAST_EXTRACTED_DATETIME
  ,SPLIT_BY_COLUMN
  ,SIZE
  ,LOAD_TYPE
  ,CREATE_DDL
  ,SEQUENCE
  ,VIEW_NAME
From
(
  select  distinct 
    d.DATABASE_NAME  as DATABASE_NAME,
    tc.SCHEMA_NAME as TABLE_SCHEMA,
    substring(tc.VIEW_NAME,${SUBSTR_1}) as  TABLE_NAME,
    'NULL' as CDC_COLUMN,
    '1900-01-01 00:00:00.000' as LAST_EXTRACTED_DATETIME,
    'SEQGEN' as SPLIT_BY_COLUMN,
    cast(t.TABLE_SIZE as varchar) as SIZE,
    'FR' as LOAD_TYPE,
    'Y' as CREATE_DDL,
    1 as SEQUENCE,
    tc.VIEW_NAME as  VIEW_NAME from
    M_DATABASE d 
  inner join VIEW_COLUMNS tc 
    on 1=1 
  left outer join M_TABLES t 
    on substring(tc.VIEW_NAME,${SUBSTR_1})=t.TABLE_NAME 
    and t.SCHEMA_NAME='ECC'
)X 
where TABLE_SCHEMA='_SYS_BIC' 
  and VIEW_NAME in (${FULL_LOAD_TABLE}) 
  and \\\$CONDITIONS
UNION
select 
   '$IP_Hostname' AS ip_hostname
  ,'$Server_Name' AS server_name
  ,'$Instance_Name' AS  instance_name
  ,'$PORT_Name' AS tcp_port
  ,DATABASE_NAME
  ,TABLE_SCHEMA
  ,TABLE_NAME
  ,CDC_COLUMN
  ,LAST_EXTRACTED_DATETIME
  ,SPLIT_BY_COLUMN
  ,SIZE
  ,LOAD_TYPE
  ,CREATE_DDL
  ,SEQUENCE
  ,VIEW_NAME
From
(
  select  distinct 
    d.DATABASE_NAME  as DATABASE_NAME,
    tc.SCHEMA_NAME as TABLE_SCHEMA,
    substring(tc.VIEW_NAME,${SUBSTR_1},${SUBSTR_2}) as  TABLE_NAME,
    'NULL' as CDC_COLUMN,
    '1900-01-01 00:00:00.000' as LAST_EXTRACTED_DATETIME,
    'SEQGEN' as SPLIT_BY_COLUMN,
    cast(t.TABLE_SIZE as varchar) as SIZE,
    'FR' as LOAD_TYPE,
    'Y' as CREATE_DDL,
    1 as SEQUENCE,
    tc.VIEW_NAME as  VIEW_NAME 
  from M_DATABASE d 
  inner join VIEW_COLUMNS tc 
    on 1=1 
  left outer join M_TABLES t 
    on substring(tc.VIEW_NAME,${SUBSTR_1},${SUBSTR_2})=t.TABLE_NAME 
    and t.SCHEMA_NAME='ECC'
)X 
where TABLE_SCHEMA='_SYS_BIC' 
  and VIEW_NAME in (${INCR_LOAD_TABLE}) 
  and \\\$CONDITIONS ;"
