#!bin\bash

###Script to insert records from the given file to stg_source_db_details and than to source_db_details

###Below are the parameters which have to be passed to run the script.
#Eg : Below are the parameters and samle values that must be passed to the script
             #Filename =/grid/0/interfaces/code/DIF/RDBMS/Metadata_Extractor/MES_Source_DB_Details_File.csv
             #servername='VNRSQLV02B'
             #instance name='INST1'
             #username
             #password

Filename=$1
Servername=$2
Instancename=$3
Username=$4
Password=$5
logged_user=`whoami`

###MySQL database credentials are available in the file IP_Parameter_File.txt
source /eip_interfaces/code/DIF/RDBMS/Metadata_Extractor/IP_Parameter_File.txt

###Truncating the table stg_source_db_details before the load
mysql --defaults-file=/home/$logged_user/.mysql.cnf -h$IP -D$databasename -e "truncate table stg_source_db_details;"
echo 'Table stg_source_db_details has been truncated.'


###Load the table stg_source_db_details from the given csv file
mysql --defaults-file=/home/$logged_user/.mysql.cnf -h$IP -D$databasename -e "LOAD DATA local INFILE '$Filename' INTO TABLE stg_source_db_details fields terminated by ',' lines terminated by '\n' IGNORE 1 LINES;"
Count=$(mysql --defaults-file=/home/$logged_user/.mysql.cnf -h$IP -D$databasename -N -e"(select count(1) as count from stg_source_db_details)")
echo 'Number of records loaded in the table stg_source_db_details is '$Count'.'


###Check if the count of table stg_source_db_details >=1, if yes, then insert the records into the table source_db_details
if [ "${Count}">=1 ]
then
mysql --defaults-file=/home/$logged_user/.mysql.cnf -h$IP -D$databasename -e "CALL sp_GetSourceDBDetails('$Servername','$Instancename','$Username','$Password');"
echo 'Records have been inserted into the table source_db_details.'
else 
echo 'No records were inserted into the table source_db_details.'
fi
