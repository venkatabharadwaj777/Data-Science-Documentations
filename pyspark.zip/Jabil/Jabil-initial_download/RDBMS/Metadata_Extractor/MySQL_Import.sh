#!/bin/bash
# MySQL_Import.sh
# Copyright (c) 2019 Jabil Inc.
#
# Script to run queries to import table and column details from CSV file into MySQL table
# to read a file we use source and it will read the corresponding parameters like property file in 
# java # to read a file we use source and it will read the corresponding parameters like property file in java # to read a file we use source and it will read the corresponding parameters like property file in java

# Import parameters
DB_Type="$1"
DB_Name="$2"
Logical_Name="$3"
Table_Name="$4"

echo "Parameters for MySQL_Import.sh:"
echo "Parameter 1 - DB Type:       ${DB_Type}"
echo "Parameter 2 - DB Name:       ${DB_Name}"
echo "Parameter 3 - Logical Name:  ${Logical_Name}"
echo "Parameter 4 - Table Name:    ${Table_Name}"

if [[ "$#" -ne 3 ]];
then
  if [[ "$#" -ne 4 ]]; then
    echo "Incorrect number of parameters Passed: $#"
    exit 1; 
  fi
fi

if [[ "${Table_Name}" != "" ]]; then 
  Table_File_Name="${Logical_Name}_${Table_Name}"
else
  Table_File_Name="${Logical_Name}"
fi
echo "Table File Name:             ${Table_File_Name}"

# Get the directory we're executing from
export SOURCE="${BASH_SOURCE[0]}"
while [ -h "${SOURCE}" ]; do # resolve $SOURCE until the file is no longer a symlink
  export DIR="$( cd -P $( dirname ${SOURCE} ) > /dev/null 2>&1 && pwd )"
  export SOURCE="$(readlink ${SOURCE})"
  # if $SOURCE was a relative symlink, we need to resolve it relative to the path 
  # where the symlink file was located
  [[ ${SOURCE} != /* ]] && SOURCE="${DIR}/${SOURCE}" 
done
export DIR="$( cd -P $( dirname ${SOURCE} ) >/dev/null 2>&1 && pwd )"

# Get the parameters from a file
source "${DIR}/IP_Parameter_File.txt"

# Generate the table metadata queries
source "${DIR}/${DB_Type}/${Table_File_Name}.conf"
logged_user="$(whoami)"
MYSQL_DB_NAME="${databasename}"
#Input_File_location="${Input_location}"
Input_File_location="${Output_File_Path}"

#file1=$(grep "file_Name1=" $config_file | cut -d'=' -f2);
#file2=$(grep "file_Name2=" $config_file | cut -d'=' -f2);
#file3=$(grep "file_Name3=" $config_file | cut -d'=' -f2);

#file1=$file_Name1
#file2=$file_Name2
#file3=$file_Name3

#echo "$file_Name1 $file_Name2 $file_Name3"
echo "Output File 1: ${output_file1}"
echo "Output File 2: ${output_file2}"
echo "Output File 3: ${output_file3}"
#Input_file1=$Input_File_location/$file1
#Input_file2=$Input_File_location/$file2
#Input_file3=$Input_File_location/$file3

mysql --defaults-file=/home/$logged_user/.mysql.cnf -D$MYSQL_DB_NAME -h$IP_Instance -se "LOAD DATA local INFILE '$output_file1' INTO TABLE source_table_details fields terminated by '\t' lines terminated by '\n';"
#echo "mysql -u$MYSQL_DB_USER -p$MYSQL_DB_PWD -D$MYSQL_DB_NAME -h$IP_Instance -se\"LOAD DATA local INFILE \'${output_file1}\' INTO TABLE source_table_details fields terminated by \'\\t\' lines terminated by \'\\n\';\""
#mysql -u$MYSQL_DB_USER -p$MYSQL_DB_PWD -D$MYSQL_DB_NAME -h$IP_Instance -se\"LOAD DATA local INFILE \'${output_file1}\' INTO TABLE source_table_details fields terminated by \'\\t\' lines terminated by \'\\n\';\"
if [ $? == 0 ]
then 
  touch "${TouchFile_Location}/_MYSQL_LOAD_SOURCE_TABLE_DETAILS_SUCCESS"
else
  touch "${TouchFile_Location}/_MYSQL_LOAD_SOURCE_TABLE_DETAILS_FAIL"
fi
mysql --defaults-file=/home/$logged_user/.mysql.cnf -D$MYSQL_DB_NAME -h$IP_Instance -se "LOAD DATA local INFILE '$output_file2' INTO TABLE source_column_details fields terminated by '\t' lines terminated by '\n';"
#mysql -u$MYSQL_DB_USER -p$MYSQL_DB_PWD -D$MYSQL_DB_NAME -h$IP_Instance -se\"LOAD DATA local INFILE \'${output_file2}\' INTO TABLE source_column_details fields terminated by \'\\t\' lines terminated by \'\\n\';\"
if [ $? == 0 ]
then 
  touch "${TouchFile_Location}/_MYSQL_LOAD_SOURCE_COLUMN_DETAILS_SUCCESS"
else
  touch "${TouchFile_Location}/_MYSQL_LOAD_SOURCE_COLUMN_DETAILS_FAIL"
fi
mysql --defaults-file=/home/$logged_user/.mysql.cnf -D$MYSQL_DB_NAME -h$IP_Instance -se "LOAD DATA local INFILE '$output_file3' INTO TABLE stg_source_table_details fields terminated by '\t' lines terminated by '\n';"
#mysql -u$MYSQL_DB_USER -p$MYSQL_DB_PWD -D$MYSQL_DB_NAME -h$IP_Instance -se\"LOAD DATA local INFILE \'${output_file3}\' INTO TABLE stg_source_table_details fields terminated by \'\\t\' lines terminated by \'\\n\';\"
if [ $? == 0 ]
then 
  touch "${TouchFile_Location}/_MYSQL_LOAD_STG_SOURCE_TABLE_DETAILS_SUCCESS"
else
  touch "${TouchFile_Location}/_MYSQL_LOAD_STG_SOURCE_TABLE_DETAILS_FAIL"
fi
