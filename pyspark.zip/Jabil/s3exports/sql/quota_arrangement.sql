select * from (
    select
        concat_ws('_', DataSourceId, plantcode, materialcode) as MaterialKey
        , concat_ws('-',profitcenter,plantcode) profitplant
        , DataSourceId
        , coalesce( plantcode, '') as PlantCode
        , coalesce( materialcode, '') as MaterialCode
        , coalesce( profitcenter,'') as ProfitCenter
        , coalesce( corporationdsname, '') as CorporationdsName
        , coalesce( corporationname, '') as CorporationName
        , coalesce( suppliercorporationdscode, '') as SupplierCorporationdsCode
        , coalesce( materialsourcetypecode, '') as MaterialSourceTypeCode
        , coalesce( materialtsourcereference, '') as MaterialtSourceReference
        , coalesce( effectivefromdate, '') EffectiveFromDate
        , coalesce( effectivetodate, '') as EffectiveToDate
        , coalesce( mrpindicator, '') MrpIndicator
        , coalesce( cast(fixedleadtime as string), '') as FixedLeadTime
        , coalesce( cast(maximumlotsize as string), '') as MaximumLotSize
        , coalesce( cast(minimumlotsize as string), '') as MinimumLotSize
        , coalesce( cast(multipleqty as string), '') as MultipleQty
        , coalesce( planningtimefence, '') as PlanningTimefence
        , coalesce( priority, '') as Priority
        , coalesce( cast(targetratio as string), '') TargetRatio
        , coalesce( cast(todateqty as string), '') ToDateQty
        , coalesce( transferplantcode, '') TransferPlantCode
        , coalesce( transferplantmaterialcode, '') as TransferPlantMaterialCode
        , coalesce( amlreference, '') as AmlReference
        , coalesce( statuscode, '') as StatusCode
        , coalesce( dscreateuser, '') as DsCreateUser
        , coalesce( dscreatedts, '') as DsCreatedTs
        , coalesce( deleteflag, '') as DeleteFlag
        , coalesce( corporationdstypecode, '') as CorporationDsTypeCode
        , coalesce( purchasingorganizationcode, '') as PurchasingOrganizationCode
        , coalesce( roundingprofile, '') as RoundingProfile
        , coalesce( procurementtype, '') as ProcurementType
        , coalesce( cast(maxquantity as string), '') as MaxQuantity
        , coalesce( cast(quotebasequantity as string), '') as QuoteBaseQuantity
        , coalesce( onceonlyindicator, '') as OnceOnlyIndicator
        , coalesce( cast(maximumreleasequantity as string), '') as MaximumReleaseQuantity
        , coalesce( periods, '') as Periods
        , current_date as snapshotdate
    from dimensions.vw_sl_quotaarrangement
) qa