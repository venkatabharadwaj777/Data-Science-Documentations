select
 CONCAT_WS('_', DataSourceId, PlantCode, MaterialCode) as MaterialKey
, DataSourceId
, PlantCode
, PlantName
, MaterialCode
, CustomerMaterialCode
, MaterialTypeCode
, AbcCode
, MaterialGroupCode
, CustomerGroupCode
, ProductGroupCode
, PlanningCalendarCode
, OrderPolicyCode
, MaterialDescription
, PlannerCode
, BuyerCode
, UnitOfMeasureCode
, Yield
, MinimumLotSize
, MaximumLotSize
, MultipleQuantity
, SafetyStockQuantity
, ReorderPointQuantity
, MaximumStockQuantity
, LotSizeCode
, PlanningTimeFence
, DockToStockLeadTime
, SafetyLeadTime
, FixedLeadTime
, BatchManagedFlag
, BeforeForecastInterval
, AfterForeCastInterval
, PriceUnit
, StandardUnitCostP0
, StandardUnitCostP1
, SellUnitPriceP0
, SellUnitPriceP1
, StandardUnitCostUSD
, SellUnitPriceUSD
, P1EffectiveFromDate
, AssemblyScrapCount
, ComponentScrapCount
, PlanningStrategyGroup
, ProfitCenter
, DeleteFlag
, DsCreatedTs
, DsUpdatedTs
, RecordExist
, LocalCurrencyToUsdExchangeRate
, P2EffectiveFromDate
, P3EffectiveFromDate
, P0EffectiveFromDate
, MaterialLedgerActiveFlag
, RangeOfCoverageProfile
, SafetyTimeIndicator
, Mrpprofile
, MrpGroup
, DiscontinuationIndicator
, DiscontinuationEffectiveOutDate
, FollowUpMaterial
, CommodityImportCode
, IndustryStandardDescription
, SafetyInStock
, FixedLotSize
, PriceControlIndicator
, StdUnitCostPlannedCurrent
, MovingAverageUnitCost
, StkValueQuantity
, StkValueCurrent
, StkValueMovingAverageWhenStandardPriceControl
, StdUnitCostPlannedNext
, MlPriceControlIndicator
, MlMovingAvgUnitCostUsd
, MlCurrencyCode
, LocalCurrencyCode
, MlStkValueCurrentUsd
, MlStkValueMovingAvgWhenStdPriceControlUsd
, MlStdUnitCostUsd
, MlPriceUnit
, StkValueAtStdUnitCost
, StkValueAtMovingAvgCost
, MlStkValueAtStdUnitCostUsd
, MlStkValueAtMovingAvgCostUsd
, MlPeriodCurrentStdCostEstimate
, MlFiscalYearCurrentStdCostEstimate
, AutoPoreScheduleStrategy
, GenItemCat
, UpdatedOn
, MaterialTypeStdCode
, Description
, MakeBuy
, QuotaArrangementUsage
, profitplant
, snapshotdate
, CustomerName
, SectorName
, DivisionName
, StrategicPurchasingFlag
, BuyerName
, DocumentNumber
, MaterialType
, BulkIndicator
, MrpController
, MrpControllerName
, MaterialGroup5
 from (
  select
  datasourceid as DataSourceId
, plantcode as PlantCode
, plantname as PlantName
, materialcode as MaterialCode
, customermaterialcode as CustomerMaterialCode
, materialtypecode as MaterialTypeCode
, abccode as AbcCode
, materialgroupcode as MaterialGroupCode
, customergroupcode as CustomerGroupCode
, productgroupcode as ProductGroupCode
, planningcalendarcode as PlanningCalendarCode
, orderpolicycode as OrderPolicyCode
, materialdescription as MaterialDescription
, plannercode as PlannerCode
, buyercode as BuyerCode
, unitofmeasuredscode as UnitOfMeasureCode
, yield as Yield
, minimumlotsize as MinimumLotSize
, maximumlotsize as MaximumLotSize
, multipleqty as MultipleQuantity
, safetystockqty as SafetyStockQuantity
, reorderpointqty as ReorderPointQuantity
, maximumstockqty as MaximumStockQuantity
, lotsizecode as LotSizeCode
, planningtimefence as PlanningTimeFence
, docktostockleadtime as DockToStockLeadTime
, safetyleadtime as SafetyLeadTime
, fixedleadtime as FixedLeadTime
, batchmanagedflag as BatchManagedFlag
, beforeforecastinterval as BeforeForecastInterval
, afterforecastinterval as AfterForeCastInterval
, priceunit as PriceUnit
, stdunitcostp0 as StandardUnitCostP0
, stdunitcostp1 as StandardUnitCostP1
, sellunitpricep0 as SellUnitPriceP0
, sellunitpricep1 as SellUnitPriceP1
, standardunitcostusd as StandardUnitCostUSD
, sellunitpriceusd as SellUnitPriceUSD
, cast(case when p1effectivefromdate = '00000000' then NULL else concat_ws('-', substr(p1effectivefromdate,1,4), substr(p1effectivefromdate,5,2), substr(p1effectivefromdate,7) ) end as date) as P1EffectiveFromDate
, assemblyscrappct as AssemblyScrapCount
, componentscrappct as ComponentScrapCount
, planningstrategygroup as PlanningStrategyGroup
, profitcenter as ProfitCenter
, case when deleteflag = 'X' then 1 else 0 end as DeleteFlag
, cast(case when dscreatedts = '00000000' then NULL else concat_ws('-', substr(dscreatedts,1,4), substr(dscreatedts,5,2), substr(dscreatedts,7)) end as date) DsCreatedTs
, cast(case when dsupdatedts = '00000000' then NULL else concat_ws('-', substr(dsupdatedts,1,4), substr(dsupdatedts,5,2), substr(dsupdatedts,7)) end as date) DsUpdatedTs
, recordexist as RecordExist
, localcurrencytousdexchangerate as LocalCurrencyToUsdExchangeRate
, cast(case when p2effectivefromdate = '00000000' then NULL else concat_ws('-', substr(p2effectivefromdate,1,4), substr(p2effectivefromdate,5,2), substr(p2effectivefromdate,7) ) end as date) P2EffectiveFromDate
, cast(case when p3effectivefromdate = '00000000' then NULL else concat_ws('-', substr(p3effectivefromdate,1,4), substr(p3effectivefromdate,5,2), substr(p3effectivefromdate,7) ) end as date) P3EffectiveFromDate
, cast(case when p0effectivefromdate = '00000000' then NULL else concat_ws('-', substr(p0effectivefromdate,1,4), substr(p0effectivefromdate,5,2), substr(p0effectivefromdate,7) ) end as date) P0EffectiveFromDate
, case when materialledgeractiveflag = 'X' then 1 else 0 end as MaterialLedgerActiveFlag
, rangeofcoverageprofile as RangeOfCoverageProfile
, cast ( case when safetytimeindicator = '' then NULL else SafetyTimeIndicator end as int) as SafetyTimeIndicator
, mrpprofile as MrpProfile
, mrpgroup as MrpGroup
, cast(discontinuationindicator as int) as DiscontinuationIndicator
, cast(case when discontinuationeffectiveoutdate = '00000000' then NULL else concat_ws('-', substr(discontinuationeffectiveoutdate,1,4), substr(discontinuationeffectiveoutdate,5,2), substr(discontinuationeffectiveoutdate,7) ) end as date) DiscontinuationEffectiveOutDate
, followupmaterial as FollowUpMaterial
, commodityimportcode as CommodityImportCode
, industrystddesc as IndustryStandardDescription
, cast(safetyinstock as int) as SafetyInStock
, cast(fixedlotsize as int) as FixedLotSize
, pricecontrolindicator as PriceControlIndicator
, stdunitcostplannedcurrent as StdUnitCostPlannedCurrent
, movingavgunitcost as MovingAverageUnitCost
, stkvaluedqty as StkValueQuantity
, stkvaluecurrent as StkValueCurrent
, stkvaluemovingavgwhenstdpricecontrol as StkValueMovingAverageWhenStandardPriceControl
, stdunitcostplannednext as StdUnitCostPlannedNext
, mlpricecontrolindicator as MlPriceControlIndicator
, mlmovingavgunitcostusd as MlMovingAvgUnitCostUsd
, mlcurrencycode as MlCurrencyCode
, localcurrencycode as LocalCurrencyCode
, mlstkvaluecurrentusd as MlStkValueCurrentUsd
, mlstkvaluemovingavgwhenstdpricecontrolusd as MlStkValueMovingAvgWhenStdPriceControlUsd
, mlstdunitcostusd as MlStdUnitCostUsd
, mlpriceunit as MlPriceUnit
, stkvalueatstdunitcost as StkValueAtStdUnitCost
, stkvalueatmovingavgcost as StkValueAtMovingAvgCost
, mlstkvalueatstdunitcostusd as MlStkValueAtStdUnitCostUsd
, mlstkvalueatmovingavgcostusd as MlStkValueAtMovingAvgCostUsd
, mlperiodcurrentstdcostestimate as MlPeriodCurrentStdCostEstimate
, mlfiscalyearcurrentstdcostestimate as MlFiscalYearCurrentStdCostEstimate
, autoporeschedulestrategy as AutoPoreScheduleStrategy
, genitemcat as GenItemCat
, cast(updatedOn as string) as UpdatedOn
, materialtypestdcode as MaterialTypeStdCode
, description as Description
, makebuy as MakeBuy
, quotaarrangementusage as QuotaArrangementUsage
, concat_ws('-', profitcenter, plantcode) as profitplant
, current_date as snapshotdate
, customername as CustomerName
, sectorname as SectorName
, divisionname as DivisionName
, strategicpurchasingflag as StrategicPurchasingFlag
, buyername as BuyerName
, documentnumber as DocumentNumber
, materialtype as MaterialType
, if(bulkindicator='X', cast(1 as int), cast(0 as int)) as BulkIndicator
, mrpcontroller as MrpController
, mrpcontrollername as MrpControllerName
, materialgroupcode5 as MaterialGroup5
  from dimensions.vw_sl_materials sp
 )
 as materials
 