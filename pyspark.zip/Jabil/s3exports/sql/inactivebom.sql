SELECT 
datasourceid        AS DataSourceID
,plantcode          AS PlantCode
,materialcode       AS MaterialCode
, current_date as SnapshotDate 
from incontrol.vw_sl_inactive_bom_materials
