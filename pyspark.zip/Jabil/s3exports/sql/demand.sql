 select 
 datasourceid
,concat_ws('-',profitcenter,plantcode) profitplant
,plantcode
,coalesce(profitcenter,'') as profitcenter
,cast(snapshotdate as string) as snapshotdate
,coalesce(mrpnumber,'') as mrpnumber
,coalesce( mrpitem,'') as mrpitem
,coalesce( mrparea,'') as mrparea
,coalesce( mrpplanningsegment,'') as mrpplanningsegment
,coalesce( cast(receiptrequirementdts as string),'') as receiptrequirementdts
,coalesce( cast(deliveryfinishdts as string),'') as deliveryfinishdts
,coalesce( cast(startreleasedts as string),'') as startreleasedts
,coalesce( cast(openingdts  as string),'') as openingdts
,coalesce( cast(mrpcalcdate as string),'') as mrpcalcdate
,coalesce( mrpelementindicator,'') as mrpelementindicator
,  quantity
,coalesce( documentnumber,'') as documentnumber
,coalesce( documentitem,'') as documentitem
,coalesce( documentscheduleline,'') as documentscheduleline
,coalesce( parentmaterialcode,'') as parentmaterialcode
,coalesce( receiptissueindicator,'') as receiptissueindicator
,coalesce( materialcode,'') as materialcode
,coalesce( mrpscenario,'') as mrpscenario
,coalesce( fixedvendor,'') as fixedvendor
,coalesce( mpnmaterial,'') as mpnmaterial
,coalesce( firmedorderflag,'') as firmedorderflag
,coalesce( firmedcomponentflag,'') as firmedcomponentflag
,coalesce( availability,'') as availability
,coalesce( documentnumber2,'') as documentnumber2
,coalesce( mrprecommendationcode,'') as mrprecommendationcode
,coalesce( mrprecommendationcode2,'') as mrprecommendationcode2
,coalesce( poordertype,'') as poordertype
,coalesce( planningproductionplant,'') as planningproductionplant
,coalesce( productionversion,'') as productionversion
,coalesce( cast(reqdate as string) ,'') as reqdate
,coalesce( mrptypecode,'') as mrptypecode
,coalesce( mrptypestdcode,'') as mrptypestdcode
,coalesce( baseunitofmeasuredscode,'') as baseunitofmeasuredscode
,coalesce(processingrule,'') as processingrule
,coalesce(cast(cancellationleadtime as string),'') as cancellationleadtime
,coalesce( ncnrflag, '') as ncnrflag
 from
 (
 select 
 *  
 from
 incontrol.vw_sl_mrp_tmp
  WHERE  mrptypestdcode != 'SubContractor Requirement'
    OR ( mrpplanningsegment != ''
        AND    mrpplanningsegment IS NOT NULL )
) demand 