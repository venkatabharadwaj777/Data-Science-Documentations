select 

  coalesce(customername,'') as customername
, coalesce(materialgroupcode,'') as materialgroupcode
, coalesce(productgroupcode,'') as productgroupcode 

from  incontrol.vw_sl_customer_reference