select pi.* from
    ( SELECT
          concat_ws('-', profitcenter, plantcode)     			AS profitplant
        ,  datasourceid							  			AS DataSourceID
        , coalesce(purchasedocumentnumber, '')				AS PurchaseDocumentNumber
        , coalesce(purchasedocumentitem, '')				AS		PurchaseDocumentItem
        , coalesce(materialcode, '')				AS MaterialCode
        , coalesce(companycode, '')				AS CompanyCode
        , coalesce(plantcode, '')				AS PlantCode
        , coalesce(manufacturerdscode, '')				AS ManufacturerDsCode
        , coalesce(manufacturerdsname, '')				AS ManufacturerDsName
        , coalesce(corporationname, '')				AS CorporationName
        , coalesce(purchasequantity, '')				AS PurchaseQuantity
        , coalesce(numberofinforecord, '')				AS NumberOfInfoRecord
        , coalesce(receivingstoragelocation, '')				AS ReceivingStorageLocation
        , coalesce(manufacturerpartcode, '')				AS Manufacturerpartcode
        , coalesce(netprice, '')				AS NetPrice
        , coalesce(priceunit, '')				AS PriceUnit
        , coalesce(deliverycompleteflag, '')				AS DeliveryCompleteFlag
        , coalesce(cumulativequantity, '')				AS CumulativeQuantity
        , coalesce(cast(cumulativequantityreconciledts as STRING), '')				AS CumulativeQuantityReconcileDts
        , coalesce(firmzone, '')				AS FirmZone
        , coalesce(tradeoffzone, '')				AS TradeOffZone
        , coalesce(purchaseitemcategory, '')				AS PurcaseItemCategory
        , coalesce(accountassignment, '')				AS AccountAssignment
        , coalesce(nonvaluedflag, '')				AS NonValuedFlag
        , coalesce(shippinginstructions, '')				AS ShippingInstructions
        , coalesce(incoterms1, '')				AS INCOTERMS1
        , coalesce(incoterms2, '')				AS INCOTerms2
        , coalesce(specialstockscode, '')				AS SpecialStocksCode
        , coalesce(lasttransmissiondts, '')				AS LastTransmissionDts
        , coalesce(lasttransmissionnumber, '')				AS LastTransmissionNumber
        , coalesce(maximumfirmquantity, '')				AS MaximumFirmQuantity
        , coalesce(maximumtradeoffquantity, '')				AS MaximumTradeOffQuantity
        , coalesce(cancellationleadtime, '')				AS CancellationLeadTime
        , coalesce(deleteflag, '')				AS DeleleteFlag
        , coalesce(cast(dsupdatedts as string), '')				AS DsUpdatedTs
        , coalesce(itemcomment, '')				AS ItemComment
        , coalesce(amlreference, '')				AS AMLReference
        , coalesce(orderunitofmeasuredscode, '')				AS OrderUnitOfMeasuredsCode
        , coalesce(baseunitofmeasure, '')				AS BaseUnitOfMeasure
        , coalesce(poblocked, '')				AS POBlocked
        , coalesce(poreminder1, '')				AS POReminder1
        , coalesce(poreminder2, '')				AS POReminder2
        , coalesce(crossrefdocnumber, '')				AS CrossRefDocNumber
        , coalesce(crossrefdocitem, '')				AS CrossRefDocItemefDocItem
        , coalesce(cast(updatedon as string), '')				AS UpdatedOn
        , coalesce(requirementnumber, '')				AS RequiredNumber
        , coalesce(requestedby, '')				AS RequestedBy
        , coalesce(customer, '')				AS Customer
        , coalesce(vendorsubrange, '')				AS VendorSubRange
        , coalesce(goodprocessingtime, '')				AS GoodProcessingTime
        , coalesce(planneddeliverytime, '')				AS PlannedDeliveryTime
        , coalesce(confirmationcontrol  , '')				AS  ConfirmationControl
        , coalesce(returnsitemflag, '')				AS ReturnsItemFlag
        , coalesce(profitcenter, '')				AS ProfitCenter
        , current_date as snapshotdate
    FROM
         scm.vw_sl_purchaseitems
) pi