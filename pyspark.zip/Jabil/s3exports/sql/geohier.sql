select plantcode , plantname , campuscode , campusname, countrycode , countryname   , regioncode , regionname  from dimensions.vw_sl_hierarchy_plantgeo
