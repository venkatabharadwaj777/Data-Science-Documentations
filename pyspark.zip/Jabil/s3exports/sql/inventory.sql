Select
 concat_ws('-',profitcenter,plantcode) profitplant
, snapshotdate
, datasourceid
, coalesce(plantcode,'') as plantcode
, coalesce(profitcenter,'') as profitcenter
, coalesce(materialcode,'') as materialcode
, coalesce(batch,'') as batch
, coalesce(storagelocation,'') as storagelocation
, coalesce(locationname,'') as locationname
, coalesce(locationtypecode,'') as locationtypecode
, coalesce(stocktype,'') as stocktype
, coalesce(inventorytypecode,'') as inventorytypecode
, coalesce(specialstockindicator,'') as specialstockindicator
, coalesce(inventorytypestdcode,'') as inventorytypestdcode
, coalesce(nettableflag,'') as nettableflag
, consigned
, coalesce(vendorcode,'') as vendorcode
, coalesce(vendortype,'') as vendortype
, coalesce(vendorgroup,'') as vendorgroup
, coalesce(currencycode,'') as currencycode
, coalesce(datefrom,'') as datefrom
, coalesce(unitofmeasure,'') as unitofmeasure
, exchangerate
, quantity
, materialcost
, priceunit
, unitprice
, coalesce(divisionname,'') as divisionname
, coalesce(customername,'') as customername
, coalesce(sectorname,'') as sectorname
 from
 incontrol.vw_sl_inventory_tmp
