select
 CONCAT_WS('_', datasourceid, plantcode, materialcode) as MaterialKey
,datasourceid as DataSourceId
,plantcode  as PlantCode
,materialcode as MaterialCode
,commoditycdm as CommodityCDM
,commoditymaterialgroup as CommodityMaterialGroup
,commodity as Commodity  
  from  dimensions.vw_sl_materialcommodities 