select materialkey, datasourceid, plantcode, materialcode, profitcenter,materialdescription, bomalternativecode, assemblymaterialcode, assemblymaterialkey
, assemblyprofitcenter,assemblydescription,topassembly, hierarchy,quantity, effectivefromdate, effectivetodate, assemblycustomergroupcode, assemblyproductgroupcode   from incontrol.vw_sl_billofmaterialflat_tmp
