select
  datasourceid   AS DataSourceID
 , materialcode  AS MaterialCode
 , plantcode     AS PlantCode
 , profitcenter  AS ProfitCenter
 , maxposteddts  AS MaxPostedDts
 , profitplant   AS profitplant
 , snapshotdate  As SnapshotDate
 from (
 SELECT
 datasourceid
, materialcode
, plantcode
, profitcenter
, coalesce(cast(max(posteddts) as string),'') as maxposteddts
, concat_ws('-', profitcenter, plantcode) as profitplant
, current_date as snapshotdate
 from incontrol.vw_sl_shipmentdate
 group by datasourceid
, materialcode
, plantcode
, profitcenter
, concat_ws('-', profitcenter, plantcode)
, current_date
 ) as shipment
