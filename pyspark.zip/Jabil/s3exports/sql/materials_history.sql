select * from (
    SELECT
      concat_ws('-', marc_prctr, marc_werks)            AS profitplant
    , marc_mandt                                        AS DatasourceID
    , coalesce(marc_matnr, '')                          AS MaterialCode
    , coalesce(marc_werks, '')                          AS PlantCode
    , coalesce(cast(marc_plifz as string), '')          AS FixedLeadTime
    , coalesce(mara_mtart, '')                          AS MaterialType
    , coalesce(mara_matkl, '')                          AS MaterialGroupCode
    , coalesce(makt_maktx, '')                          AS Description
    , coalesce(makt_maktg, '')                          AS DescriptionUppercase
    , coalesce(cast(mbew_stprs as string), '')          AS StdUnitCostP0
    , coalesce(cast(mbew_zplp2 as string), '')          AS SellUnitPriceP0
    , coalesce(cast(mbew_peinh as string), '')          AS PriceUnit
    , coalesce(cast(marc_eisbe as string), '')          AS SafetyStockQty
    , coalesce(cast(marc_bstmi as string), '')          AS MinimumLotSize
    , coalesce(cast(marc_bstrf as string), '')          AS MultipleQty
    , coalesce(to_date(lead_date), '')                  AS SnapshotLeadTimeDate
    , coalesce(marc_prctr, '')                          AS ProfitCenter
    , coalesce(t001k_mlbwa, '')                         AS MaterialLedgerActiveFlag
    , coalesce(cast(mval_std_30 as string), '')         AS StandardUnitCostUSD
    , coalesce(cast(mval_pp2_30 as string), '')         AS SellUnitPriceUSD
    , coalesce(cast(marc_minbe as string), '')          AS ReorderPointQty
    , coalesce(cast(mval_peinh_30 as string), '')       AS PriceUnitUSD
    , coalesce(to_date(cc_edate), '')                   AS SnapshotDate
    FROM  domains.ha_parts_mondays
) mh