Select
 concat_ws('-', profitcenter, plantcode) as profitplant
, coalesce(profitcenter, '') as profitcenter
, coalesce(plantcode, '') as plantcode
, datasourceid
, cast(snapshotdate as string) as snapshotdate
, coalesce( divisionname, '') as divisionname
, coalesce( sectorname, '') as sectorname
, coalesce( customername, '') as customername
, coalesce( materialgroupcode, '') as materialgroupcode
, coalesce( materialcode, '') as materialcode
, coalesce( materialdescription, '') as materialdescription
, coalesce( materialtypestdcode, '') as materialtypestdcode
, coalesce( abccode, '') as abccode
, coalesce( makebuy, '') as makebuy
, coalesce(unitofmeasuredscode, '') as unitofmeasuredscode
, coalesce(cast( posteddts as string),'') as posteddts
, 'NULL' as inventorytypestdcode
, onhandquantitynonconsigned
, onhandquantityconsigned
, totalonhandquantity
, netmvmtquantitynonconsigned
, totalmvmtquantity
, agenonconsigned
, totalage
, standardunitcost
, pp2cost
 from
 incontrol.vw_sl_agedinventory_tmp
