select psl.* from (
    select
          concat_ws('_', DataSourceId, plantcode, materialcode) as MaterialKey
        , concat_ws('-',profitcenter,plantcode) profitplant
        , DataSourceId
        , coalesce( plantcode, '') as PlantCode
        , coalesce( materialcode, '') as MaterialCode
        , coalesce( profitcenter,'') as ProfitCenter
        , coalesce( corporationdsname, '') as CorporationDsName
        , coalesce( corporationname, '') as CorporationName
        , coalesce( suppliercorporationdscode, '') as SupplierCorporationDsCode
        , coalesce( materialsourcetypecode, '') as MaterialSourceTypeCode
        , coalesce( sequencenumber, '') as SequenceNumber
        , coalesce( materialsourcereference, '') as MaterialSourceReference
        , coalesce( cast(effectivefromdate as string), '') as EffectiveFromDate
        , coalesce( cast(effectivetodate as string), '') as EffectiveToDate
        , coalesce( mrpindicator, '') as MrpIndicator
        , coalesce( orderunitofmeasuredscode, '') as OrderUnitOfMeasureDsCode
        , coalesce( transferplantcode, '') as TransferPlantCode
        , coalesce( transfermaterialcode, '') as TransferMaterialCode
        , coalesce( amlreference, '') as AmlReference
        , coalesce( purchasedocumentnumber, '') as PurchaseDocumentNumber
        , coalesce( purchasedocumentitem, '') as PurchaseDocumentItem
        , coalesce( statuscode, '') as StatusCode
        , coalesce( corporationdstypecode, '') as CorporationDsTypeCode
        , coalesce( purchasingorganizationcode, '') as PurchasingOrganizationCode
        , coalesce( FixedSource, '') as FixedSource
        , coalesce( dscreateuser, '') as DsCreateUser
        , coalesce( cast(dscreatedts as string), '') as DsCreatedTs
        , current_date as snapshotdate
    from dimensions.vw_sl_purchasingsourcelist
) psl
