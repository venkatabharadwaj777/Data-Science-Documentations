SELECT
 concat_ws('_',datasourceid,plantcode,materialcode) AS MaterialKey
,  concat_ws('-', profitcenter, plantcode)     AS profitplant
, datasourceid                                AS DataSourceID
, plantcode                     AS PlantCode
, profitcenter                  AS ProfitCenter
, bomalternativecode            AS BomAlternativeCode
, assemblymaterialcode          AS AssemblyMaterialCode
, materialcode                  AS MaterialCode
, topassembly                                 AS TopAssembly
, hierarchy                     AS Hierarchy
, quantity                                    AS Quantity
, cast(effectivefromdate as date)        AS EffectiveFromDate
, cast(effectivetodate as date)          AS EffectiveToDate
, TotalDemand
, cast(snapshotdate as date)             AS SnapshotDate
 FROM  incontrol.vw_sl_billofmaterialflat_withdemand_tmp 
