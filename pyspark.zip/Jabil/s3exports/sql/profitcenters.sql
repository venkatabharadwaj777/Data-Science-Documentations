select parent,child,topflag,level,nodename as ProfitCenterName ,levelnumber,hierarchy from 
dimensions.vw_sl_hierarchy_profitcenters