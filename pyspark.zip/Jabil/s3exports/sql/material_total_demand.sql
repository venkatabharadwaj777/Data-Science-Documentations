INSERT INTO incontrol.MaterialTotalDemand
(
     snapshotdate
   , plantcode
   , materialcode
   , TotalDemand
)
SELECT 
      M.snapshotdate
    , M.plantcode
    , M.materialcode
    , SUM ( M.quantity ) AS 'TotalDemand'
FROM    
    incontrol.vw_sl_mrp_tmp M
WHERE
    M.quantity > 0
    AND upper(M.processingrule) = 'REGULAR'
    AND upper(M.mrptypestdcode) IN 
    (
        'DELIVERY'
        , 'INDEPENDENT REQUIREMENT'
        , 'SALES ORDER'
        , 'SALES AGREEMENT'
        , 'INTERPLANT TRANSFER ORDER'
    )
    AND NOT EXISTS 
    (
        SELECT
            NULL
        FROM 
            incontrol.MaterialTotalDemand MD 
        WHERE
            MD.snapshotdate = M.snapshotdate
    )
GROUP BY
      M.snapshotdate
    , M.plantcode
    , M.materialcode   ;


COMPUTE STATS incontrol.MaterialTotalDemand ;