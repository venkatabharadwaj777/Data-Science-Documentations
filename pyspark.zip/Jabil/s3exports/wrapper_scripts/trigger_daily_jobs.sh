#!/bin/bash

# backward processing from start to end date including both dates

eip_folder=/eip_interfaces/code/inControl/s3exports/
config_folder=${eip_folder}config/
script_folder=${eip_folder}wrapper_scripts/
extractcount_str=$(sed -n '/^extractcount/p' ${config_folder}appconfig.conf)

startdate=$1
enddate=$2

if [[ $(date -d "$startdate" +%Y%m%d) -le $(date -d "$enddate" +%Y%m%d) ]]; then
    echo "Backward historical load. Start date can't be less, than end date."
    exit 0
fi

i=0
while [[ "$snapshotdate" != "$enddate" ]]; do
    snapshotdate=$( date -d "$startdate - $i days" +%Y-%m-%d ) # get $i days forward
    echo "Processing s3 export for snapshot date "${snapshotdate}
    # set extract count to 10
    if [[ -z "$snapshotdate" ]]
    then
        echo "EMPTY SNAPSHOTDATE. USING TODAY AS SNAPSHOTDATE"
    else
        sed -ri "s/${extractcount_str}/extractcount=15/g" ${config_folder}appconfig.conf
    fi

    # set snapshotdate in all config files
    sed -ri "s/$(sed -n '/^snapshotdt=/p' ${config_folder}purchaseitems.ini)/snapshotdt=${snapshotdate}/g" ${config_folder}purchaseitems.ini
    sed -ri "s/$(sed -n '/^snapshotdt=/p' ${config_folder}quota_arrangement.ini)/snapshotdt=${snapshotdate}/g" ${config_folder}quota_arrangement.ini
    sed -ri "s/$(sed -n '/^snapshotdt=/p' ${config_folder}purchasing_source_list.ini)/snapshotdt=${snapshotdate}/g" ${config_folder}purchasing_source_list.ini
    sed -ri "s/$(sed -n '/^snapshotdt=/p' ${config_folder}materials.ini)/snapshotdt=${snapshotdate}/g" ${config_folder}materials.ini
    sed -ri "s/$(sed -n '/^snapshotdt=/p' ${config_folder}demand.ini)/snapshotdt=${snapshotdate}/g" ${config_folder}demand.ini
    sed -ri "s/$(sed -n '/^snapshotdt=/p' ${config_folder}agedinventory.ini)/snapshotdt=${snapshotdate}/g" ${config_folder}agedinventory.ini
    sed -ri "s/$(sed -n '/^snapshotdt=/p' ${config_folder}material_total_demand.ini)/snapshotdt=${snapshotdate}/g" ${config_folder}material_total_demand.ini
    sed -ri "s/$(sed -n '/^snapshotdt=/p' ${config_folder}inventory.ini)/snapshotdt=${snapshotdate}/g" ${config_folder}inventory.ini
    sed -ri "s/$(sed -n '/^snapshotdt=/p' ${config_folder}whereusedbom.ini)/snapshotdt=${snapshotdate}/g" ${config_folder}whereusedbom.ini
    sed -ri "s/$(sed -n '/^snapshotdt=/p' ${config_folder}shipment.ini)/snapshotdt=${snapshotdate}/g" ${config_folder}shipment.ini
    sed -ri "s/$(sed -n '/^snapshotdt=/p' ${config_folder}inactivebom.ini)/snapshotdt=${snapshotdate}/g" ${config_folder}inactivebom.ini

    # run all extractions
    sh ${script_folder}incontrol_spark_submit_wrapper.sh purchaseitems.ini
    sh ${script_folder}incontrol_spark_submit_wrapper.sh quota_arrangement.ini
    sh ${script_folder}incontrol_spark_submit_wrapper.sh purchasing_source_list.ini
    sh ${script_folder}incontrol_spark_submit_wrapper.sh materials.ini
    sh ${script_folder}incontrol_spark_submit_wrapper.sh demand.ini
    sh ${script_folder}incontrol_spark_submit_wrapper.sh agedinventory.ini
    sh ${script_folder}material_total_demand_wrapper.sh
    sh ${script_folder}incontrol_spark_submit_wrapper.sh inventory.ini
    sh ${script_folder}incontrol_spark_submit_wrapper.sh whereusedbom.ini
    sh ${script_folder}incontrol_spark_submit_wrapper.sh shipment.ini

    # to send sns message
    sed -ri "s/extractcount=15/extractcount=14/g" ${config_folder}appconfig.conf
    sh ${script_folder}incontrol_spark_submit_wrapper.sh inactivebom.ini

    # remove snapshotdate in all config files
    sed -ri "s/snapshotdt=${snapshotdate}/snapshotdt=/g" ${config_folder}purchaseitems.ini
    sed -ri "s/snapshotdt=${snapshotdate}/snapshotdt=/g" ${config_folder}quota_arrangement.ini
    sed -ri "s/snapshotdt=${snapshotdate}/snapshotdt=/g" ${config_folder}purchasing_source_list.ini
    sed -ri "s/snapshotdt=${snapshotdate}/snapshotdt=/g" ${config_folder}materials.ini
    sed -ri "s/snapshotdt=${snapshotdate}/snapshotdt=/g" ${config_folder}demand.ini
    sed -ri "s/snapshotdt=${snapshotdate}/snapshotdt=/g" ${config_folder}agedinventory.ini
    sed -ri "s/snapshotdt=${snapshotdate}/snapshotdt=/g" ${config_folder}material_total_demand.ini
    sed -ri "s/snapshotdt=${snapshotdate}/snapshotdt=/g" ${config_folder}inventory.ini
    sed -ri "s/snapshotdt=${snapshotdate}/snapshotdt=/g" ${config_folder}whereusedbom.ini
    sed -ri "s/snapshotdt=${snapshotdate}/snapshotdt=/g" ${config_folder}shipment.ini
    sed -ri "s/snapshotdt=${snapshotdate}/snapshotdt=/g" ${config_folder}inactivebom.ini

    i=$(( i + 1 ))
done