#!/bin/bash


set -o xtrace


logit()
{
    echo "[${ACCOUNT}][`date`][material-snapshot] - ${*}" >> ${logfile}
}



appdir="/eip_interfaces/code/inControl/s3exports/"
confdir=${appdir}"config/"
spark_scripts_dir=${appdir}"spark_scripts/"
util_script_path="${spark_scripts_dir}spark_utils.py"
source "${confdir}appconfig.conf"
# Get the hostname to determine the CLUSTER
export USECASE=inControl

case "${HOSTNAME:9:1}" in
"d")
    # DEV only
    export CLUSTER=dev
    export ACCOUNT=svdcor_hdp_incontrol
    executormemory='5g'
    drivermemory='7g'
    cores=5
    bucketarn=${bucketarndev}
    secretsarn=${secretsarndev}
    enable_error_notifications=${enable_error_notifications_dev}
    aurora_database_name=${aurora_database_name_dev}
    ;;
"q")

# STG only
    export CLUSTER=stg
    export ACCOUNT=svscor_hdp_incontrol
    executormemory='10g'
    drivermemory='12g'
    cores=5
    bucketarn=${bucketarnstg}
    secretsarn=${secretsarnstg}
    enable_error_notifications=${enable_error_notifications_stg}
    aurora_database_name=${aurora_database_name_stg}
    ;;
"p")
    # PRD only
    export CLUSTER=prd
    export ACCOUNT=svccor_hdp_incontrol
    executormemory='10g'
    drivermemory='12g'
    cores=5
    bucketarn=${bucketarnprd}
    secretsarn=${secretsarnprd}
    s3exporterrortopic=${snserrorarnprd}
    enable_error_notifications=${enable_error_notifications_prd}
    aurora_database_name=${aurora_database_name_prd}
    ;;
esac



check_job_status()
{
  while [[ "$JobState" != "FINISHED" ]] && [[ "$JobState" != "FAILED" ]] && [[ "$JobState" != "KILLED" ]]
  do
   yarnstatus=$(yarn application -status ${appId}|grep 'State')
   JobState=$(echo ${yarnstatus} | awk '{print $3}')
   FinalState=$(echo ${yarnstatus}|awk '{print $6}')
   logit "Job Status   :"${JobState}
   logit "Final Status :"${FinalState}
   sleep 30
  done
  logit "Job Status   :"${JobState}
  logit "Final Status :"${FinalState}
  if [[ "$FinalState" != "SUCCEEDED" ]]; then
 logit "Job  :"${FinalState}
   logit "*****JOB FAILED********"
   send_error_sns_message "Spark job failed"
   logit "To Check Logs use yarn logs -applicationId "${appId}
   exit 0
  else
   logit "Job  :"${FinalState}
  fi
}


#Spark Config
deploymode='cluster'
script_path="${spark_scripts_dir}ihs_alternates_full.py"
logfile="/eip_interfaces/logs/inControl/incontrol_wrapper_ihs_alternates-$(date +'%Y-%m-%d').log"
s3_root_path="s3a://${bucketarn}/data/"

# kerberos authentication
k5start -qf /eip_interfaces/${ACCOUNT}/${ACCOUNT}.keytab ${ACCOUNT}@CORP.JABIL.ORG


appId=`spark2-submit \
          --executor-memory ${executormemory} \
          --driver-memory ${drivermemory} \
          --executor-cores ${cores} \
          --conf spark.yarn.submit.waitAppCompletion=false \
          --conf spark.sql.hive.caseSensitiveInferenceMode=NEVER_INFER \
          --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 \
          --conf spark.dynamicAllocation.enabled=true \
          --conf spark.dynamicAllocation.maxExecutors=30 \
          --conf spark.sql.session.timeZone=UTC \
          --conf spark.yarn.driver.memoryOverhead=4096 \
          --conf spark.yarn.executor.memoryOverhead=4096 \
          --conf spark.driver.maxResultSize=4g \
          --conf spark.speculation=false \
          --conf spark.sql.parquet.mergeSchema=false \
          --conf spark.sql.parquet.filterPushdown=true \
          --conf spark.sql.hive.metastorePartitionPruning=true \
          --conf spark.kryoserializer.buffer.max=512M \
          --conf spark.sql.shuffle.partitions=2400 \
          --conf spark.shuffle.service.enabled=true \
          --conf spark.shuffle.service.index.cache.size=512m \
          --deploy-mode ${deploymode} \
          ${script_path}  \
          --util_script_path ${util_script_path} \
          --enable_logging ${enable_logging} 2>&1 | tee /dev/tty|grep -io application_[0-9]*_[0-9]* |head -1`




#Monitor Job Status in Yarn
check_job_status ${appId}
logit "--------------------------------------------"
logit "  "
logit "AppID: "${appId}

logit "----------PROCESS COMPLETE-----------------------------"