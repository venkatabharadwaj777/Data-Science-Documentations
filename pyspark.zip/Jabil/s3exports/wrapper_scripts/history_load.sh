#!/bin/bash
# historical load backward from start date to end date
# Ways to run history load:
# 1) history_load end_date domain.ini       (run starting from start_date in domain.ini file till end_date)
# 2) history_load start_date end_date domain.ini      (run starting from start_date till end_date in parameters)

if [[ $# -eq 2 ]]; then
    finaldate=$(date -d "$1"  +%Y%m%d)
    domain_file=$2
    appdir="/eip_interfaces/code/inControl/s3exports/"
    scripts_folder="${appdir}wrapper_scripts/"
    config_folder="${appdir}config/"
    startdate=$(cat "$config_folder$domain_file" | grep snapshotdt | cut -d'=' -f 2)
    startdate=$(date -d "$startdate" +%Y%m%d)

    if [[ "$startdate" -le "$finaldate" ]]; then
        echo 'Historical data completed. Exiting historical load.'
        exit 0
    fi
    enddate=$(date -d "$startdate-4 month" +%Y%m%d)
    if [[ "$enddate" -le "$finaldate" ]]; then
        enddate=${finaldate}
    fi
    olddate=${startdate}
    newdate=${startdate}
elif [[ $# -eq 3 ]]; then
    startdate=$1
    enddate=$2
    domain_file=$3
    if [[ $(date -d "$startdate" +%Y%m%d) -le $(date -d "$enddate" +%Y%m%d) ]]; then
        echo "Backward historical load. Start date can't be less, than end date."
        exit 0
    fi
    olddate=$(cat "$config_folder$domain_file" | grep snapshotdt | cut -d'=' -f 2)
    newdate=${startdate}
else
    echo "Incorrect number of parameters"
    exit 1
fi

enddate=$(date -d "$enddate" +%Y-%m-%d)
startdate=$(date -d "$startdate" +%Y-%m-%d)

printf 'Historical load start date: '
echo ${startdate}
printf 'Historical load end date: '
echo ${enddate}
printf 'Running Historical load for : '
echo ${domain_file}

i=0
while [[ "$newdate" != "$enddate" ]]; do
    printf 'Current date in .ini file:'
    echo $(cat "$config_folder/$domain_file" | grep snapshotdt| cut -d'=' -f 2)
    newdate=$( date -d "$startdate - $i days" +%Y-%m-%d ) # get $i days forward
    printf 'Replacing date in .ini file with: '${newdate}
    printf '\n'
    $(sed -i "s/$olddate/$newdate/g" "$config_folder/$domain_file")
    printf 'New date in .ini file: '
    echo $(cat "$config_folder/$domain_file" | grep snapshotdt| cut -d'=' -f 2)
    /bin/bash ${scripts_folder}incontrol_spark_submit_wrapper.sh ${domain_file} Y
    if [[ $? -ne 0 ]]; then
        echo "ERROR: Performance script failed for date "${newdate}
        echo "Retry in 10 minutes"
        sleep 10m
        /bin/bash ${scripts_folder}incontrol_spark_submit_wrapper.sh ${domain_file} Y
        if [[ $? -ne 0 ]]; then
            echo "ERROR: Performance script failed for date "${newdate}
            echo "Retry in 10 minutes"
            sleep 10m
            /bin/bash ${scripts_folder}incontrol_spark_submit_wrapper.sh ${domain_file} Y
            if [[ $? -ne 0 ]]; then
                echo "ERROR: Performance script failed for date "${newdate}
                echo 'Historical data failed. Exiting historical load.'
                exit 1
            fi
        fi
    fi
    i=$(( i + 1 ))
    olddate=${newdate}
done
