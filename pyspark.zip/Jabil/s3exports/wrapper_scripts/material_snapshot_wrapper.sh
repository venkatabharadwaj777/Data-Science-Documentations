#!/bin/bash

## This wrapper triggers the Spark Submit for extracting waterfall component data.

## Spark Submit calls component_waterfall_job.py

set -o xtrace


logit()
{
    echo "[${ACCOUNT}][`date`][material-snapshot] - ${*}" >> ${logfile}
}



appdir="/eip_interfaces/code/inControl/s3exports/"
confdir=${appdir}"config/"
spark_scripts_dir=${appdir}"spark_scripts/"
util_script_path="${spark_scripts_dir}spark_utils.py"
source "${confdir}appconfig.conf"
source "${confdir}material_snapshot.ini"
# Get the hostname to determine the CLUSTER
export USECASE=inControl

case "${HOSTNAME:9:1}" in
"d")
    # DEV only
    export CLUSTER=dev
    export ACCOUNT=svdcor_hdp_incontrol
    executormemory='5g'
    drivermemory='7g'
    cores=5
    bucketarn=${bucketarndev}
    secretsarn=${secretsarndev}
    s3exporterrortopic=${snserrorarndev}
    enable_error_notifications=${enable_error_notifications_dev}
    aurora_database_name=${aurora_database_name_dev}
    ;;
"q")

# STG only
    export CLUSTER=stg
    export ACCOUNT=svscor_hdp_incontrol
    executormemory='10g'
    drivermemory='12g'
    cores=5
    bucketarn=${bucketarnstg}
    secretsarn=${secretsarnstg}
    s3exporterrortopic=${snserrorarnstg}
    enable_error_notifications=${enable_error_notifications_stg}
    aurora_database_name=${aurora_database_name_stg}
    ;;
"p")
    # PRD only
    export CLUSTER=prd
    export ACCOUNT=svccor_hdp_incontrol
    executormemory='10g'
    drivermemory='12g'
    cores=5
    bucketarn=${bucketarnprd}
    secretsarn=${secretsarnprd}
    s3exporterrortopic=${snserrorarnprd}
    enable_error_notifications=${enable_error_notifications_prd}
    aurora_database_name=${aurora_database_name_prd}
    ;;
esac


send_error_sns_message()
{
  #Send error SNS message
  extractname="Material Snapshot"
  message=$1" for extraction of ${extractname}. Snapshot date: ${snapshotdate}"
  logit "ERROR:  "${message}
  cluster_name=$(echo ${CLUSTER} | tr a-z A-Z)
  if [[ "$enable_error_notifications" == "true" ]]; then
    aws sns publish --topic-arn ${s3exporterrortopic}  --message "${message}"  --subject "$CLUSTER : Error during s3export"  --region ${region}
  fi
}


check_job_status()
{
  while [[ "$JobState" != "FINISHED" ]] && [[ "$JobState" != "FAILED" ]] && [[ "$JobState" != "KILLED" ]]
  do
   yarnstatus=$(yarn application -status ${appId}|grep 'State')
   JobState=$(echo ${yarnstatus} | awk '{print $3}')
   FinalState=$(echo ${yarnstatus}|awk '{print $6}')
   logit "Job Status   :"${JobState}
   logit "Final Status :"${FinalState}
   sleep 30
  done
  logit "Job Status   :"${JobState}
  logit "Final Status :"${FinalState}
  if [[ "$FinalState" != "SUCCEEDED" ]]; then
 logit "Job  :"${FinalState}
   logit "*****JOB FAILED********"
   send_error_sns_message "Spark job failed"
   logit "To Check Logs use yarn logs -applicationId "${appId}
   exit 0
  else
   logit "Job  :"${FinalState}
  fi
}


createdrop_temp_table ()
{
    tablename=$1
    schemaname=$2
    datecolumn=$3

    SQLQuery="USE ${USECASE};DROP TABLE IF EXISTS ${USECASE}.${tablename}_TMP;set PARQUET_FILE_SIZE=10m;CREATE TABLE ${USECASE}.${tablename}_TMP STORED AS PARQUET AS SELECT * FROM ${schemaname}.${tablename} where ${datecolumn} = '${snapshotdate}'";
    logit "$SQLQuery"

    impala-shell -k --ssl -i hadoop${CLUSTER} -q "${SQLQuery}"
    if [[ $? -ne 0 ]];then
        logit "Temp Table Creation Second Attempt"
        impala-shell -k --ssl -i hadoop${CLUSTER} -q "${SQLQuery}"
          if [[ $? -ne 0 ]];then
                  error="Error on Executing the Impala Temp table creation for "${tablename}
                  send_error_sns_message "${error}"
                  exit 0
          else
                  logit "Temp Table Created successfully on Second Attempt"
          fi
    else
          logit "Temp Table Created Successfully"
    fi
}


#Spark Config
deploymode='cluster'
script_path="${spark_scripts_dir}material_snapshot_job.py"
logfile="/eip_interfaces/logs/inControl/incontrol_wrapper_material_snapshot-$(date +'%Y-%m-%d').log"
s3_root_path="s3a://${bucketarn}/data/"
target_s3path="${s3_root_path}${s3_target_path}"

# kerberos authentication
k5start -qf /eip_interfaces/${ACCOUNT}/${ACCOUNT}.keytab ${ACCOUNT}@CORP.JABIL.ORG


datespecified='false'
if [[ -z "$snapshotdate" ]]; then
    snapshotdate=$(date +%Y-%m-%d)
    logit "Snapshot date wasn't specified. Use today as a snapshot date"
else
    datespecified='true'
    snapshotdate=$(date -d ${snapshotdate} +%Y-%m-%d)
    logit "Specified snapshot date is "${snapshotdate}
fi

if [[ ${datespecified} == 'true' && ${data_source} != 'S3' ]]; then
    createdrop_temp_table "vw_sl_mrp" "scm" "snapshotdate"
    createdrop_temp_table "vw_sl_agedinventory" "scm" "snapshotdate"
fi


appId=`spark2-submit \
          --packages mysql:mysql-connector-java:5.1.38\
          --executor-memory ${executormemory} \
          --driver-memory ${drivermemory} \
          --executor-cores ${cores} \
          --conf spark.yarn.submit.waitAppCompletion=false \
          --conf spark.sql.hive.caseSensitiveInferenceMode=NEVER_INFER \
          --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 \
          --conf spark.dynamicAllocation.enabled=true \
          --conf spark.dynamicAllocation.maxExecutors=30 \
          --conf spark.sql.session.timeZone=UTC \
          --conf spark.yarn.driver.memoryOverhead=4096 \
          --conf spark.yarn.executor.memoryOverhead=4096 \
          --conf spark.speculation=false \
          --conf spark.sql.parquet.mergeSchema=false \
          --conf spark.sql.parquet.filterPushdown=true \
          --conf spark.sql.hive.metastorePartitionPruning=true \
          --conf spark.kryoserializer.buffer.max=512M \
          --conf spark.sql.shuffle.partitions=2400 \
          --conf spark.shuffle.service.enabled=true \
          --conf spark.shuffle.service.index.cache.size=512m \
          --deploy-mode ${deploymode} \
          ${script_path}  \
          --util_script_path ${util_script_path} \
          --snapshotdate ${snapshotdate} \
          --s3_root_path ${s3_root_path} \
          --target_s3_path ${target_s3path} \
          --secrets_arn ${secretsarn} \
          --region_name ${region} \
          --s3_output_format ${s3_output_format} \
          --aurora_table_name ${aurora_table_name} \
          --aurora_database_name ${aurora_database_name} \
          --data_source ${data_source} \
          --loadtodb ${loadtodb} \
          --enable_logging ${enable_logging} 2>&1 | tee /dev/tty|grep -io application_[0-9]*_[0-9]* |head -1`



#Monitor Job Status in Yarn
check_job_status ${appId}
logit "--------------------------------------------"
logit "  "
logit "AppID: "${appId}

logit "----------PROCESS COMPLETE-----------------------------"
