#!/bin/bash

## Usage ./incontrol_spar_submit_wrapper.sh configfile.ini

## This wrapper triggers the Spark Submit for extracting data from EIP to S3.

## Spark Submit calls spark_incontrol.py

## Create an SQL and INI file , and pass the INI file as input to this script


set -o xtrace


logit()
{
    echo "[${USER}][`date`][$filename] - ${*}" >> ${logfile}
}



if [[ $# -eq 0 ]] || [[ ${1: -4} != ".ini" ]]
  then
    logit "ini file not supplied or file does not end with extension ini"
    exit 0
fi

skip_sns=$([[ $# -eq 2 && $2 -e "Y" ]] && echo true || echo false)

logit $1

appdir="/eip_interfaces/code/inControl/s3exports/"
confdir=${appdir}"config/"
spark_scripts_dir=${appdir}"spark_scripts/"
sql_dir=${appdir}"sql/"

pyspark_script="spark_incontrol.py"
script_path="${spark_scripts_dir}${pyspark_script}"
util_script_path="${spark_scripts_dir}spark_utils.py"
extractname=$(echo $1| cut -d'.' -f 1)
logfile="/eip_interfaces/logs/inControl/incontrol_wrapper_$extractname-$(date +'%Y-%m-%d').log"
source "$confdir$1"
source "${confdir}appconfig.conf"
logit $1


# Get the hostname to determine the CLUSTER
export USECASE=inControl
case "${HOSTNAME:9:1}" in
"d")
    # DEV only
    export CLUSTER=dev
    export ACCOUNT=svdcor_hdp_incontrol
    S3path=${S3path//dev/$CLUSTER}
    hadoopcreds='jceks://hdfs/user/svdcor_hdp_incontrol/awskeyfile.jceks'
    bucketarn=$bucketarndev
    snsarn=$snsarndev
    snsauroraarn=$snsauroraarndev
    secretsarn=$secretsarndev
    s3exporterrortopic=$snserrorarndev
    enable_error_notifications=$enable_error_notifications_dev
    aurora_database_name=$aurora_database_name_dev
    ;;
"q")

# STG only
    export CLUSTER=stg
    export ACCOUNT=svscor_hdp_incontrol
    S3path=${S3path//dev/$CLUSTER}
    hadoopcreds='jceks://hdfs/user/svscor_hdp_incontrol/awskeyfile.jceks'
    bucketarn=$bucketarnstg
    snsarn=$snsarnstg
    snsauroraarn=$snsauroraarnstg
    secretsarn=$secretsarnstg
    s3exporterrortopic=$snserrorarnstg
    enable_error_notifications=$enable_error_notifications_stg
    aurora_database_name=$aurora_database_name_stg
    ;;
"p")
    # PRD only
    export CLUSTER=prd
    export ACCOUNT=svccor_hdp_incontrol
    S3path=${S3path//dev/$CLUSTER}
    hadoopcreds='jceks://hdfs/user/svccor_hdp_incontrol/awskeyfile.jceks'
    bucketarn=$bucketarnprd
    snsarn=$snsarnprd
    snsauroraarn=$snsauroraarnprd
    secretsarn=$secretsarnprd
    s3exporterrortopic=$snserrorarnprd
    enable_error_notifications=$enable_error_notifications_prd
    aurora_database_name=$aurora_database_name_prd
    ;;
esac

#Spark Config
deploymode='cluster'
#get variables from the ini file
logit "SQL File to Run:  "$filename
logit "Partition Flag:   "$partition
logit "Snapshot Date:    "$snapshotdt
logit "S3 Path:          "$S3path
logit "OutputFormat:     "$outputformat
logit "Temp Table Flag   "$temptable
logit "Table Name        "$tablename
logit "Schema            "$schemaname
logit "Load to Db        "$loadtodb
logit "Error topic:      "$s3exporterrortopic
if [[ -z "$snapshotdt" ]]; then
snapshotdtparam=''
tempsnapdt=$(date '+%Y-%m-%d')
elif [[ "$snapshotdt" == "N"  ]]; then
snapshotdtparam="--snapshotdt "$snapshotdt
tempsnapdt=$(date '+%Y-%m-%d')
else
snapshotdtparam="--snapshotdt "$snapshotdt
tempsnapdt=$snapshotdt
fi

if [[ -z "$dbtable" ]]; then
dbtableparam=''
else
dbtableparam="--dbtable "$dbtable
fi

if [[ -z "$update_latest_snapshot" ]]; then
update_latest_snapshot_param=''
else
update_latest_snapshot_param="--update_latest_snapshot "$update_latest_snapshot
fi

#Below section is specific to BOM incremental Loads
if [[ -z "$deltadateparam" ]]; then
deltadateparam=$(date -d "yesterday 13:00" '+%Y-%m-%d')
fi
logit $deltadateparam

filepath="$sql_dir$filename"
#Submit Spark Job with the parameters
k5start -qf /eip_interfaces/${ACCOUNT}/${ACCOUNT}.keytab ${ACCOUNT}@CORP.JABIL.ORG




#Function to Write into DynamoDB and check if all processes are successful

update_eip_incontrol_dynamodb()
{

  processname=EIP-${tablename}
  aws dynamodb put-item \
        --table-name eip-jobcontrol \
        --item '{"snapshotdate": {"S": '\"$tempsnapdt\"'},"processname": {"S": '\"$processname\"'},"status":{"S":"SUCCESS"}}' --region $region
  #Get the Number of Records for the snapshotdate
   tablecount=$(aws dynamodb query --table-name eip-jobcontrol \
              --key-condition-expression 'snapshotdate = :a AND  begins_with(processname,:b) ' \
                          --expression-attribute-values '{  ":a": {"S": '\"$tempsnapdt\"'},":b": {"S": "EIP-"} }' \
                          --consistent-read --select COUNT --region $region |jq '.Count')
    logit "Records for Current Snapshot Date    : "$tablecount
}


#Function to Send SNS Message on completion of EIP

send_sns_message()
{
  #Read Message Structure
  MessageStruct=$(<$confdir/messagestruct.json)
  logit $MessageStruct
  #Update Bucket Name & Snapshot Date
  MessageStruct=$(jq --arg tempsnapdt "$tempsnapdt" --arg bucketarn "$bucketarn" '.input.snapshots = [$tempsnapdt]|.input.bucketARN =$bucketarn' <<<"$MessageStruct")
  logit $MessageStruct
  #Stringify the message
  MessageStruct=${MessageStruct//\"/\\\"}
  logit "Add the header for SNS"
  Message="{\"default\":\""$MessageStruct"\"}"
  logit $Message
  echo $Message > /tmp/CurrentMsg.json
 #Send SNS
  aws sns publish --topic-arn $snsarn --message-structure json --message file:///tmp/CurrentMsg.json --region $region
}

send_error_sns_message()
{
  #Send error SNS message
  message=$1" for extraction of ${extractname}. Snapshot date: ${tempsnapdt}"
  logit "ERROR:  "${message}
  cluster_name=$(echo $CLUSTER | tr a-z A-Z)
  if [[ "$enable_error_notifications" == "true" ]]; then
    aws sns publish --topic-arn ${s3exporterrortopic}  --message "${message}"  --subject "$CLUSTER : Error during s3export"  --region ${region}
  fi
}

send_sns_aurora_message()
{
  #Read Message Structure
  #Send SNS
  logit $extractname
  aws sns publish --topic-arn $snsauroraarn  --message "$extractname Triggered"  --subject "Aurora Load Triggered"  --region $region
}

check_job_status()
{

  while [[ "$JobState" != "FINISHED" ]] && [[ "$JobState" != "FAILED" ]] && [[ "$JobState" != "KILLED" ]]
  do
   yarnstatus=$(yarn application -status $appId|grep 'State')
   JobState=$(echo $yarnstatus | awk '{print $3}')
   FinalState=$(echo $yarnstatus|awk '{print $6}')
   logit "Job Status   :"${JobState}
   logit "Final Status :"${FinalState}
   sleep 30
  done
  logit "Job Status   :"${JobState}
  logit "Final Status :"${FinalState}
  if [[ "$FinalState" != "SUCCEEDED" ]]; then
 logit "Job  :"${FinalState}
   logit "*****JOB FAILED********"
   logit "To Check Logs use yarn logs -applicationId "${appId}
   send_error_sns_message "Spark job failed"
  else
   logit "Job  :"${FinalState}
   logit "Write code to send message to SQS"
   update_eip_incontrol_dynamodb
    if [[ "$loadtodb" == 'Y' ]]; then
        send_sns_aurora_message
    fi

  fi
}

#Function to Create Temporary table in inControl Schema to alleviate performance issue with VIEWS

createdrop_temp_table ()
{

        if [[ $snapshotdt == 'N' ]];then

            SQLQuery="USE ${USECASE};DROP TABLE IF EXISTS ${USECASE}.${tablename}_TMP;set PARQUET_FILE_SIZE=10m;CREATE TABLE ${USECASE}.${tablename}_TMP STORED AS PARQUET AS SELECT * FROM ${schemaname}.${tablename}";
            logit "$SQLQuery"
        else
            SQLQuery="USE ${USECASE};DROP TABLE IF EXISTS ${USECASE}.${tablename}_TMP;set PARQUET_FILE_SIZE=10m;CREATE TABLE ${USECASE}.${tablename}_TMP STORED AS PARQUET AS SELECT * FROM ${schemaname}.${tablename} where SNAPSHOTDATE = '${tempsnapdt}'";
                logit "$SQLQuery"
        fi
        impala-shell -k --ssl -i hadoop${CLUSTER} -q "${SQLQuery}"
        if [[ $? -ne 0 ]];then
            logit "Temp Table Creation Second Attempt"
            impala-shell -k --ssl -i hadoop${CLUSTER} -q "${SQLQuery}"
              if [[ $? -ne 0 ]];then
                      error="Error on Executing the Impala Temp table creation"
                      logit ${error}
                      send_error_sns_message "${error}"
                      exit 1
              else
                      logit "Temp Table Created successfully on Second Attempt"

              fi
        else
              logit "Temp Table Created Successfully"

        fi

}

# function to check non-zero records presence
check_records_count()
{
    logit "Checking records count for ${1} table"
    SQLQuery="select count(*) from $1"
    count=$(impala-shell -k --ssl -i hadoop${CLUSTER} -q "${SQLQuery}" -B)
    logit "COUNT = ${count}"
    if [[ ${count} == 0 ]]; then
        error="Zero records fetched"
        logit "${error}"
        send_error_sns_message "${error}"
        exit 1
    fi
}


if [[ "$temptable" == "Y" ]]; then
    createdrop_temp_table
    check_records_count "${USECASE}.${tablename}_TMP"
else
    check_records_count "${schemaname}.${tablename}"
fi

appId=`spark2-submit \
          --packages mysql:mysql-connector-java:5.1.38\
          --executor-memory ${executor_memory} \
          --driver-memory ${driver_memory} \
          --executor-cores ${cores_number} \
          --conf spark.yarn.submit.waitAppCompletion=false \
          --conf spark.sql.hive.caseSensitiveInferenceMode=NEVER_INFER \
          --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 \
          --conf spark.dynamicAllocation.enabled=true \
          --conf spark.dynamicAllocation.maxExecutors=30 \
          --conf spark.sql.session.timeZone=UTC \
          --conf spark.yarn.driver.memoryOverhead=4096 \
          --conf spark.yarn.executor.memoryOverhead=4096 \
          --conf spark.speculation=false \
          --conf spark.sql.parquet.mergeSchema=false \
          --conf spark.sql.parquet.filterPushdown=true \
          --conf spark.sql.hive.metastorePartitionPruning=true \
          --conf spark.kryoserializer.buffer.max=512M \
          --conf spark.sql.shuffle.partitions=2400 \
          --conf spark.shuffle.service.enabled=true \
          --conf spark.shuffle.service.index.cache.size=512m \
          --deploy-mode ${deploymode} \
          --files ${filepath} ${script_path} \
          --util_script_path ${util_script_path} \
          --sqlfile ${filename} \
          --partition ${partition} \
          ${snapshotdtparam} \
          --S3Path ${S3path} \
          --secrets ${secretsarn} \
          --region_name ${region} \
          --aurora_database_name ${aurora_database_name} \
          --s3export_error_topic ${s3exporterrortopic} \
          --cluster_env ${CLUSTER} \
          --enable_error_notifications ${enable_error_notifications} \
          ${update_latest_snapshot_param} \
          ${dbtableparam} \
          --outputformat ${outputformat}    2>&1 | tee /dev/tty|grep -io application_[0-9]*_[0-9]* |head -1`


#Monitor Job Status in Yarn
check_job_status $appId
logit "--------------------------------------------"
logit "  "
logit "AppID: "${appId}

if [[ "$tablecount" == "$extractcount" && "$skip_sns" != "false" ]]; then
  logit "All Processes complete for the day.Sending SNS for Iceberg"
  send_sns_message

else
    logit "All Processes not complete"

fi
logit "----------PROCESS COMPLETE-----------------------------"
