#!/bin/bash

## This wrapper triggers the Spark Submit for extracting waterfall component data.

## Spark Submit calls component_waterfall_job.py

set -o xtrace


logit()
{
    echo "[${ACCOUNT}][`date`][high-watermark-report] - ${*}" >> ${logfile}
}



appdir="/eip_interfaces/code/inControl/s3exports/"
confdir=${appdir}"config/"
spark_scripts_dir=${appdir}"spark_scripts/"
util_script_path="${spark_scripts_dir}spark_utils.py"
source "${confdir}appconfig.conf"
source "${confdir}high_watermark_report.ini"
# Get the hostname to determine the CLUSTER
export USECASE=inControl

case "${HOSTNAME:9:1}" in
"d")
    # DEV only
    export CLUSTER=dev
    export ACCOUNT=svdcor_hdp_incontrol
    executormemory='5g'
    drivermemory='7g'
    cores=5
    bucketarn=${bucketarndev}
    secretsarn=${secretsarndev}
    aurora_database_name=${aurora_database_name_dev}
    ;;
"q")

# STG only
    export CLUSTER=stg
    export ACCOUNT=svscor_hdp_incontrol
    executormemory='10g'
    drivermemory='12g'
    cores=5
    bucketarn=${bucketarnstg}
    secretsarn=${secretsarnstg}
    aurora_database_name=${aurora_database_name_stg}
    ;;
"p")
    # PRD only
    export CLUSTER=prd
    export ACCOUNT=svccor_hdp_incontrol
    executormemory='10g'
    drivermemory='12g'
    cores=5
    bucketarn=${bucketarnprd}
    secretsarn=${secretsarnprd}
    aurora_database_name=${aurora_database_name_prd}
    ;;
esac


check_job_status()
{
  while [[ "$JobState" != "FINISHED" ]] && [[ "$JobState" != "FAILED" ]] && [[ "$JobState" != "KILLED" ]]
  do
   yarnstatus=$(yarn application -status ${appId}|grep 'State')
   JobState=$(echo ${yarnstatus} | awk '{print $3}')
   FinalState=$(echo ${yarnstatus}|awk '{print $6}')
   logit "Job Status   :"${JobState}
   logit "Final Status :"${FinalState}
   if [[ "$JobState" == "RUNNING" || "$JobState" == "ACCEPTED" ]]; then
       sleep 30
   fi
  done
  logit "Job Status   :"${JobState}
  logit "Final Status :"${FinalState}
  if [[ "$FinalState" != "SUCCEEDED" ]]; then
 logit "Job  :"${FinalState}
   logit "*****JOB FAILED********"
   send_error_sns_message "Spark job failed"
   logit "To Check Logs use yarn logs -applicationId "${appId}
   exit 0
  else
   logit "Job  :"${FinalState}
  fi
}

send_error_sns_message()
{
  #Send error SNS message
  extractname="High Watermark Report. Snapshot date: ${snapshotdate}"
  message=$1" for extraction of "${extractname}
  logit "ERROR:  "${message}
  cluster_name=$(echo ${CLUSTER} | tr a-z A-Z)
  if [[ "$enable_error_notifications" == "true" ]]; then
    aws sns publish --topic-arn ${s3exporterrortopic}  --message "${message}"  --subject "$CLUSTER : Error during aurora export"  --region ${region}
  fi
}


create_current_week_consumption_temp_table ()
{
    day_of_week=$( date +%u --date "$snapshotdate")
    next_monday_date=$(date --date "$snapshotdate +$((8-day_of_week)) days" +%Y-%m-%d)
    next_monday_date_minus_13w=$(date --date "$next_monday_date -13 weeks" +%Y-%m-%d)
    next_monday_date_minus_26w=$(date --date "$next_monday_date -26 weeks" +%Y-%m-%d)
    next_monday_date_minus_39w=$(date --date "$next_monday_date -39 weeks" +%Y-%m-%d)
    next_monday_date_minus_52w=$(date --date "$next_monday_date -52 weeks" +%Y-%m-%d)

    # CurrentWeekConsumption - quantity for next Monday
    # RollingNwkAvgConsumptionList - list of (N - 1) quantities (next Monday not presented)
    SQLQuery="USE ${USECASE};\
              DROP TABLE IF EXISTS ${USECASE}.vw_conship_79mondays_TMP;\
              set PARQUET_FILE_SIZE=10m;\
              CREATE TABLE ${USECASE}.vw_conship_79mondays_TMP STORED AS PARQUET\
                AS SELECT wfplant as PlantCode, wfmaterial as MaterialCode,\
                    GROUP_CONCAT(CASE WHEN wfccedate = '${next_monday_date}' THEN CAST(wfconsump_qty AS STRING) END) as CurrentWeekConsumption,\
                    GROUP_CONCAT(CASE WHEN wfccedate > '$next_monday_date_minus_13w' AND wfccedate < '${next_monday_date}' THEN CAST(wfconsump_qty AS STRING) END) as Rolling13wkAvgConsumptionList,\
                    GROUP_CONCAT(CASE WHEN wfccedate > '$next_monday_date_minus_26w' AND wfccedate < '${next_monday_date}' THEN CAST(wfconsump_qty AS STRING) END) as Rolling26wkAvgConsumptionList,\
                    GROUP_CONCAT(CASE WHEN wfccedate > '$next_monday_date_minus_39w' AND wfccedate < '${next_monday_date}' THEN CAST(wfconsump_qty AS STRING) END) as Rolling39wkAvgConsumptionList,\
                    GROUP_CONCAT(CASE WHEN wfccedate > '$next_monday_date_minus_52w' AND wfccedate < '${next_monday_date}' THEN CAST(wfconsump_qty AS STRING) END) as Rolling52wkAvgConsumptionList\
                FROM domains.vw_conship_79mondays\
                WHERE wfccedate > '${next_monday_date_minus_52w}' and wfccedate <= '${next_monday_date}'\
                GROUP BY wfplant, wfmaterial;"
    logit "$SQLQuery"

    impala-shell -k --ssl -i hadoop${CLUSTER} -q "${SQLQuery}"
    if [[ $? -ne 0 ]];then
        logit "Temp Table Creation Second Attempt"
        impala-shell -k --ssl -i hadoop${CLUSTER} -q "${SQLQuery}"
          if [[ $? -ne 0 ]];then
                  error="Error on Executing the Impala Temp table creation for "${tablename}
                  send_error_sns_message "${error}"
                  exit 0
          else
                  logit "Temp Table Created successfully on Second Attempt"
          fi
    else
          logit "Temp Table Created Successfully"
    fi
}


#Spark Config
deploymode='cluster'
script_path="${spark_scripts_dir}high_watermark_report_job.py"
logfile="/eip_interfaces/logs/inControl/incontrol_wrapper_high_watermark-$(date +'%Y-%m-%d').log"
s3_root_path="s3a://${bucketarn}/data/"

# kerberos authentication
k5start -qf /eip_interfaces/${ACCOUNT}/${ACCOUNT}.keytab ${ACCOUNT}@CORP.JABIL.ORG


datespecified='false'
if [[ -z "$snapshotdate" ]]; then
    snapshotdate=$(date +%Y-%m-%d)
    logit "Snapshot date wasn't specified. Use today as a snapshot date"
else
    datespecified='true'
    snapshotdate=$(date -d ${snapshotdate} +%Y-%m-%d)
    logit "Specified snapshot date is "${snapshotdate}
fi

create_current_week_consumption_temp_table ${snapshotdate}


appId=`spark2-submit \
          --packages mysql:mysql-connector-java:5.1.38\
          --executor-memory ${executormemory} \
          --driver-memory ${drivermemory} \
          --executor-cores ${cores} \
          --conf spark.yarn.submit.waitAppCompletion=false \
          --conf spark.sql.hive.caseSensitiveInferenceMode=NEVER_INFER \
          --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 \
          --conf spark.dynamicAllocation.enabled=true \
          --conf spark.dynamicAllocation.maxExecutors=30 \
          --conf spark.sql.session.timeZone=UTC \
          --conf spark.yarn.driver.memoryOverhead=4096 \
          --conf spark.yarn.executor.memoryOverhead=4096 \
          --conf spark.speculation=false \
          --conf spark.sql.parquet.mergeSchema=false \
          --conf spark.sql.parquet.filterPushdown=true \
          --conf spark.sql.hive.metastorePartitionPruning=true \
          --conf spark.kryoserializer.buffer.max=512M \
          --conf spark.sql.shuffle.partitions=2400 \
          --conf spark.shuffle.service.enabled=true \
          --conf spark.shuffle.service.index.cache.size=512m \
          --deploy-mode ${deploymode} \
          ${script_path}  \
          --util_script_path ${util_script_path} \
          --snapshotdate ${snapshotdate} \
          --s3_root_path ${s3_root_path} \
          --secrets_arn ${secretsarn} \
          --region_name ${region} \
          --aurora_table_name ${aurora_table_name} \
          --component_header_aurora_table_name ${component_header_aurora_table_name} \
          --aurora_database_name ${aurora_database_name} \
          --enable_logging ${enable_logging} 2>&1 | tee /dev/tty|grep -io application_[0-9]*_[0-9]* |head -1`



#Monitor Job Status in Yarn
check_job_status ${appId}
logit "--------------------------------------------"
logit "  "
logit "AppID: "${appId}

logit "----------PROCESS COMPLETE-----------------------------"
