#!/bin/bash
# historical load backward from start date to end date
# Ways to run history load:
# 1) history_load end_date domain.ini       (run starting from start_date in domain.ini file till end_date)
# 2) history_load start_date end_date domain.ini      (run starting from start_date till end_date in parameters)

check_job_status()
{
  while [[ "$JobState" != "FINISHED" ]] && [[ "$JobState" != "FAILED" ]] && [[ "$JobState" != "KILLED" ]]
  do
   yarnstatus=$(yarn application -status ${appId}|grep 'State')
   JobState=$(echo ${yarnstatus} | awk '{print $3}')
   FinalState=$(echo ${yarnstatus}|awk '{print $6}')
   logit "Job Status   :"${JobState}
   logit "Final Status :"${FinalState}
   sleep 30
  done
  logit "Job Status   :"${JobState}
  logit "Final Status :"${FinalState}
  if [[ "$FinalState" != "SUCCEEDED" ]]; then
 logit "Job  :"${FinalState}
   logit "*****JOB FAILED********"
   send_error_sns_message "Spark job failed"
   logit "To Check Logs use yarn logs -applicationId "${appId}
   exit 0
  else
   logit "Job  :"${FinalState}
  fi
}

export ACCOUNT=svscor_hdp_incontrol
k5start -qf /eip_interfaces/${ACCOUNT}/${ACCOUNT}.keytab ${ACCOUNT}@CORP.JABIL.ORG

enddate=$(date -d "$2" +%Y-%m-%d)
startdate=$(date -d "$1" +%Y-%m-%d)
read_s3_root_path="s3a://jbl-prd-use1-s3-incontrol-003/data/"
write_s3_root_path="s3a://jbl-prd-use1-s3-incontrol-003/data/"

printf 'Historical load start date: '
echo ${startdate}
printf 'Historical load end date: '
echo ${enddate}
printf 'Running Historical load for : MaterialKeys'
newdate=${startdate}

i=0
while [[ "$newdate" != "$enddate" ]]; do
    newdate=$( date -d "$startdate + $i days" +%Y-%m-%d ) # get $i days forward

    appId=`spark2-submit \
              --packages mysql:mysql-connector-java:5.1.38\
              --executor-memory 3G \
              --driver-memory 4G \
              --executor-cores 2 \
              --conf spark.yarn.submit.waitAppCompletion=false \
              --conf spark.sql.hive.caseSensitiveInferenceMode=NEVER_INFER \
              --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 \
              --conf spark.dynamicAllocation.enabled=true \
              --conf spark.dynamicAllocation.maxExecutors=30 \
              --conf spark.sql.session.timeZone=UTC \
              --conf spark.yarn.driver.memoryOverhead=4096 \
              --conf spark.yarn.executor.memoryOverhead=4096 \
              --conf spark.speculation=false \
              --conf spark.sql.parquet.mergeSchema=false \
              --conf spark.sql.parquet.filterPushdown=true \
              --conf spark.sql.hive.metastorePartitionPruning=true \
              --conf spark.kryoserializer.buffer.max=512M \
              --conf spark.sql.shuffle.partitions=2400 \
              --conf spark.shuffle.service.enabled=true \
              --conf spark.shuffle.service.index.cache.size=512m \
              --deploy-mode client \
              /eip_interfaces/code/inControl/s3exports/spark_scripts/demand_material_keys.py  \
              --util_script_path "/eip_interfaces/code/inControl/s3exports/spark_scripts/spark_utils.py" \
              --snapshotdate ${newdate} \
              --region_name "us-east-1" \
              --read_s3_root_path ${read_s3_root_path} \
              --write_s3_root_path ${write_s3_root_path} \
              --target_s3_path "incontrol/demand_material_keys" 2>&1 | tee /dev/tty|grep -io application_[0-9]*_[0-9]* |head -1`

    check_job_status ${appId}

    i=$(( i + 1 ))
    olddate=${newdate}
done
