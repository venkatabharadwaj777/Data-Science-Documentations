#!/bin/bash -vx

date -u

set -o xtrace


logit()
{
    echo "[${USER}][`date`][material_total_demand] - ${*}" >> ${logfile}
}

appdir="/eip_interfaces/code/inControl/s3exports/"
confdir=${appdir}"config/"
sql_dir=${appdir}"sql/"
sql_file=${sql_dir}"material_total_demand.sql"
extractname="Material Total Demand"
logfile="/eip_interfaces/logs/inControl/incontrol_wrapper_$extractname-$(date +'%Y-%m-%d').log"

source ${confdir}"material_total_demand.ini"
source "${confdir}appconfig.conf"


export USECASE=inControl

# Get the hostname to determine the CLUSTER
case "${HOSTNAME:9:1}" in
"d")
    # DEV only
    export CLUSTER=dev
    export ACCOUNT=svdcor_hdp_incontrol
    enable_error_notifications=${enable_error_notifications_dev}
    hadoopcreds='jceks://hdfs/user/svdcor_hdp_incontrol/awskeyfile.jceks'
    s3exporterrortopic=${snserrorarndev}
    ;;
"q")
    # STG only
    export CLUSTER=stg
    export ACCOUNT=svscor_hdp_incontrol
    enable_error_notifications=${enable_error_notifications_stg}
    hadoopcreds='jceks://hdfs/user/svscor_hdp_incontrol/awskeyfile.jceks'
    s3exporterrortopic=${snserrorarnstg}
    ;;
"p")
    # PRD only
    export CLUSTER=prd
    export ACCOUNT=svccor_hdp_incontrol
    enable_error_notifications=${enable_error_notifications_prd}
    hadoopcreds='jceks://hdfs/user/svccor_hdp_incontrol/awskeyfile.jceks'
    s3exporterrortopic=${snserrorarnprd}
    ;;
esac

send_error_sns_message()
{
  #Send error SNS message
  message=$1" for extraction of "${extractname}
  logit "ERROR:  "${message}
  cluster_name=$(echo ${CLUSTER} | tr a-z A-Z)
  if [[ "$enable_error_notifications" == "true" ]]; then
    aws sns publish --topic-arn ${s3exporterrortopic}  --message "${message}" \
     --subject "$CLUSTER : Error during Material_Total_Demand extraction"  --region ${region}
  fi
}

check_records_count()
{
    logit "Checking records count from mrp temp table for snapshot date  ${snapshotdate}"
    SQLQuery="select count(*) from incontrol.vw_sl_mrp_tmp"
    count=$(impala-shell -k --ssl -i hadoop${CLUSTER} -q "${SQLQuery}" -B)
    logit "COUNT = ${count}"
    if [[ ${count} == 0 ]]; then
        error="Zero records fetched from mrp for snapshot date  "${snapshotdate}
        send_error_sns_message "${error}"
        exit 1
    fi
}

createdrop_temp_table ()
{
    tablename=$1
    schemaname=$2
    datecolumn=$3
    SQLQuery="USE ${USECASE};DROP TABLE IF EXISTS ${USECASE}.${tablename}_TMP;set PARQUET_FILE_SIZE=10m;
    CREATE TABLE ${USECASE}.${tablename}_TMP STORED AS PARQUET AS SELECT * FROM ${schemaname}.${tablename}
    where SNAPSHOTDATE = '${snapshotdate}'";
    logit "$SQLQuery"
    impala-shell -k --ssl -i hadoop${CLUSTER} -q "${SQLQuery}"
    if [[ $? -ne 0 ]];then
        logit "Temp Table Creation Second Attempt"
        impala-shell -k --ssl -i hadoop${CLUSTER} -q "${SQLQuery}"
          if [[ $? -ne 0 ]];then
                  error="Error on Executing the Impala Temp table creation"
                  send_error_sns_message "${error}"
                  exit 1
          else
                  logit "Temp Table Created successfully on Second Attempt"
          fi
    else
          logit "Temp Table Created Successfully"
    fi
}

k5start -qf /eip_interfaces/${ACCOUNT}/${ACCOUNT}.keytab ${ACCOUNT}@CORP.JABIL.ORG

if [[ -z "$snapshotdt" ]]; then
    snapshotdate=$(date +%Y-%m-%d)
    logit "Snapshot date wasn't specified. Use today as a snapshot date"
else
    snapshotdate=$(date -d ${snapshotdt} +%Y-%m-%d)
    logit "Specified snapshot date is "${snapshotdate}
    createdrop_temp_table "vw_sl_mrp" "scm" "snapshotdate"
fi

logit "SQL File to Run:  "${filename}
logit "Snapshot Date:    "${snapshotdate}

check_records_count

logit "Running query from sql file"
impala-shell -k --ssl -i hadoop${CLUSTER} --var=snapshotdate=${snapshotdate} -f ${sql_file}
if [[ $? -ne 0 ]]; then
    error="Error on Executing the Impala INSERT query "
    send_error_sns_message "${error}"
fi

logit "----------PROCESS COMPLETE-----------------------------"
