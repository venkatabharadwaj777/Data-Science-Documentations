from unittest.mock import MagicMock
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import DateType
from pyspark.sql import Row
from pyspark.sql.functions import schema_of_json, from_json
from importlib import import_module
import unittest
import json
import os
import sys
sys.path.insert(0, os.path.abspath('..'))
from spark_scripts.material_snapshot_job import MaterialSnapshotPipeline, DataProvider
import coverage
coverage.process_startup()


class AbstractSparkTest(unittest.TestCase):

    test_files_loc = "./test_files/material_snapshot/"

    on_order_structure_example = '[{"materialKey": "_", "deliveryFinishDts":  "yyyy-MM-dd", ' \
                              '"mrpTypeStdCode": "_", "quantity": 0}]'
    on_hand_structure_example = '[{"inventoryTypeStdCode":"_","netMvmtQuantityNonConsigned":0.0,"totalMvmtQuantity":0.0,' \
                             '"ageNonConsigned":0,"totalAge":0,"standardUnitCost":0.0,' \
                             '"postingDate":"yyyy-MM-dd 00:00:00","materialKey":"_"}]'
    demand_summary_structure_example = '[{"deliveryFinishDts": "yyyy-MM-dd", ' \
                             '"inDepQuantity": 0, "depQuantity": 0}]'
    shipment_structure_example = '[{"maxPostedDts": "yyyy-MM-dd 00:00:00", "snapshotDate": "yyyy-MM-dd 00:00:00"}]'

    @classmethod
    def create_testing_pyspark_session(cls):
        return SparkSession.builder.master('local[2]').appName('material_snapshot_test').getOrCreate()

    @classmethod
    def setUpClass(cls):
        cls.pipeline_configs = "2020-01-01", "target_s3_path", "s3_output_format", "N", \
            "aurora_database_name", "aurora_table_name", "secrets_arn", "region_name", "s3_root_folder", \
            "../spark_scripts/spark_utils.py", "raw_data_source", False
        cls.spark_session = cls.create_testing_pyspark_session()
        # creating schemas for nested objects
        empty_dataframe = cls.spark_session.createDataFrame([Row(ex_num=0)])
        nested_schemas = empty_dataframe.select(
            schema_of_json(AbstractSparkTest.on_order_structure_example).alias('on_order_schema'),
            schema_of_json(AbstractSparkTest.on_hand_structure_example).alias('on_hand_schema'),
            schema_of_json(AbstractSparkTest.demand_summary_structure_example).alias('demand_summary_schema'),
            schema_of_json(AbstractSparkTest.shipment_structure_example).alias('shipment_schema')
        ).collect()[0]
        cls.nested_objects_schemas = {"on_order_schema": nested_schemas['on_order_schema'],
                                      "on_hand_schema": nested_schemas['on_hand_schema'],
                                      "demand_summary_schema": nested_schemas['demand_summary_schema'],
                                      "shipment_schema": nested_schemas['shipment_schema']}

    @classmethod
    def tearDownClass(cls):
        cls.spark_session.stop()

    def read_test_file(self, file_name):
        with open(MaterialSnapshotTest.test_files_loc + file_name) as json_file:
            data = json.load(json_file)
        test_data = data['test_data']
        test_input_data = {}
        for domain in test_data.keys():
            rows_array = [Row(**domain_data_row) for domain_data_row in test_data[domain]]
            test_input_data[domain] = self.spark_session.createDataFrame(data=rows_array)
        expected_data = data['expected_data']
        if type(expected_data) is dict:
            expected_input_data = {}
            for domain in expected_data.keys():
                rows_array = [Row(**domain_data_row) for domain_data_row in expected_data[domain]]
                expected_input_data[domain] = self.spark_session.createDataFrame(data=rows_array)
        else:
            expected_input_data = self.spark_session.createDataFrame(data=[Row(**exp_row) for exp_row in expected_data])
        return test_input_data, expected_input_data

    def compare_data_frames(self, expected, actual):
        df_cols = expected.columns
        self.assertEqual(sorted(df_cols), sorted(actual.columns), "DataFrames' structure is different")
        self.assertEqual(expected.count(), actual.count(), "DataFrames' records count is different")
        self.assertEqual(expected.exceptAll(actual.select(*df_cols)).count(), 0, "DataFrames are not equal")

    def prepare_pipeline(self):
        spark_utils = import_module('spark_scripts.spark_utils')
        data_provider = DataProvider(self.spark_session, spark_utils,
                                          self.pipeline_configs[8], self.pipeline_configs[10], self.pipeline_configs[0])
        material_snapshot_pipeline = MaterialSnapshotPipeline(self.spark_session, spark_utils,
                                                              data_provider, *self.pipeline_configs)
        return data_provider, material_snapshot_pipeline


class MaterialSnapshotTest(AbstractSparkTest):

    def test_get_on_order_data(self):
        _, material_snapshot_pipeline = self.prepare_pipeline()
        test_input_data, expected_data = self.read_test_file("get_on_order_test.json")
        mrp_data = test_input_data['mrp_data']
        materials_data = test_input_data['materials_data']\
            .withColumn("snapshotDate", col("snapshotDate").cast(DateType()))

        actual_data = material_snapshot_pipeline.get_on_order_data(mrp_data, materials_data)
        expected_data['summary_data'] = expected_data['summary_data']\
            .withColumn("onOrder", from_json(col("onOrder"), self.nested_objects_schemas['on_order_schema']))

        self.compare_data_frames(expected_data['total'], actual_data['total'])
        self.compare_data_frames(expected_data['summary_data'], actual_data['summary_data'])

    def test_get_on_hand_data(self):
        _, material_snapshot_pipeline = self.prepare_pipeline()
        test_input_data, expected_data = self.read_test_file("get_on_hand_test.json")
        aged_inventory_data = test_input_data['aged_inventory_data']

        actual_data = material_snapshot_pipeline.get_on_hand_data(aged_inventory_data)
        expected_data['summary_data'] = expected_data['summary_data']\
            .withColumn("onHand", from_json(col("onHand"), self.nested_objects_schemas['on_hand_schema']))

        self.compare_data_frames(expected_data['total'], actual_data['total'])
        self.compare_data_frames(expected_data['summary_data'], actual_data['summary_data'])

    def test_get_demand_summary_data(self):
        _, material_snapshot_pipeline = self.prepare_pipeline()
        test_input_data, expected_data = self.read_test_file("get_demand_summary_test.json")
        mrp_data = test_input_data['mrp_data']

        actual_data = material_snapshot_pipeline.get_demand_summary_data(mrp_data)
        expected_data['summary_data'] = expected_data['summary_data']\
            .withColumn("demand", from_json(col("demand"), self.nested_objects_schemas['demand_summary_schema']))

        self.compare_data_frames(expected_data['total'], actual_data['total'])
        self.compare_data_frames(expected_data['summary_data'], actual_data['summary_data'])
        self.compare_data_frames(expected_data['sales_order_quantity'], actual_data['sales_order_quantity'])

    def test_get_demand_in_lead_time(self):
        _, material_snapshot_pipeline = self.prepare_pipeline()
        test_input_data, expected_data = self.read_test_file("get_demand_in_lead_time_test.json")
        materials_with_demand = test_input_data['materials_with_demand'] \
            .withColumn("demand", from_json(col("demand"), self.nested_objects_schemas['demand_summary_schema']))

        actual_data = material_snapshot_pipeline.get_demand_in_lead_time(materials_with_demand)
        self.compare_data_frames(expected_data, actual_data)

    def test_get_base_material_object(self):
        grid_data_provider, material_snapshot_pipeline = self.prepare_pipeline()
        test_input_data, expected_data = self.read_test_file("get_base_material_object_test.json")
        materials_data = test_input_data['materials_data']
        mrp_data = test_input_data['mrp_data']
        on_hand_data = {"total": test_input_data['on_hand_data']}
        on_order_data = {"total": test_input_data['on_order_data']}
        inactive_bom_data = test_input_data['inactive_bom_data']
        grid_data_provider.get_inactive_bom_data = MagicMock(return_value=inactive_bom_data)

        actual_data = material_snapshot_pipeline.get_base_material_object(materials_data, mrp_data,
                                                                          on_hand_data, on_order_data)
        expected_data = expected_data.withColumn("demand",
                                                 from_json(col("demand"),
                                                           self.nested_objects_schemas['demand_summary_schema']))
        self.compare_data_frames(expected_data, actual_data)

    def test_material_snapshot_pipeline(self):
        test_input_data, expected_data = self.read_test_file("material_snapshot_pipeline_test.json")
        spark_utils = import_module('spark_scripts.spark_utils')

        spark_utils.get_secrets = MagicMock(return_value=("host", "user", "pwd"))
        spark_utils.write_to_s3 = MagicMock(return_value=None)
        shipment_data = test_input_data['shipment_data']\
            .withColumn("shipment", from_json(col("shipment"), self.nested_objects_schemas['shipment_schema']))
        data_provider = DataProvider(self.spark_session, spark_utils, self.pipeline_configs[10],
                                          self.pipeline_configs[1], self.pipeline_configs[0])
        data_provider.get_materials_data = MagicMock(return_value=test_input_data['materials_data'])
        data_provider.get_inactive_bom_data = MagicMock(return_value=test_input_data['inactive_bom_data'])
        data_provider.get_demand_data = MagicMock(return_value=test_input_data['mrp_data'])
        data_provider.get_shipment_data = MagicMock(return_value=shipment_data)

        data_provider.get_agedinventory_data = MagicMock(return_value=test_input_data['aged_inventory_data'])

        material_snapshot_pipeline = MaterialSnapshotPipeline(self.spark_session, spark_utils,
                                                              data_provider, *self.pipeline_configs)
        material_snapshot_pipeline.run_pipeline()

        snapshot_date = material_snapshot_pipeline.snapshot_date
        target_s3_path = material_snapshot_pipeline.target_s3_path
        s3_output_format = material_snapshot_pipeline.s3_output_format
        s3path = target_s3_path + "/YYYY=" + snapshot_date[:4] + \
                 "/MM=" + snapshot_date[5:7] + \
                 "/DD=" + snapshot_date[8:]
        expected_s3_params = {"s3_output_format": s3_output_format, "s3path": s3path,
                              "s3_folder_name": None, "is_partitioned": True,
                              "partition_column": "profitplant"}
        spark_utils.write_to_s3.assert_called_once()
        actual_write_call_params = spark_utils.write_to_s3.call_args_list[0]
        self.assertEqual(expected_s3_params, actual_write_call_params[0][1], "Incorrect Aurora params")
        self.compare_data_frames(expected_data, actual_write_call_params[0][0])


if __name__ == '__main__':
    unittest.main()
