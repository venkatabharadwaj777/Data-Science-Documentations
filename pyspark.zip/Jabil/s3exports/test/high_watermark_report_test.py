from unittest.mock import MagicMock
from pyspark.sql import SparkSession
from pyspark.sql import Row
from importlib import import_module
import unittest
import json
import os
import sys
sys.path.insert(0, os.path.abspath('..'))
from spark_scripts.high_watermark_report_job import HighWatermarkDataProvider, HighWatermarkPipeline


class AbstractSparkTest(unittest.TestCase):

    @classmethod
    def create_testing_pyspark_session(cls):
        return SparkSession.builder.master('local[2]').appName('high_watermark_report_test').getOrCreate()

    @classmethod
    def setUpClass(cls):
        cls.pipeline_configs = "2020-02-24", "s3root_path", "secrets_arn", \
                               "region_name", "aurora_table_name", "aurora_database_name", False
        cls.spark_session = cls.create_testing_pyspark_session()

    @classmethod
    def tearDownClass(cls):
        cls.spark_session.stop()

    def prepare_pipeline(self):
        spark_utils = import_module('spark_scripts.spark_utils')
        spark_utils.get_secrets = MagicMock(return_value=("host", "user", "pwd"))
        data_provider = HighWatermarkDataProvider(self.spark_session, spark_utils)
        pipeline = HighWatermarkPipeline(self.spark_session, data_provider, spark_utils, self.pipeline_configs)
        return data_provider, pipeline

    def compare_data_frames(self, expected, actual):
        df_cols = expected.columns
        self.assertEqual(sorted(df_cols), sorted(actual.columns), "DataFrames' structure is different")
        self.assertEqual(expected.count(), actual.count(), "DataFrames' records count is different")
        self.assertEqual(expected.exceptAll(actual.select(*df_cols)).count(), 0, "DataFrames are not equal")

    def read_test_file(self, file_name):
        with open(HighWatermarkReportTest.test_files_loc + file_name) as json_file:
            data = json.load(json_file)
        test_data = data['test_data']
        test_input_data = {}
        for domain in test_data.keys():
            rows_array = [Row(**domain_data_row) for domain_data_row in test_data[domain]]
            test_input_data[domain] = self.spark_session.createDataFrame(data=rows_array)
        expected_data = self.spark_session.createDataFrame(data=[Row(**exp_row) for exp_row in data['expected_data']])
        return test_input_data, expected_data


class HighWatermarkReportTest(AbstractSparkTest):

    test_files_loc = "./test_files/high_watermark_report/"

    def test_high_watermark_report_pipeline_monday(self):
        high_watermark_data_provider, high_watermark_pipeline = self.prepare_pipeline()
        test_input_data, expected_data = self.read_test_file("high_watermark_report_pipeline_test.json")
        spark_utils = import_module('spark_scripts.spark_utils')

        spark_utils.get_secrets = MagicMock(return_value=("host", "user", "pwd"))
        spark_utils.write_to_aurora = MagicMock(return_value=None)
        high_watermark_pipeline.update_main_table = MagicMock(return_value=None)

        high_watermark_data_provider.get_base_component_waterfall_data = MagicMock(return_value=
                                                                                   test_input_data[
                                                                                       'component_waterfall_data'])
        high_watermark_data_provider.get_on_order_data = MagicMock(return_value=(test_input_data['consigned_on_order'],
                                                                                 test_input_data['jabil_owned_on_order']))
        high_watermark_data_provider.get_prior_wkly_receipts_data = MagicMock(return_value=
                                                                              test_input_data[
                                                                                  'prior_wkly_receipts_data'])
        high_watermark_data_provider.get_prev_12_weeks_avg_data = MagicMock(return_value=
                                                                            test_input_data['prev_13_weeks_avg_data'])
        high_watermark_data_provider.get_consumption_data = MagicMock(return_value=
                                                                      test_input_data['79_mondays_data'])

        high_watermark_pipeline.run_pipeline()

        expected_aurora_params = {"aurora_database_name": high_watermark_pipeline.aurora_database_name,
                                  "aurora_table_name": high_watermark_pipeline.aurora_table_name,
                                  "aurora_host": "host", "aurora_user": "user", "aurora_pwd": "pwd",
                                  "snapshot_date_column": "SnapshotDate",
                                  "snapshot_date": high_watermark_pipeline.snapshot_date.strftime("%Y-%m-%d"),
                                  "drop_snapshot_date": True}
        spark_utils.write_to_aurora.assert_called_once()
        actual_call_params = spark_utils.write_to_aurora.call_args_list[0]

        # self.compare_data_frames(expected_data, actual_call_params[0][0])
        self.assertEqual(expected_aurora_params, actual_call_params[0][1], "Incorrect Aurora params")


if __name__ == '__main__':
    unittest.main()
