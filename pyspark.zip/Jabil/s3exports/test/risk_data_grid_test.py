from unittest.mock import MagicMock
from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.functions import current_date
from datetime import datetime, timedelta
from importlib import import_module
import unittest
import json
import os
import sys
sys.path.insert(0, os.path.abspath('..'))
from spark_scripts.risk_data_grid import RiskDataGridPipeline, DataProvider


class AbstractSparkTest(unittest.TestCase):

    @classmethod
    def create_testing_pyspark_session(cls):
        return SparkSession.builder.master('local[2]').appName('risk_data_grid_test').getOrCreate()

    @classmethod
    def setUpClass(cls):
        cls.pipeline_configs = "snapshotdate", "s3_root_folder", "secrets_arn", \
                               "region_name", \
                               "../spark_scripts/spark_utils.py",\
                               "False", "aurora_table_name", "aurora_database_name"
        cls.spark_session = cls.create_testing_pyspark_session()

    @classmethod
    def tearDownClass(cls):
        cls.spark_session.stop()

    def prepare_pipeline(self):
        spark_utils = import_module('spark_scripts.spark_utils')
        spark_utils.get_secrets = MagicMock(return_value=("host", "user", "pwd"))
        grid_data_provider = DataProvider(self.spark_session, spark_utils,
                                          self.pipeline_configs[1], self.pipeline_configs[0])
        data_grid_pipeline = RiskDataGridPipeline(self.spark_session, spark_utils,
                                                  grid_data_provider, *self.pipeline_configs)
        return grid_data_provider, data_grid_pipeline

    def compare_data_frames(self, expected, actual):
        df_cols = expected.columns
        self.assertEqual(sorted(df_cols), sorted(actual.columns), "DataFrames' structure is different")
        self.assertEqual(expected.count(), actual.count(), "DataFrames' records count is different")
        self.assertEqual(expected.exceptAll(actual.select(*df_cols)).count(), 0, "DataFrames are not equal")

    def read_test_file(self, file_name):
        with open(RiskDataGridTest.test_files_loc + file_name) as json_file:
            data = json.load(json_file)
        test_data = data['test_data']
        test_input_data = {}
        for domain in test_data.keys():
            rows_array = [Row(**domain_data_row) for domain_data_row in test_data[domain]]
            test_input_data[domain] = self.spark_session.createDataFrame(data=rows_array)
        expected_data = self.spark_session.createDataFrame(data=[Row(**exp_row) for exp_row in data['expected_data']])
        return test_input_data, expected_data


class RiskDataGridTest(AbstractSparkTest):

    test_files_loc = "./test_files/risk_data_grid/"

    def test_full_materials_data(self):
        grid_data_provider, data_grid_pipeline = self.prepare_pipeline()
        test_input_data, expected_data = self.read_test_file("full_materials_data_test.json")

        grid_data_provider.get_materials_data = MagicMock(return_value=test_input_data['materials'])
        grid_data_provider.get_aml_count_data = MagicMock(return_value=test_input_data['aml_count_data'])
        grid_data_provider.get_material_comm_data = MagicMock(return_value=test_input_data['material_comm_data'])

        actual_result_data = data_grid_pipeline.get_full_materials_data()
        self.compare_data_frames(expected_data, actual_result_data)

    def test_add_purchasing_info_data(self):
        grid_data_provider, data_grid_pipeline = self.prepare_pipeline()
        test_input_data, expected_data = self.read_test_file("add_purchasing_info_test.json")

        materials_data = test_input_data['materials']
        grid_data_provider.get_purchasing_info_record_data = MagicMock(return_value=test_input_data['purchasing_info_data'])
        grid_data_provider.get_source_type_data = MagicMock(return_value=test_input_data['source_type_data'])

        actual_data = data_grid_pipeline.add_purchasing_info_data(materials_data)
        self.compare_data_frames(expected_data, actual_data)

    def test_aggregate_source_list_data(self):
        grid_data_provider, data_grid_pipeline = self.prepare_pipeline()
        test_input_data, _ = self.read_test_file("aggregate_source_list_test.json")
        
        grouping_columns = ['MaterialKey']
        source_list_data = test_input_data['source_list_data']
        
        expected_data = self.spark_session.createDataFrame([
            Row(MaterialKey='MK1', SourceListSourcingCount=1,  SourceListRecord=
                Row(CorporationName="CorpName1", AmlReference="AmlReference1",
                    SupplierCorporationDSCode="SuppCorpDsCode1", PurchasingOrganizationCode="PurchOrgCode1")),
            Row(MaterialKey='MK2', SourceListSourcingCount=2, SourceListRecord=
                Row(CorporationName="CorpName3", AmlReference="AmlReference3",
                    SupplierCorporationDSCode="SuppCorpDsCode3", PurchasingOrganizationCode="PurchOrgCode3")),
            Row(MaterialKey='MK3', SourceListSourcingCount=3, SourceListRecord=
                Row(CorporationName="CorpName5", AmlReference="AmlReference5",
                    SupplierCorporationDSCode="SuppCorpDsCode5", PurchasingOrganizationCode="PurchOrgCode5"))
        ])

        actual_data = data_grid_pipeline.aggregate_source_list_data(source_list_data, grouping_columns)
        self.compare_data_frames(expected_data, actual_data)

    def test_aggregate_quota_arrangement_data(self):
        _, data_grid_pipeline = self.prepare_pipeline()
        test_input_data, _ = self.read_test_file("aggregate_quota_arrangement_test.json")
        today = datetime.now()
        tomorrow = today + timedelta(days=1)
        yesterday = today - timedelta(days=1)

        quota_arrangement_data = test_input_data['quota_arrangement_data']
        quota_arrangement_effective_data_data = self.spark_session.createDataFrame([
            # EffectiveToDate = today and TargetRatio > 0
            Row(MaterialKey="MK1", AmlReference="Aml1", EffectiveToDate=today.strftime("%Y%m%d"),
                EffectiveFromDate=yesterday.strftime("%Y%m%d")),
            # EffectiveToDate > today and TargetRatio > 0
            Row(MaterialKey="MK1", AmlReference="Aml2", EffectiveToDate=tomorrow.strftime("%Y%m%d"),
                EffectiveFromDate=yesterday.strftime("%Y%m%d")),
            # EffectiveToDate > today and TargetRatio = 0
            Row(MaterialKey="MK1", AmlReference="Aml3", EffectiveToDate=tomorrow.strftime("%Y%m%d"),
                EffectiveFromDate=yesterday.strftime("%Y%m%d")),
            # EffectiveToDate < today and TargetRatio > 0
            Row(MaterialKey="MK1", AmlReference="Aml4", EffectiveToDate=yesterday.strftime("%Y%m%d"),
                EffectiveFromDate=yesterday.strftime("%Y%m%d"))
        ])
        quota_arrangement_data = quota_arrangement_data\
            .join(quota_arrangement_effective_data_data, ['MaterialKey', "AmlReference"])

        expected_data = self.spark_session.createDataFrame([
            Row(MaterialKey='MK1', SourcingCount=2,
                QuotaArrangement=[Row(AmlReference="Aml1", CorporationName="CorpName1", TargetRatio=50.0,
                                      PurchasingOrganizationCode='PurchOC1', SupplierCorporationDSCode='SCDC1'),
                                  Row(AmlReference="Aml2", CorporationName="CorpName2", TargetRatio=50.0,
                                      PurchasingOrganizationCode='PurchOC2', SupplierCorporationDSCode='SCDC2',)])
        ])
        actual_data = data_grid_pipeline.aggregate_quota_arrangement_data(quota_arrangement_data)
        self.compare_data_frames(expected_data, actual_data)

    def test_get_source_list_materials_aml_only(self):
        _, data_grid_pipeline = self.prepare_pipeline()
        test_input_data, expected_data = self.read_test_file("source_list_materials_aml_only_test.json")
        materials_data = test_input_data['materials']
        source_list_data = test_input_data['source_list_data']
        join_cols = ["MaterialKey"]
        aml_only = True
        actual_data = data_grid_pipeline.get_source_list_materials(materials_data,
                                                                   source_list_data, join_cols, aml_only=aml_only)
        self.compare_data_frames(expected_data, actual_data)

    def test_get_source_list_materials(self):
        _, data_grid_pipeline = self.prepare_pipeline()
        test_input_data, expected_data = self.read_test_file("source_list_materials_test.json")
        materials_data = test_input_data['materials']
        source_list_data = test_input_data['source_list_data']
        join_cols = ["MaterialKey", "SupplierCorporationDSCode"]
        aml_only = False
        actual_data = data_grid_pipeline.get_source_list_materials(materials_data,
                                                                   source_list_data, join_cols, aml_only=aml_only)
        self.compare_data_frames(expected_data, actual_data)

    def test_get_quota_arr_materials(self):
        _, data_grid_pipeline = self.prepare_pipeline()
        test_input_data, expected_data = self.read_test_file("quota_arrangement_materials_test.json")

        materials_data = test_input_data['materials']
        quota_arrangement_data = test_input_data['quota_arrangement_data']
        tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y%m%d")
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
        quota_arrangement_effective_data_data = self.spark_session.createDataFrame([
            Row(MaterialKey="MK1", EffectiveToDate=tomorrow, EffectiveFromDate=yesterday),
            Row(MaterialKey="MK2", EffectiveToDate=tomorrow, EffectiveFromDate=yesterday),
            Row(MaterialKey="MK3", EffectiveToDate=tomorrow, EffectiveFromDate=yesterday)
        ])
        quota_arrangement_data = quota_arrangement_data.join(quota_arrangement_effective_data_data, ['MaterialKey'])
        source_list_data = test_input_data['source_list_data']

        actual_data = data_grid_pipeline.get_quota_arr_materials(materials_data,
                                                                 quota_arrangement_data, source_list_data)
        self.compare_data_frames(expected_data, actual_data)

    def test_add_preferred_supplier_data(self):
        grid_data_provider, data_grid_pipeline = self.prepare_pipeline()
        test_input_data, expected_data = self.read_test_file("add_preferred_supplier_data_test.json")

        grid_data_provider.get_preferred_supplier_data = MagicMock(return_value=
                                                                   test_input_data['preferred_supplier_data'])
        actual_data = data_grid_pipeline.add_preferred_supplier_data(test_input_data['supplier_data'])

        self.compare_data_frames(expected_data, actual_data)

    # def test_data_grid_pipeline(self):
    #     test_input_data, expected_data = self.read_test_file("data_grid_pipeline_test.json")
    #     spark_utils = import_module('spark_scripts.spark_utils')
    #
    #     spark_utils.get_secrets = MagicMock(return_value=("host", "user", "pwd"))
    #     spark_utils.write_to_aurora = MagicMock(return_value=None)
    #     spark_utils.update_snapshot_table = MagicMock(return_value=None)
    #     grid_data_provider = DataProvider(self.spark_session, spark_utils,
    #                                       self.pipeline_configs[1], self.pipeline_configs[0])
    #     data_grid_pipeline = RiskDataGridPipeline(self.spark_session, spark_utils,
    #                                               grid_data_provider, *self.pipeline_configs)
    #     grid_data_provider.get_materials_data = MagicMock(return_value=test_input_data['materials'])
    #     grid_data_provider.get_aml_count_data = MagicMock(return_value=test_input_data['aml_count_data'])
    #     grid_data_provider.get_material_comm_data = MagicMock(return_value=test_input_data['material_comm_data'])
    #     grid_data_provider.get_ihs_data = MagicMock(return_value=test_input_data['ihs_data'])
    #     grid_data_provider.get_preferred_supplier_data = MagicMock(return_value=
    #                                                                test_input_data['preferred_supplier_data'])
    #     grid_data_provider.get_purchasing_info_record_data = MagicMock(return_value=
    #                                                                    test_input_data['purchasing_info_data'])
    #     grid_data_provider.get_source_type_data = MagicMock(return_value=test_input_data['source_type_data'])
    #
    #     quota_arrangement_data = test_input_data['quota_arrangement']
    #     tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y%m%d")
    #     yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
    #     quota_arrangement_effective_data_data = self.spark_session.createDataFrame([
    #         Row(MaterialKey="MK1", EffectiveToDate=tomorrow, EffectiveFromDate=yesterday),
    #         Row(MaterialKey="MK2", EffectiveToDate=tomorrow, EffectiveFromDate=yesterday),
    #         Row(MaterialKey="MK3", EffectiveToDate=tomorrow, EffectiveFromDate=yesterday)
    #     ])
    #     quota_arrangement_data = quota_arrangement_data.join(quota_arrangement_effective_data_data, ['MaterialKey'])
    #     grid_data_provider.get_quota_arrangement_data = MagicMock(return_value=quota_arrangement_data)
    #     grid_data_provider.get_purchasing_source_list_data = MagicMock(return_value=test_input_data['source_list'])
    #     grid_data_provider.get_corporation_data = MagicMock(return_value=test_input_data['manufacturer_data'])
    #
    #     expected_data = expected_data.withColumn("CreatedDate", current_date())
    #     data_grid_pipeline.run_pipeline()
    #     expected_aurora_params = {"aurora_database_name": data_grid_pipeline.aurora_database_name,
    #                               "aurora_table_name": data_grid_pipeline.aurora_table_name,
    #                               "aurora_host": "host", "aurora_user": "user", "aurora_pwd": "pwd",
    #                               "snapshot_date_column": "Version",
    #                               "snapshot_date": data_grid_pipeline.snapshot_date,
    #                               "drop_snapshot_date": True}
    #     spark_utils.write_to_aurora.assert_called_once()
    #     actual_call_params = spark_utils.write_to_aurora.call_args_list[0]
    #
    #     actual_call_params[0][0].sort("MaterialKey").show(truncate=False)
    #     self.compare_data_frames(expected_data, actual_call_params[0][0])
    #     self.assertEqual(expected_aurora_params, actual_call_params[0][1], "Incorrect Aurora params")


if __name__ == '__main__':
    unittest.main()
