
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import StringType
from datetime import datetime
from mysql.connector import MySQLConnection, Error
import logging
import argparse
import boto3
import json


def configure_logging():
    logfile = "/eip_interfaces/logs/inControl/" + datetime.now().strftime(
        'incontrol_dataingest_material_snapshot_logfile_%Y-%m-%d_%H-%M.log')
    fmt = '%(asctime)s %(message)s'
    logging.basicConfig(filename=logfile, level=logging.INFO, format=fmt)


def get_parameters():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--snapshotdate", dest="snapshot_date", metavar="9999-01-01",
                        help="Date in Y-MM-DD format for which query needs to run. If no Date is provided it will "
                             "run for today", required=False)
    parser.add_argument("--s3_root_path", dest="s3_root_path", metavar="s3a://bucket_name/object_path",
                        help="Bucket and object path for writing result data", required=True)
    parser.add_argument("--region_name", dest="region_name",
                        help="AWS Region")
    parser.add_argument("--secrets_arn", dest="secrets_arn",
                        help="Secrets name to retrieve Aurora Credentials", required=False)
    parser.add_argument("--aurora_database_name", dest="aurora_database_name",
                        help="Database name for material snapshot data")
    parser.add_argument("--aurora_table_name", dest="aurora_table_name",
                        help="Table name for material snapshot data")
    args = parser.parse_args()
    return args.snapshot_date, args.s3_root_path, args.aurora_database_name, args.aurora_table_name, args.secrets_arn, args.region_name

def get_secrets(secretsarn, region_name):
    logging.info("Retrieve Aurora Credentials")
    secret_name = secretsarn
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    secret = get_secret_value_response['SecretString']
    parsed_secret = json.loads(secret)
    host = parsed_secret['host']
    user = parsed_secret['username']
    pwd = parsed_secret['password']
    return host, user, pwd

def read_data(spark, s3_root_path, snapshot_date):
    s3path = s3_root_path + "incontrol/whereusedbom" + \
             "/YYYY=" + snapshot_date[:4] + "/MM=" + snapshot_date[5:7] + "/DD=" + snapshot_date[8:]
    data_df = spark.read.format("parquet").load(s3path)
    data_df = data_df.withColumn("MaterialKey", concat(col("datasourceid"), lit("_"),col("plantcode"), lit("_"),col("materialcode"))) \
        .withColumn("SnapshotDate", col('snapshotdate').cast(StringType()).substr(1, 10))
    return data_df.repartitionByRange(100, "MaterialKey")

def write_data(data, aurora_params):
    host = aurora_params['aurora_host']
    database_name = aurora_params['aurora_database_name']
    table_name = aurora_params['aurora_table_name']
    user = aurora_params['aurora_user']
    password = aurora_params['aurora_pwd']
    logging.info("Inside Write to Aurora")
    logging.info(host)
    url = "jdbc:mysql://%s/%s?useServerPrepStmts=false&rewriteBatchedStatements=true&" \
          "useUnicode=yes&characterEncoding=UTF-8" % (host, database_name)
    data.write.format('jdbc').options(url=url, driver="com.mysql.jdbc.Driver",
                                      dbtable=table_name, user=user,
                                      password=password).mode('append').save()

def run_load_whereused():
    spark = SparkSession.builder.getOrCreate()
    snapshot_date, s3_root_path, aurora_database_name, aurora_table_name, secrets_arn, region_name = get_parameters()
    logging.info("Snapshot date:   %s" % snapshot_date)
    logging.info("S3 root path:   %s" % s3_root_path)
    whereused_data = read_data(spark, s3_root_path, snapshot_date)
    aurora_host, aurora_user, aurora_pwd = get_secrets(secrets_arn, region_name)
    aurora_params = {"aurora_database_name": aurora_database_name, "aurora_table_name": aurora_table_name,"aurora_host": aurora_host, "aurora_user": aurora_user, "aurora_pwd": aurora_pwd}
    write_data(whereused_data, aurora_params)
    logging.info("Process Completed")
    spark.stop()

def main():
    run_load_whereused()

if __name__ == "__main__":
    main()

