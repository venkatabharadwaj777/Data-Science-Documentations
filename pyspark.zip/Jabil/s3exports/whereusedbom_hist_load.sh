#!/bin/bash
startdate=$1
enddate=$2
printf 'Historical load start date: '
echo $1
printf 'Historical load end date: '
echo $2
printf 'Running Historical load for : '
echo $3
olddate=$(cat ./config/"$3" | grep snapshotdt | cut -d'=' -f 2)
echo $olddate
newdate=$startdate
i=0
while [ "$newdate" != "$enddate" ]; do
    printf 'Current date in .ini file:'
    echo $(cat ./config/"$3" | grep snapshotdt| cut -d'=' -f 2)
    newdate=$( date -d "$startdate + $i days" +%Y-%m-%d ) # get $i days forward
    printf 'Replacing date in .ini file with: '$newdate
    printf '\n'
    $(sed -i "s/$olddate/$newdate/g" ./config/"$3")
    printf 'New date in .ini file: '
    echo $(cat ./config/"$3" | grep snapshotdt| cut -d'=' -f 2)
    /bin/bash whereusedbom_hist.sh $3
    i=$(( i + 1 ))
    olddate=$newdate
done
